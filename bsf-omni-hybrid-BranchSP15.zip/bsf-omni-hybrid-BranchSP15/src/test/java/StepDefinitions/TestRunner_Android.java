package StepDefinitions;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import org.testng.annotations.BeforeClass;

@io.cucumber.testng.CucumberOptions(
        features = "src/test/resources/Features",
        glue = {"StepDefinitions"},
        tags = "@TC_Messages_inbox_01_02_01_01",
        monochrome = true,
        plugin = {"pretty",
                "html:target/cucumber-html-report.html",
                "json:target/cucumber-json-report.json",
                "junit:target/cucumber-junit-xml-report.xml",
                "rerun:target/cucumber-reports/rerun.txt",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        },
        dryRun = false
)
public class TestRunner_Android extends AbstractTestNGCucumberTests {
//    public static void main(String[] args) {
//        // Set the tag value using the system property
//        // You can pass the desired tag as a command-line argument using "-Dcucumber.tags=<tag>"
//        System.setProperty("tagToRun", System.getProperty("tagToRun"));
//
//        // Run Cucumber tests
////        org.junit.runner.JUnitCore.main("com.example.TestRunner");
//    }

    public TestRunner_Android() {
        RunnerInfo.setName("android");
    }
}