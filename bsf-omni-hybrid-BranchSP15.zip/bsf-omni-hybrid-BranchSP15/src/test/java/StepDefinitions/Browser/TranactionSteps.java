package StepDefinitions.Browser;

import Pages.actions.Browser.Transactions_Browser;
import io.cucumber.java.en.Then;

public class TranactionSteps {

    Transactions_Browser Trans = new Transactions_Browser();


    @Then("user click on account number {string}")
    public void view_All_tabs(String value) {
        Trans.getClickAccounts(value);
    }

    @Then("user is able to view transaction")
    public void TransactionPage() {
        Trans.GetTransactionPage();
    }

    @Then("user enter {string} to search in transaction")
    public void searchTransaction(String value) {
        Trans.GetTransactionSearch(value);
    }

    @Then("user is able to see {string} message")
    public void TransactionMessage(String value) {
        Trans.GetTransactionMessage(value);
    }

    @Then("user click on cancel button on transaction page")
    public void userClickOnCancelButtonTransactionPage() {
        Trans.GetTransactionCancelBtn();
    }

    @Then("user click on Filter button")
    public void userClickFilterButton() {
        Trans.GetTransactionFilterClick();
    }

    @Then("user is able to view transaction Filters options")
    public void user_is_able_to_view_transaction_filters_options() {
        Trans.GetTransactionFilterOptions();
    }
    @Then("user is able to view Start Date with date format as {string}")
    public void user_is_able_to_view_start_date_with_date_format(String value) {
        Trans.GetTransactionFilterStartDate(value);
    }
    @Then("user is able to view End Date with date format as {string}")
    public void user_is_able_to_view_end_date_with_date_format(String value) {
        Trans.GetTransactionFilterENDDate(value);
    }
    @Then("user click on Date filter with calendar control")
    public void user_click_on_date_filter_with_calendar_control() {
        Trans.FilterCalandarOptions();
    }

    @Then("user is able to view {string} drop down")
    public void user_is_able_to_view_credit_debit_drop_down(String value) {
        Trans.GetTransactionCreditDebitField(value);
    }
    @Then("user is able to view {string} field with prompt text {string}")
    public void user_is_able_to_view_field_with_prompt_text(String value, String placeholder) {
        Trans.GetTransactionMinMaxField(value,placeholder);
    }

    @Then("user is able to view {string} button in transaction")
    public void user_is_able_to_view_button_in_transaction(String value) {
        Trans.GetTransactionButton(value);
    }

    @Then("user enter date as {string} in {string}")
    public void user_enter_date_as_in(String string, String string2) {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

}
