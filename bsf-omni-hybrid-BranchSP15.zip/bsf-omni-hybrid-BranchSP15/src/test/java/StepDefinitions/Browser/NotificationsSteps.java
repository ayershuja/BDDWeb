package StepDefinitions.Browser;

import Pages.actions.Browser.Notifications_Browser;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NotificationsSteps {

    Notifications_Browser notificationsBrowser = new Notifications_Browser();

    @Then("user click on the bell icon")
    public void click_bell_icon() {
        notificationsBrowser.BellIconIsClicked();
    }

    @Then("user click on Toggle button of balance")
    public void click_toggle_btn() {
        notificationsBrowser.ClickToggleBtn();
    }

    @Then("user click on Toggle button of Debits and Credits")
    public void click_Credit_toggle_btn() {
        notificationsBrowser.click_Credit_toggle_btn();
    }

    @Then("user verify the notifications")
    public void see_notifications() {
        notificationsBrowser.NotificationsHeadingIsDisplayed();
    }

    @Then("user see the No Notification Image")
    public void see_no_notifications_img() {
        notificationsBrowser.NoNotificationsImageIsDisplayed();
    }

    @Then("user click on the settings icon")
    public void click_setting_icon() {
        notificationsBrowser.SettingsIconIsClicked();
    }

    @Then("user is able to see account names as {string} account num as {string}")
    public void acc_num_across_accName(String value, String value1) {
        notificationsBrowser.ElementIsDisplayedAcross(value, value1);
    }

    @Then("user is able to see account names as {string} account balance as {string}")
    public void acc_bal_across_accName(String value, String value1) {
        notificationsBrowser.AccountBalanceIsDisplayedAcross(value, value1);
    }

    @Then("user is able to see Manage Notifications Header")
    public void elementDispl() {
        notificationsBrowser.ElementIsDisplay();
    }

    @Then("user is able to see Current Accounts")
    public void CurrentAccounts_Disp() {
        notificationsBrowser.CurrentAccountsDisp();
    }

    @Then("user is able to see Savings Accounts")
    public void SavingsAccounts_Disp() {
        notificationsBrowser.SavingsAccountsDisp();
    }

    @Then("user click on Edit button of manage notification")
    public void EditBtnClick() {
        notificationsBrowser.Edit_Btn_Click();
    }

    @Then("user clear lower than input field")
    public void Clear_Input_Field() {
        notificationsBrowser.ClearInputField();
    }

    @Then("user clicks on accept button in notification details page")
    public void Click_Accept_Btn() {
        notificationsBrowser.ClickAcceptBtn();
    }

    @Then("user enters {string} amount in the lower than input field")
    public void enterAmountInField(String amount) {
        notificationsBrowser.enterAmount(amount);
    }

    @Then("user is able to see symbol as {string} amount as {string}")
    public void LowerThanSymbolAndAmount(String symbol, String amount) {
        notificationsBrowser.LowerThan_Symbol_And_Amount(symbol, amount);
    }

    @Then("verify lower than input field is visible")
    public void elementDisplayed() {
        notificationsBrowser.LowerThanFieldIsDisplayed();
    }

}
