package StepDefinitions.Browser;

import Pages.actions.Browser.Message_Browser;
import io.cucumber.java.en.Then;
import org.openqa.selenium.remote.http.Message;

import java.awt.*;
import java.io.FileNotFoundException;

public class NewMessageSteps {

    Message_Browser Message = new Message_Browser();


    @Then("user select {string} from dropdown")
    public void user_select_from_dropdown(String value) {
        Message.GetValueFromDropdown(value);
    }

    @Then("user attach file")
    public void UserAttachFile() throws AWTException, FileNotFoundException {
        Message.GetAttachment();
    }

    @Then("user clicks on {string} button on footer")
    public void user_clicks_on_button_on_footer(String value) {
        Message.ClickFooterBtn(value);
    }

    @Then("user clicks on the {string} confirmation popup")
    public void user_clicks_on_button_on_confirmation(String value) {
        Message.ClickConfirmationBtn(value);
    }

    @Then("user verify {string} character on message")
    public void user_verify_character_on_message(String value) {
        Message.GetCharacterLength(value);
    }

    @Then("user is able to verify message sent on outbox as {string}")
    public void userIsAbleToVerifyMessageSentOnOutbox(String value) {
        Message.GetOutboxSubject(value);
    }

    @Then("user selects conversation where subject is {string} from drafts")
    public void SelectConversation(String value) {
        Message.SelectConversation(value);
    }

    @Then("user click on CTA button ...")
    public void userClickOnCTAButton() {
        Message.ClickCTA();
    }

    @Then("user see CTA button ...")
    public void userSeeCTAButton() {
        Message.SeeCTA();
    }

    @Then("verify and click message as {string}")
    public void verifyMessageReadUnread(String value) {
        Message.GetUnreadRead(value);
    }

    @Then("user verify Important messages have important icon visible with them")
    public void verifyImportantSign() {
        Message.GetImportantSign();
    }
}
