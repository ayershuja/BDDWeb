package StepDefinitions.Browser;

import DriverManager.Driver;
import Pages.actions.Browser.AccountManagement_Browser;
import Pages.actions.Browser.EmployeeApp_Browser;
import Pages.actions.Browser.Header_Browser;
import Pages.actions.Browser.LoginPage_Browser;
import io.cucumber.java.en.Then;

public class EmployeeAppSteps {

    EmployeeApp_Browser employeeapp_Page = new EmployeeApp_Browser();

    AccountManagement_Browser AccountManagement;
    private Object timeout;


    @Then("user able to see {string} Label")
    public void getLabelText(String value) {
        employeeapp_Page.GetLabelText(value);
    }

    @Then("user able to see {string}")

    public void input_fields(String value) {
        employeeapp_Page.inputFieldsVisible(value);
    }

    @Then("field is displaying the number of users")
    public void num_of_users() {
        employeeapp_Page.totalNumOfUserisDisplayed();
    }

    @Then("verify the Pagination is displayed")
    public void paginaton_verify() throws Exception {
        employeeapp_Page.userTableisDisplayed();
    }

    @Then("list of users with the following data is displayed")
    public void user_list() throws Exception {
        employeeapp_Page.userTableisDisplayed();
    }

    @Then("list of users with the name {string} is displayed")
    public void user_list_relative(String value) throws Exception {
        employeeapp_Page.verifyUsersDisplayed(value);
    }

    @Then("user search {string} in search bar")
    public void search_username(String value) throws Exception {
        employeeapp_Page.empAppEnterUser(value);
    }

    @Then("user clicks Find users")
    public void clickFinduser() throws Exception {
        employeeapp_Page.clickFindUserbtn();
    }

    @Then("user selects a {string} user")
    public void userSelection(String value) throws Exception {
        employeeapp_Page.clickUserToSelect(value);
    }

    @Then("Verify error message is displayed on Users screen")
    public void verifyErrorMsg() throws Exception {
        employeeapp_Page.errorMsg();
    }

    @Then("CTA to close selected user profile")
    public void btnCTASelection() throws Exception {
        employeeapp_Page.btnCTASelect();
    }

    @Then("Actions dropdown button")
    public void actionsDropdownSelection() throws Exception {
        employeeapp_Page.actionsDDLSelect();
    }

    @Then("user verify {string} is displayed")
    public void elementIsDisplayed(String value) throws Exception {
        employeeapp_Page.elementIsDisplayed(value);
    }

    @Then("user see the device details is displayed of {string}")
    public void deviceDetails(String value) throws Exception {
        employeeapp_Page.deviceDetailsDisplayed(value);
    }

    @Then("user verify {string} is not displayed")
    public void elementIsNotDisplayed(String value) throws Exception {
        employeeapp_Page.elementIsNotDisplayed(value);
    }

    @Then("user verify dropdown option {string} is displayed of {string}")
    public void dropDownOptionIsDisplayed(String value1, String value2) throws Exception {
        employeeapp_Page.dropDownOpIsDisplayed(value1, value2);
    }

    @Then("user verify dropdown option {string} is clicked of {string}")
    public void dropDownOptionIsClicked(String value1, String value2) throws Exception {
        employeeapp_Page.dropDownOpIsClicked(value1, value2);
    }

    @Then("user dropdown option {string} is clicked")
    public void dropDownOptionIsclicked(String value) throws Exception {
        employeeapp_Page.dropDownOpIsClicked(value);
    }

    @Then("user verify {string} displayed")
    public void elementDisplayed(String value) throws Exception {
        employeeapp_Page.elementDisplayed(value);
    }

    @Then("user is able to see the {string}")
    public void deviceNameDisplayed(String value) throws Exception {
        employeeapp_Page.deviceNameIsDisplayed(value);
    }

    @Then("user see {string} and {string}")
    public void deviceTypeDisplayed(String value1, String value2) throws Exception {
        employeeapp_Page.deviceTypeIsDisplayed(value1, value2);
    }

    @Then("user see {string} and {string} is displayed")
    public void suspendedBtnDisplayed(String value1, String value2) throws Exception {
        employeeapp_Page.suspendedIsDisplayed(value1, value2);
    }

    @Then("user click manage {string} btn")
    public void manageBtnDisplayed(String value) throws Exception {
        employeeapp_Page.managebBtnIsClicked(value);
    }

    @Then("user see manage {string} btn")
    public void manageBtnisDisplayed(String value) throws Exception {
        employeeapp_Page.managebBtnIsDisplayed(value);
    }

    @Then("user Input Edit {string} in {string}")
    public void editFamilyName(String value, String elementName) throws Exception {
        employeeapp_Page.inputEditFullName(value, elementName);
    }

    @Then("user verify {string} is clicked")
    public void elementIsClick(String value) throws Exception {
        employeeapp_Page.elementisClicked(value);
    }

    @Then("user clicks on three dots")
    public void threeDotsClick() throws Exception {
        employeeapp_Page.threeDotsClicked();
    }

    @Then("user clicks on {string} Manage button")
    public void user_clicks_on_Manage_button(String value) throws Exception {
        employeeapp_Page.clickManageBtn(value);
    }

    @Then("user verify Edit full name")
    public void user_verify_Edit_full_name() throws Exception {
        employeeapp_Page.verifyEditFullName();
    }

    @Then("user verify the window gets collapsed")
    public void windowCollapsedAfterEdit() throws Exception {
        employeeapp_Page.windowCollapsed();
    }

    @Then("verify the notification displayed")
    public void notificationDisplayed() throws Exception {
        employeeapp_Page.notificationDisplayed();
    }

    @Then("verify Notification {string}")
    public void notificationDisplayed1(String value) throws Exception {
        employeeapp_Page.notificationDisplayed1(value);
    }

    @Then("user verify Given name with empty input text field")
    public void verify_Given_name_with_empty_input_text_field() throws Exception {
        employeeapp_Page.verifyGivenName();
    }

    @Then("user verify {string} with empty input text field")
    public void verify_empty_input_text_field(String value) throws Exception {
        employeeapp_Page.verifyInputField(value);
    }

    @Then("user verify Family name with empty input text field")
    public void verify_Family_name_with_empty_input_text_field() throws Exception {
        employeeapp_Page.verifyFamilyName();
    }

    @Then("user verify Save changes button is displayed")
    public void user_verify_Save_changes_button() throws Exception {
        employeeapp_Page.saveBtnIsDisplayed();
    }

    @Then("user clicks Save changes button")
    public void user_clicks_Save_changes_button() throws Exception {
        employeeapp_Page.saveBtn();
    }

    @Then("user click on {string} btn")
    public void user_clicks_Cancel_button(String value) throws Exception {
        employeeapp_Page.cancelBtn(value);
    }

    @Then("user verify Cancel Button")
    public void user_verify_Cancel_Button() throws Exception {
        employeeapp_Page.cancelBtnIsDisplayed();
    }

    @Then("user verify {string} Button")
    public void user_verify_Button(String value) throws Exception {
        employeeapp_Page.btnIsDisplayed(value);
    }

    @Then("user see on button type {string}")
    public void click_suspend_Button(String value) throws Exception {
        employeeapp_Page.suspendBtn(value);
    }

    @Then("user click on button type {string}")
    public void see_special_Button(String value) throws Exception {
        employeeapp_Page.specialBtn(value);
    }

    @Then("user is able to see result of search")
    public void user_verify_search_result() throws Exception {
        employeeapp_Page.searchResult();
    }

}
