package StepDefinitions.Browser;

import Pages.actions.Browser.InternalTransfer_Browser;
import io.cucumber.java.en.Then;

public class InternalTransferSteps {


    InternalTransfer_Browser ITransfer = new InternalTransfer_Browser();

    @Then("user click on Transfer from field")
    public void user_click_on_transfer_from_field() {
        ITransfer.ClickTransferFrom();
    }

    @Then("user verify the fields gets cleared")
    public void VerifyFieldsGetsCleared() {
        ITransfer.VerifyFieldsGetsClear();
    }
    @Then("user verify details for {string}")
    public void user_verify_details_From_account (String value) {
        ITransfer.VerifyDetailsFromAccount(value);
    }
    @Then("user verify details for Amount {string}")
    public void user_verify_details_amount(String value) {
        ITransfer.VerifyDetailsAmount(value);
    }

    @Then("user Verify the Currency Unit field gets fixed")
    public void user_Verify_Currency_Unit_field_gets_fixed() throws Exception {
        ITransfer.CurrencyUnitGetsFixed();
    }

    @Then("user Verify the currency drop down values gets updated as {string} and {string}")
    public void currency_drop_down_values_gets_updated(String value1, String value2) {
        ITransfer.CurrencyUnitDropDown(value1, value2);
    }

    @Then("user select account as {string}")
    public void user_select_account_as(String value) {
        ITransfer.ClickOnFromTransferAccount(value);
    }

    @Then("user verify the {string} message")
    public void verify_success_msg(String value) {
        ITransfer.VerifySuccessMsg(value);
    }
    @Then("user verify the {string}")
    public void verify_success(String value) {
        ITransfer.VerifySuccessMsg(value);
    }
    @Then("user click on Transfer to field")
    public void user_click_on_transfer_to_field() {
        ITransfer.ClickTransferTo();
    }

    @Then("user see the blank From and To acc fields")
    public void user_see_blank_From_and_To_acc_fields() {
        ITransfer.FromAndTOFieldsCLear();
    }

    @Then("verify the Sight Deposit is disabled")
    public void verify_the_saving_account_is_disabled() {
        ITransfer.VerifyDDElementDisabled();
    }

    @Then("The user is unable to select same account for To field as it is  greyed out")
    public void the_user_is_unable_to_select_same_account_for_to_field_as_it_is_greyed_out() {
        ITransfer.SelectHeaderMenu();
    }

    @Then("user is able to view {string} in integer field")
    public void user_is_able_to_view_in_integer_field(String string) {
        ITransfer.SelectHeaderMenu();
    }

    @Then("user is able to view {string} in decimal field")
    public void user_is_able_to_view_in_decimal_field(String string) {
        ITransfer.SelectHeaderMenu();
    }

    @Then("user should see the currency field locked and it should not be editable")
    public void user_should_see_the_currency_field_locked_and_it_should_not_be_editable() {
        ITransfer.SelectHeaderMenu();
    }

    @Then("user select {string} from Currency")
    public void user_select_from_currency(String string) {
        ITransfer.SelectHeaderMenu();
    }

    @Then("user enter additional note as {string}")
    public void user_enter_additional_note_as(String string) {
        ITransfer.SelectHeaderMenu();
    }

    @Then("user should be navigated to the {string} screen")
    public void user_should_be_navigated_to_the_screen(String string) {
        ITransfer.SelectHeaderMenu();
    }

    @Then("selected or entered information should be cleared or removed")
    public void selected_or_entered_information_should_be_cleared_or_removed() {
        ITransfer.SelectHeaderMenu();
    }

    @Then("verify {string} selector is displayed")
    public void verify_selector_is_displayed(String string) {
        ITransfer.SelectHeaderMenu();
    }

    @Then("verify {string} is displayed")
    public void verify_is_displayed(String string) {
        ITransfer.SelectHeaderMenu();
    }

    @Then("An error message should be highlighted in Red {string}")
    public void an_error_message_should_be_highlighted_in_red_funding_account_balance_is_less_than_payment_amount() {
        ITransfer.SelectHeaderMenu();
    }

    @Then("user click on {string} button on payment")
    public void userClickOnButtonOnPayment(String value) {
        ITransfer.SelectHeaderMenu();
    }

}
