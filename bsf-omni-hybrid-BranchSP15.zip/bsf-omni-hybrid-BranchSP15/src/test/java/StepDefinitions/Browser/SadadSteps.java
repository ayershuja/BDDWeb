package StepDefinitions.Browser;

import Pages.actions.Browser.Sadad_Browser;
import io.cucumber.java.en.Then;

public class SadadSteps {


    Sadad_Browser Sadad_browser = new Sadad_Browser();

    @Then("user verifies {string} option on dropdown")
    public void user_click_on_dropdown(String value) {

        Sadad_browser.verifyAddNewDropdownList(value);
    }

    @Then("user is able to view dropdown")
    public void AddNewDropDownView() {

        Sadad_browser.GetAddNewDropdownView();
    }


    @Then("user click on search field and enter {string}")
    public void UserClickOnSearchField(String value) {
        Sadad_browser.ClickSearchField(value);
    }

    @Then("user clicks on {string} from Add New Dropdown")
    public void user_clicks_on_from_add_new_dropdown(String value) {
        Sadad_browser.GetDropdownValueSelect(value);
    }

    @Then("user is able to view {string} with Search Field")
    public void user_is_able_to_view_with_search_field(String value) {
        Sadad_browser.GetValueWithField(value);
    }

    @Then("user is able to view filter button")
    public void user_is_able_to_view_button() {
        Sadad_browser.GetValueWithField();
    }

    @Then("user is able to see the input of {string}")
    public void user_able_to_see_the_input(String value) {
        Sadad_browser.GetViewInputOfLabel(value);

    }

    @Then("user is able to view disable button")
    public void user_is_able_to_view_disable_button() {
        Sadad_browser.GetBtnDisable();
    }

    @Then("user click on billar option")
    public void user_click_on_billar_option() {
        Sadad_browser.SelectBillerField();
    }

    @Then("user verify input type of {string} is {string}")
    public void user_verify_input_type_of_is(String value, String type) {
        Sadad_browser.VerifyInputType(value, type);
    }

    @Then("user verify helper text of {string} is {string} with maximum length is {string}")
    public void user_verify_helper_text_of_is_with_maximum_length_is(String value, String placeholder, String length) {
        Sadad_browser.VerifyHelperText(value, placeholder, length);
    }

    @Then("user enter {string} in {string}")
    public void user_enter_in(String value, String field) {
        Sadad_browser.InputText(value, field);
    }

    @Then("user clear {string} field")
    public void user_clear_field(String field) {
        Sadad_browser.ClearField(field);
    }

    @Then("user click on Biller option")
    public void user_clickOnBiller() {
        Sadad_browser.SelectBiller();
    }

    @Then("user select {string} from Biller option")
    public void user_SelectValueOnBiller(String value) {
        Sadad_browser.SelectBillerValue(value);
    }

    @Then("user select biller from dropdown")
    public void user_SelctBiller() {
        Sadad_browser.SelectBillerValueDropdown();
    }

    @Then("user click on Continue Button")
    public void userClickOnContinueButton() {
        Sadad_browser.GetContinueBtn();
    }

    @Then("user click on detail button on Sadad of last bill")
    public void ClickOnDetailButtonOnSadad() {
        Sadad_browser.GetLastBill();
    }

    @Then("user click on {string} from Bill")
    public void ClickOnDetailButtonOnSadad(String value) {
        Sadad_browser.DeleteBill(value);
    }

    @Then("verify {string} popup should be displayed")
    public void verify_popup_should_be_displayed(String value) {
        Sadad_browser.GetRemoveBillPopup(value);
    }
    @Then("user verifies description available on Popup as {string}")
    public void user_verifies_description_available_on_popup(String value) {
        Sadad_browser.GetRemoveBillPopupDesc(value);
    }
    @Then("user click on {string} button on Remove Bill")
    public void user_click_on_button_on_remove_bill(String value) {
        Sadad_browser.GetRemoveBillBtn(value);
    }

    @Then("user verifies {string} header is displayed")
    public void user_verifies_header_is_displayed(String value) {
        Sadad_browser.GetHeadervalue(value);
    }
    @Then("user verifies CTA as {string} ,{string} is displayed")
    public void user_verifies_cta_as_is_displayed(String CTA1, String CTA2) {
        Sadad_browser.GetCTABtn(CTA1, CTA2);
    }
    @Then("user is able to view Search bar")
    public void user_is_able_to_view_search_bar() {
        Sadad_browser.GetSearchTextBox();
    }
    @Then("user is able to view Bill Name")
    public void user_is_able_to_view_bill_name() {
        Sadad_browser.VerifyBillName();
    }
    @Then("user is able to view Bill Number")
    public void user_is_able_to_view_bill_number() {
        Sadad_browser.VerifyBillNumber();
    }
    @Then("user is able to view Bill Status")
    public void user_is_able_to_view_bill_status() {
        Sadad_browser.VerifyBillStatus();
    }
    @Then("user is able to view due date")
    public void user_is_able_to_view_due_date() {
        Sadad_browser.VerifyExpiryDate();
    }
    @Then("user is able to view Bill amount")
    public void user_is_able_to_view_bill_amount() {
        Sadad_browser.VerifyBillAmount();
    }
    @Then("user is able to view Details CTA")
    public void user_is_able_to_view_details_cta() {
        Sadad_browser.VerifyDetailCTA();
    }

    @Then("user click on back windows")
    public void userClickOnBackWindows() {
        Sadad_browser.NavigateBack();
    }



}
