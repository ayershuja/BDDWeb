package StepDefinitions.Browser;

import Pages.actions.Browser.AccountManagement_Browser;
import Pages.actions.Browser.LoginPage_Browser;
import DriverManager.Driver;
import Pages.actions.Mobile.LoginPage_Mobile;
import Pages.actions.Mobile.MyProductsPage_Mobile;
import StepDefinitions.RunnerInfo;
import Utils.PropertiesOperations;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;


public class LoginSteps {

    LoginPage_Browser browserloginPage;
    LoginPage_Mobile loginPage_mobile;


    AccountManagement_Browser AccountManagement;
    private Object timeout;


    @Given("the browser is open")
    public void UAT_browser_is_open() throws Exception {
        String env = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("deviceType");
        String URL = null;
        System.out.println("ENV:" + env);
        if (env == null) {
            //if(RunnerInfo.getName().toLowerCase().contains("browser")){
            env = "browser";

        }
        URL = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("url");
        if (URL == null) {
            URL = RunnerInfo.getURL().toLowerCase();
            //}
        }
        Driver driver = new Driver();
        driver.setUp(env);
        browserloginPage = new LoginPage_Browser();
        browserloginPage.openURL1(URL);
        if (driver.driver.get(env) == null) {
            System.out.println("Driver is: " + driver.driver.get(env));
            System.out.println("loginPage Object is: " + browserloginPage);
        }
    }

    @Given("Open the browser")
    public void open_browser() throws Exception {
        browserloginPage = new LoginPage_Browser();
		browserloginPage.openURL();
        Driver driver = new Driver();
        if (driver.driver.get("browser") == null) {
            System.out.println("Driver is: " + driver.driver.get("browser"));
//            System.out.println("loginPage Object is: " + browserloginPage);
        }
    }

    @Given("Open the {string}")
    public void open_url(String url) throws Exception {
        String env = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("device");
        String URL = null;
        System.out.println("ENV:" + env);
        if (env == null) {
            //if(RunnerInfo.getName().toLowerCase().contains("browser")){
            env = "browser";
        }
        Driver driver = new Driver();
        driver.setUp(env);
        browserloginPage = new LoginPage_Browser();
        browserloginPage.openURL1(url);
        if (driver.driver.get(env) == null) {
            System.out.println("Driver is: " + driver.driver.get(env));
            System.out.println("loginPage Object is: " + browserloginPage);
        }
    }
//	@Given("the application is open")
//	public void opening_app() {
//		loginPage_mobile = new LoginPage_Mobile();
//		String env = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("device");
//		System.out.println("ENV:"+env);
//		if(env ==  null){
//			if(RunnerInfo.getName().toLowerCase().contains("android")){
//				env = "Android";
//			}
//			else if (RunnerInfo.getName().toLowerCase().contains("browserstack-ios")){
//				env = "browserstack-ios";
//			}
//			else if (RunnerInfo.getName().toLowerCase().contains("ios")){
//				env = "Ios";
//			}
//			else{
//				env= "web";
//			}
//		}
//		System.out.println("Before Setup Started");
//		try {
//			Driver.setUp(env);
//		} catch (Exception e) {
//			System.out.println("Cause: " + e.getCause());
//			System.out.println("Message: " + e.getMessage());
//			e.printStackTrace();
//		}
//		System.out.println("Application Started");
//	}

    @Then("close mobile application")
    public void closeMobileApplication() {
        Driver driver = new Driver();
        driver.stopAppium();
    }

    @Then("close browser application")
    public void closeBrowserApplication() {
        Driver driver = new Driver();
        driver.stopBrowserDriver();
    }

    @Then("user inputs the username")
    public void user_input_the_username() throws Exception {
        browserloginPage.enterUsername();
    }

    @Then("user inputs the password: {string}")
    public void user_inputs_the_password(String password) {
        browserloginPage.enterPassword(password);
    }

    @Then("user clicks on signIn Button")
    public void user_clicks_on_signIn_Button(String value) {
        browserloginPage.ClickNextButton(value);
    }

    @Then("user input username")
    public void user_input_username() throws Exception {

        browserloginPage.enterUsername();
    }

    @Then("user input username2")
    public void user_input_username2() throws Exception {

        browserloginPage.enterUsername2();
    }

    @Then("user input password2")
    public void user_input_password2() throws Exception {

        browserloginPage.enterPassword2();
    }

    @Then("user input username3")
    public void user_input_username3() throws Exception {

        browserloginPage.enterUsername3();
    }

    @Then("user input username5")
    public void user_input_username5() throws Exception {

        browserloginPage.enterUsername5();
    }

    @Then("user input password5")
    public void user_input_password5() throws Exception {

        browserloginPage.enterPassword5();
    }

    @Then("user input {string}")
    public void input_username(String username) throws Exception {

        browserloginPage.enterUsernameEmployeeApp(username);
    }

    @Then("user input retail {string}")
    public void input_username_retail(String username) throws Exception {

        browserloginPage.enterUsernameRetailApp(username);
    }

    @Then("user input username4")
    public void user_input_username4() throws Exception {

        browserloginPage.enterUsername4();
    }

    @Then("user click on {string} button")
    public void user_click_on(String name) {
        browserloginPage.ClickNextButton(name);

    }

    @Then("user input password : {string}")
    public void user_enter_password(String pass) {
        browserloginPage.enterPassword(pass);
    }

    @Then("user input password {string}")
    public void user_enterpassword(String pass) throws Exception {
        browserloginPage.enterPasswordInTextBox(pass);
    }

    @Then("user clicks {string} button")
    public void user_clicks_login(String pass) {
        browserloginPage.clickLogin(pass);
    }

    @Then("user able to see the {string} screen")
    public void password_screen(String value) {
        browserloginPage.GetText(value);
    }

    @Then("user able to see {string} screen")
    public void getTitle(String value) {
        browserloginPage.GetMyHeadingText(value);
    }

    @Then("user click on Language selection dropdown")
    public void MultiLangDropdownClick() {
        browserloginPage.GetLanguageClick();
    }

    @Then("user able to select {string} Language")
    public void languageClick(String value) {
        browserloginPage.ClickLanguage(value);
    }

    @Then("login Screen is displayed in {string} Language with page title {string}")
    public void LoginScreenDisplayed(String value, String title) {
        browserloginPage.GetLanguageNameTitle(value, title);
    }

    @Then("message should be displayed {string}")
    public void LoginScreenDisplayed(String name) throws Exception {
        browserloginPage.GetMessage(name);
    }

    @Then("message should be displayed {string} and showing the count {string}")
    public void ErrorMessageAttempt(String msg, String count) throws Exception {
        browserloginPage.GetErrorMessageAttempt(msg, count);
    }

    @Then("user click on show password icon")
    public void GetPasswordVisbile() {
        browserloginPage.GetPasswordVisbile();
    }

    @Then("user select {string} context")
    public void SelectContext(String value) {
        browserloginPage.SelectContext(value);
    }

    @Then("Testcase {string} is complete")
    public void theTestcaseIsComplete(String testCaseID) {
        System.out.println("TestCase " + testCaseID + " is completed");
    }

    @Then("user is able to view {string} dropdown")
    public void abletoviewdDropdown(String value ) {
        browserloginPage.GetForgetLink(value);
    }

    @Then("user click on Forgot credentials dropdown")
    public void abletowdDropdown() {
        browserloginPage.GetForgetLinkClick();
    }
}
