package StepDefinitions.Browser;

import Pages.actions.Browser.ProxyTransfer_Browser;
import io.cucumber.java.en.Then;

public class ProxyTransferSteps {

    ProxyTransfer_Browser ProxyTransfer = new ProxyTransfer_Browser();


    @Then("user verify {string} should be selected as default in Transfer Method")
    public void user_verify_should_be_selected_as_default_in_transfer_method(String value) {
        ProxyTransfer.verifyDefaultPhoneNumber(value);
    }

    @Then("user click on {string} dropdown")
    public void user_click_on_dropdown(String value) {
        ProxyTransfer.ClickTransferMethodDropdown(value);
    }

    @Then("user verify {string} in Transfer Method options")
    public void user_verify_in_transfer_method_options(String value) {
        ProxyTransfer.verifyTransferMethodDropdownList(value);
    }

    @Then("user verify Bank selection option available")
    public void user_verify_bank_selection_option_available() {
        ProxyTransfer.verifyBankOptions();
    }

    @Then("user select {string} from dropdown {string}")
    public void UserSelectFromDropdown(String value, String name) {
        ProxyTransfer.SelectOptionFromDropdown(value, name);
    }

    @Then("user verify input type of Other Purpose is {string}")
    public void user_verify_input_type_of_is(String value) {
        ProxyTransfer.verifyInputType(value);
    }

    @Then("user verify helper text of {string} is {string}")
    public void user_verify_helper_text_of_is(String value, String placeholder) {
        ProxyTransfer.VerifyHelperText(value, placeholder);
    }

    @Then("user verify maximum length of {string} is {string}")
    public void user_verify_maximum_length_of_is(String value, String length) {
        ProxyTransfer.VerifyLength(value, length);
    }

    @Then("user verify {string} field")
    public void user_verify_field(String value) {
        ProxyTransfer.VerifyAmountField(value);
    }

    @Then("user verify place holder of {string} is {string}")
    public void user_verify_place_holder_of_is(String value, String PlaceHolder) {
        ProxyTransfer.VerifyAmountPlaceHolder(value, PlaceHolder);
    }

    @Then("user verify maximum length of {string} field is {string}")
    public void user_verify_maximum_length_of_field_is(String value, String MaximumLength) {
        ProxyTransfer.VerifyMaximumLength(value, MaximumLength);
    }

    @Then("user verify place text of {string} is {string}")
    public void user_verify_placeholder_text_of_is(String value, String placeholder) {
        ProxyTransfer.VerifyNoteHelperText(value, placeholder);
    }


}
