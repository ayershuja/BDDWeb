package StepDefinitions.Browser;

import Pages.actions.Browser.Statements_Browser;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StatementSteps {

    Statements_Browser statementsBrowser = new Statements_Browser();

    @Then("verify account statement dropdown is visible")
    public void DropDownVisibility()
    {
        statementsBrowser.DropDown_Visibility();
    }

    @Then("user clicks on drop down menu to select account")
    public void ClickOnDropDown()
    {
        statementsBrowser.Click_OnDropDown();
    }

    @Then("user is able to see book date {string} and category {string}")
    public void VerifyData(String Date, String Category)
    {
        statementsBrowser.Verify_Data(Date, Category);
    }

    @Then("verify preview icon is visible")
    public void VerifyPreviewIcon()
    {
        statementsBrowser.Verify_PreviewIcon();
    }

    @Then("verify download icon is visible")
    public void VerifyDownloadIcon()
    {
        statementsBrowser.Verify_DownloadIcon();
    }

    @Then("user click on account statement filter button")
    public void ClickFilterBtn()
    {
        statementsBrowser.Click_FilterBtn();
    }

    @Then("verify date range is visible")
    public void VerifyDateRange()
    {
        statementsBrowser.Verify_DateRange();
    }

    @Then("verify category is visible")
    public void VerifyCategoryRange()
    {
        statementsBrowser.Verify_CategoryRange();
    }

    @Then("verify close button is visible")
    public void VerifyCloseBtn()
    {
        statementsBrowser.Verify_CloseBtn();
    }

    @Then("verify apply button is visible")
    public void VerifyApplyBtn()
    {
        statementsBrowser.Verify_ApplyBtn();
    }

    @Then("verify clear all is visible")
    public void VerifyClearAllBtn()
    {
        statementsBrowser.Verify_ClearAllBtn();
    }

    @Then("user click on apply")
    public void ClickOnApplytBtn()
    {
        statementsBrowser.ClickOn_ApplytBtn();
    }

    @Then("user clicks on category dropdown")
    public void ClickOnCategory()
    {
        statementsBrowser.ClickOn_Category();
    }

    @Then("user selects category")
    public void SelectCategory()
    {
        statementsBrowser.Select_Category();
    }

    @Then("user selects date")
    public void SelectDate()
    {
        statementsBrowser.Select_Date();
    }

}
