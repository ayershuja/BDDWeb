package StepDefinitions.Browser;

import Pages.actions.Browser.AccountManagement_Browser;
import Pages.actions.Browser.EmployeeApp_Browser;
import io.cucumber.java.en.Then;
import DriverManager.Driver;
import Pages.actions.Browser.AccountManagement_Browser;
import Pages.actions.Browser.DigitalSales_Browser;
import Pages.actions.Browser.Header_Browser;
import Pages.actions.Browser.LoginPage_Browser;

public class DigitalSalesSteps {
    DigitalSales_Browser digitalsales_Page = new DigitalSales_Browser();
    private Object timeout;
    @Then("user able to see image")
    public void getLabelText() throws Exception {
        digitalsales_Page.GetTheImageVerified();
    }
    @Then("user able to see text {string}")
    public void getLabelText(String txt) throws Exception {
        digitalsales_Page.GetTheTextVerified(txt);
    }
    @Then("user can see text {string}")
    public void seeText(String txt) throws Exception {
        digitalsales_Page.GetTheTextVerified(txt);
    }
    @Then("user see {string}")
    public void seeTheText(String txt) throws Exception {
        digitalsales_Page.GetTextVerified(txt);
    }
    @Then("user see National ID textbox displayed")
    public void seeTheTextbox() throws Exception {
        digitalsales_Page.TextBoxDisplayed();
    }
    @Then("user inputs {string} in National ID textbox")
    public void user_inputs_valid_national_id_Iqama_in_National_ID_textbox(String txt) throws Exception {
        digitalsales_Page.WriteText(txt);
    }
    @Then("user see the continue button")
    public void user_see_the_continue_button() throws Exception {
        digitalsales_Page.ContinueButtonDisplayed();
    }
    @Then("user click the continue button")
    public void user_click_the_continue_button() throws Exception {
        digitalsales_Page.ContinueButtonClicked();
    }
    @Then("user can logo on the footer")
    public void user_can_logo_on_footer() throws Exception {
        digitalsales_Page.LogoOnFooter();
    }

    @Then("user able to see paragraph")
    public void getParaText() throws Exception {
        digitalsales_Page.GetTheParagraphVerified();
    }
    @Then("user verify the checkbox is unchecked")
    public void VerifyCheckboxUnchecked() throws Exception {
        digitalsales_Page.CheckBoxValue();
    }
    @Then("user click the checkbox")
    public void clickCheckBox() throws Exception {
        digitalsales_Page.CheckBoxClick();
    }
    @Then("user verify the {string} btn is enabled")
    public void GetStartedBtn(String txt) throws Exception {
        digitalsales_Page.CheckBoxClick();
    }
    @Then("user click the {string} btn")
    public void GetStartedClick(String txt) throws Exception {
        digitalsales_Page.GetStartedClicked();
    }
    @Then("user able to see {string} button")
    public void getBtn(String txt) throws Exception {
        digitalsales_Page.GetTheBtnVerified(txt);
    }
    @Then("user clicks on the {string} button")
    public void clickBtn(String txt) throws Exception {
        digitalsales_Page.ClickBtn(txt);
    }
    @Then("user able to see {string} Stepper button")
    public void getStepperBtn(String txt) throws Exception {
        digitalsales_Page.GetTheStepperBtnVerified(txt);
    }
}
