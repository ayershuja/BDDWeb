package StepDefinitions.Browser;

import Pages.actions.Browser.Beneficiary_Browser;
import Pages.actions.Browser.Header_Browser;
import io.cucumber.java.en.Then;

public class BeneficiaryManagementSteps {

    Beneficiary_Browser Beneficiary = new Beneficiary_Browser();

    @Then("user is able to view Beneficiary Full Name")
    public void viewBeneficiaryFullName() {
        Beneficiary.VerifyBeneficiaryName();
    }

    @Then("user is able to view Account Number")
    public void ViewAccountNumberIban() {
        Beneficiary.VerifyAccountNumber();
    }

    @Then("user is able to view Bank Name")
    public void ViewBankName() {
        Beneficiary.VerifyBankName();
    }

    @Then("user is able to view Inactive Status")
    public void viewInactiveStatus() {
        Beneficiary.VerifyInactiveStatus();
    }

    @Then("user click on beneficiary")
    public void ClickOnBeneficiary() {
        Beneficiary.ClickFirstBeneficiary();
    }

    @Then("user is able to view full name as header in Beneficiary Detail")
    public void ViewFullNameAsHeaderInBeneficiaryDetail() {
        Beneficiary.GetFullNameAsHeading();
    }

    @Then("user is able to view Beneficiary Type in Beneficiary Detail")
    public void ViewBeneficiaryTypeInBeneficiaryDetail() {
        Beneficiary.GetBeneficiaryType();
    }

    @Then("user is able to view Full name in Beneficiary Detail")
    public void ViewFullNameInBeneficiaryDetail() {
        Beneficiary.GetBeneficiaryFullName();
    }

    @Then("user is able to view Account Number in Beneficiary Detail")
    public void ViewAccountNumberInBeneficiaryDetail() {
        Beneficiary.GetBBeneficiaryAccountNumber();
    }

    @Then("user is able to view Bank in Beneficiary Detail")
    public void ViewBankInBeneficiaryDetail() {
        Beneficiary.GetBeneficiaryBank();
    }

    @Then("user is able to view Delete button in Beneficiary Detail")
    public void ViewDeleteButtonInBeneficiaryDetail() {
        Beneficiary.GetBeneficiaryDeleteIcon();
    }

    @Then("user click on Inactive beneficiary")
    public void ClickOnInactiveBeneficiary() {
        Beneficiary.ClickInactiveStatus();
    }

    @Then("user click on Local Bank Inactive beneficiary")
    public void ClickOnLocalBankInactiveBeneficiary() {
        Beneficiary.ClickLocalInactiveStatus();
    }

    @Then("user verify Active button in Beneficiary Detail")
    public void VerifyActiveButtonInBeneficiaryDetail() {
        Beneficiary.ClickActivateBeneficiaryBtn();
    }

    @Then("user delete the beneficiary for Account number")
    public void UserDeleteBeneficiary() {
        Beneficiary.DeleteAccountNumber();
    }

    @Then("user delete the beneficiary for Local Account number")
    public void UserDeleteLocalBeneficiary() {
        Beneficiary.DeleteLocalAccountNumber();
    }

    @Then("user delete the beneficiary for BSF")
    public void UserDeleteLocalBeneficiaryBSF() {
        Beneficiary.DeleteBSFAccountNumber();
    }

    @Then("user click on Add New beneficiary")
    public void UserClickOnAddNewBeneficiary() {
        Beneficiary.ClickAddNewBeneficiary();
    }

    @Then("user select Beneficiary type as {string}")
    public void UserSelectBeneficiaryTypeAsLocal(String value) {
        Beneficiary.SelectNewBeneficiaryType(value);
    }

    @Then("user is able to see {string}")
    public void elementDisplayed(String value) {
        Beneficiary.ElementIsDisplayed(value);
    }

    @Then("user is able to see Manage Notifications")
    public void elementDispl() {
        Beneficiary.ElementIsDisplay();
    }

    @Then("user is able to see Notification details")
    public void NotificationDetailsDispl() {
        Beneficiary.NotificationDetailsHeader();
    }

    @Then("user is able to see detail {string}")
    public void detailDisplayed(String value) {
        Beneficiary.ElementDetailIsDisplayed(value);
    }

    @Then("user selects {string} from dropdown")
    public void dropDownSelection(String value) {
        Beneficiary.SelectFromDropDown(value);
    }

    @Then("user click on Toggle button of swift code")
    public void toggleButtonSwiftCode() {
        Beneficiary.ToggleBtnOff();
    }

    @Then("user search {string} in drop down search")
    public void searchDisplayed(String value) {
        Beneficiary.SearchElement(value);
    }

    @Then("user search {string} in drop down search of Bank")
    public void searchDisplayedForBank(String value) {
        Beneficiary.SearchElementForBank(value);
    }

    @Then("user verify the list of countries")
    public void countriesList() {
        Beneficiary.ContriesList();
    }

    @Then("user click {string}")
    public void elementClicked(String value) throws Exception {
        Beneficiary.ElementIsClicked(value);
    }

    @Then("user scroll to the top")
    public void scrollToTop() throws Exception {
        Beneficiary.ScrollToTop();
    }

    @Then("user click combobox for {string}")
    public void comboBoxClicked(String value) {
        Beneficiary.ComboBoxIsClicked(value);
    }
    @Then("user should be able to review {string}")
    public void user_should_be_able_to_review (String value) {
        Beneficiary.UserShouldBeAbleToReview(value);
    }

    @Then("Verify the error message is displayed {string}")
    public void errorMessageDisplayed(String value) {
        Beneficiary.ErrorMessageDisplayed(value);
    }

    @Then("user select {string} from drop down in Country of residency")
    public void dropDownSelector(String value) {
        Beneficiary.ElementSelected(value);
    }

    @Then("user verify countries and flag displayed from drop down")
    public void dropDownVerify() {
        Beneficiary.ElementVerify();
    }

    @Then("user is able to see {string} text box")
    public void textBoxDisplayed(String value) {
        Beneficiary.TextBoxIsDisplayed(value);
    }

    @Then("user input valid {string} as {string}")
    public void validValue(String value1, String value2) throws Exception {
        Beneficiary.InputValue(value1, value2);
    }

    @Then("user turn ON Banque Saudi Fransi Toggle button")
    public void UserTurnOnBanqueSaudiFransiToggleButton() throws InterruptedException {
        Beneficiary.BeneficiaryToggleBtnOn();
    }

    @Then("user enter IBAN or Account number as {string}")
    public void UserEnterIbanOrAccount_number(String value) {
        Beneficiary.InputBeneficiaryAccount(value);
    }

    @Then("user click on {string} button in Add beneficiary")
    public void UserClickOnButtonInAddBeneficiary(String value) {
        Beneficiary.BeneficiaryDetailBtn(value);
    }

    @Then("user verify {string} Field is disabled")
    public void UserVerifyFieldIsDisabled(String value) {
        Beneficiary.BeneficiaryFieldDisabled(value);
    }

    @Then("user click on {string} Button on Activate Beneficiary popup")
    public void UserClickOnButtonOnActivateBeneficiaryPopup(String value) {
        Beneficiary.BeneficiaryPopupHeaderBtn(value);
    }

    @Then("user is able to see the popup as {string} in Beneficiary")
    public void DisplayBeneficiaryPopupHeader(String value) throws InterruptedException {
        Beneficiary.BeneficiaryPopupHeaderText(value);
    }

    @Then("user click on beneficiary of Account Number {string}")
    public void UserWait(String value) throws InterruptedException {
        Beneficiary.DefinedBeneficiary(value);
    }

    @Then("user verify {string} in Beneficiary Detail")
    public void VerifyBeneficiaryDetail(String value) {
        Beneficiary.GetBeneficiaryDetailName(value);
    }

    @Then("verify Add New beneficiary button is disable")
    public void VerifyAddNewBeneficiaryButtonIsDisable() {
        Beneficiary.CheckBtn();
    }

    @Then("user is able to view {string} Field in Beneficiary Detail")
    public void UserIsAbleToViewFieldInBeneficiaryDetail(String value) {
        Beneficiary.GetFieldBeneficiaries(value);
    }

    @Then("system should not allow user to enter alphanumeric characters")
    public void SystemShouldNotAllowUserToEnterAlphanumericCharacters() {
        Beneficiary.InputInvalidBeneficiaryAccount();
    }

    @Then("user enter alphanumeric value {string} in full name")
    public void userEnterAlphanumericValueInFullName(String value) {
        Beneficiary.GetAlphanumericValue(value);
    }

    @Then("{string} field should show error as {string}")
    public void fieldShouldShowErrorAs(String name, String value) {
        Beneficiary.GetAlertMessage(name, value);
    }

    @Then("user should be navigated to Add Beneficiary Form")
    public void navigatedToAddBeneficiaryForm() {
        Beneficiary.GetBeneficiaryForm();
    }

    @Then("user input {string} in full name for Local beneficiary")
    public void InputFullName(String value) {
        Beneficiary.InputBFullName(value);
    }

    @Then("user verify {string} on Add beneficiary")
    public void VerifyFieldOnAddBeneficiary(String value) {
        Beneficiary.GetAddBeneficiaryFieldName(value);
    }

    @Then("user verify toggle button default to off")
    public void VerifyToggleButtonDefaultToOff() {
        Beneficiary.ToggleButtonDefault();
    }

    @Then("user click on active beneficiary")
    public void ClickOnActiveBeneficiary() {
        Beneficiary.ClickActiveStatus();
    }

    @Then("verify user icon is displayed")
    public void verify_user_icon_is_displayed() {
        Beneficiary.DisplayBeniIcon();
    }

    @Then("verify name is displayed")
    public void verify_name_is_displayed() {
        Beneficiary.DisplayBeniFullName();
    }

    @Then("verify account number is displayed")
    public void verify_account_number_is_displayed() {
        Beneficiary.DisplayBeneficiaryaccountNumber();
    }

    @Then("verify bank is displayed")
    public void verify_bank_is_displayed() {
        Beneficiary.DisplayBeneficiarybankName();
    }

    @Then("verify inactive is displayed")
    public void verify_inactive_is_displayed() {
        Beneficiary.DisplayBeneficiaryinactiveIcon();
    }

    @Then("user delete the beneficiary for Account number-BSF")
    public void UserDeleteBeneficiaryBSF() {
        Beneficiary.DeleteAccountNumberBSF();
    }

    @Then("user delete the beneficiary for Account number-KSA")
    public void UserDeleteBeneficiaryKSA() {
        Beneficiary.DeleteAccountNumberBSF();
    }

    @Then("user is able to view Beneficiary type as {string}")
    public void UserIsAbleToViewBeneficiaryTypeAs(String value) {
        Beneficiary.GetBeniType(value);
    }

    @Then("verify {string} is displayed in Beneficiary Detail")
    public void VerifyBeniDetail(String value) {
        Beneficiary.GetBeniDetail(value);
    }

    @Then("user search {string} in Beneficiaries Search Text Box")
    public void user_search_in_beneficiaries_search_text_box(String value) {
        Beneficiary.SearchElementBSF(value);

    }
    @Then("user is able to view result of {string}")
    public void user_is_able_to_view_result_of(String value) {

    }


}
