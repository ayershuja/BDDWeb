package StepDefinitions.Browser;

import Pages.actions.Browser.Header_Browser;
import io.cucumber.java.en.Then;

public class HeaderSteps {

    Header_Browser Header = new Header_Browser();

    @Then("user click on {string} Header")
    public void click_saving_account(String value) {
        Header.SelectHeaderMenu(value);
    }

    @Then("verify test case {string} is completed")
    public void verifyTestCaseCompleted(String value) {
        Header.VerifyTestCase(value);
    }

    @Then("user clicks on {string}")
    public void click_self_service(String value) {
        Header.SelectFromMenu(value);
    }
}
