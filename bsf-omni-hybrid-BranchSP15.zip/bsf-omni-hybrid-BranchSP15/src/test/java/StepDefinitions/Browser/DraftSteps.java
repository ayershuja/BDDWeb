package StepDefinitions.Browser;

import Pages.actions.Browser.Message_Browser;
import io.cucumber.java.en.Then;

public class DraftSteps {

    Message_Browser Message = new Message_Browser();

    @Then("user click on three dots at header")
    public void click_saving_account() {
        Message.ClickOnThreeDots();
    }

    @Then("user select {string} conversation from outbox")
    public void first_conversation_outbox(String value) {
        Message.FirstCoversationOutboxCheckboxClick(value);
    }

    @Then("user is able to see read unread toggle button")
    public void read_unread_toggle_button() {
        Message.ReadUnreadToggleButton();
    }

    @Then("user clicks read unread toggle button")
    public void read_unread_toggle_button_clicked() {
        Message.ReadUnreadToggleButtonClicked();
    }

    @Then("Verify the message gets unread status")
    public void Verify_message_unread_status() {
        Message.VerifyMessageGetsUnreadStatus();
    }

    @Then("user is able to select the conversation")
    public void select_conversation() {
        Message.SelectConversation();
    }

    @Then("user click on {string} screen")
    public void user_click_on_screen(String value) {
        Message.ClickOnMoreScreen(value);
    }

    @Then("user see {string} option on dropdown")
    public void user_see_options_screen(String value) {
        Message.SeeDropDownOptions(value);
    }

    @Then("user clicks on {string} button")
    public void click_Btn(String value) {
        Message.ClickBtn(value);
    }
    @Then("user clicks on Delete button")
    public void click_Btn() {
        Message.ClickBtnDelete();
    }

    @Then("user clicks on {string} button on message detail")
    public void click_Btnmessagedetail(String value) {
        Message.SendButtonSend(value);
    }

    @Then("user see {string} button")
    public void see_Btn(String value) {
        Message.SeeBtn(value);
    }

    @Then("user is able to see the popup as {string}")
    public void user_viewable_popupName(String value) {
        Message.PopupScreenName(value);
    }

    @Then("user enter the Subject as {string}")
    public void enter_subject(String value) {
        Message.EnterMessageSubject(value);
    }

    @Then("user enter the Message as {string}")
    public void enter_message(String value) {
        Message.EnterMessage(value);
    }

    @Then("user enter some text in message as {string}")
    public void enter_txt_message(String value) {
        Message.EnterTextMessage(value);
    }

    @Then("user attach some pdf file")
    public void user_attach_some_pdf_file() {
        // Write code here that turns the phrase above into concrete actions
        throw new io.cucumber.java.PendingException();
    }

    @Then("user clicks on {string} button over discard popup")
    public void user_click_on_on_new_message_screen(String value) {
        Message.DiscardBtn(value);
    }

    @Then("user is able to view {string} button in header")
    public void userIsAbleToViewButtonInHeader(String value) {
        Message.VerifyHeaderBtn(value);
    }

    @Then("user is able to three tabs as {string},{string}&{string}")
    public void userIsAbleToThreeTabsAs(String value, String name, String label) {
        Message.VerifyTabs(value, name, label);
    }

    @Then("user is able to click on {string} tab")
    public void UserIsAbleToClickOnTab(String value) {
        Message.ClickTab(value);
    }

    @Then("user verify the {string} is default tab")
    public void UserIsAbleToSeeTab(String value) {
        Message.SeeTab(value);
    }

    @Then("user is view message as {string}")
    public void user_is_view_message_as(String message) {
        Message.MessageVerbiage(message);
    }

    @Then("user verify message as {string}")
    public void userVerifyMessageAs(String message) {
        Message.GetTransactionMessage(message);
    }

    @Then("user click on refresh button on message screen")
    public void userClickOnRefreshButtonOnMessageScreen() {
        Message.ClickRefreshBtn();
    }

    @Then("user clicks refresh button on Draft tab")
    public void userClickOnRefreshButtonOnDraftsTab() {
        Message.ClickRefreshBtnOnDrafts();
    }

    @Then("user is able to see the message")
    public void userViewMessage() {
        Message.ViewMessages();
    }

    @Then("user is able to see more messages")
    public void userViewMoreMessage() {
        Message.ViewMoreMessages();
    }

    @Then("user select all message")
    public void userSelectAllMessage() {
        Message.SelectAllMessages();

    }

    @Then("user delete the messages")
    public void userDeleteMessages() {
        Message.DeleteMessages();
    }

    @Then("user should see the details in pop up")
    public void details_in_pop_up() {
        Message.DetailsOffPopup();
    }

    @Then("user see {string} the pop up")
    public void clickBtnPopUp(String value) {
        Message.SeeBtnPopUp(value);
    }

    @Then("user clicks {string} the pop up")
    public void seeBtnPopUp(String value) {
        Message.clickBtnPopUp(value);
    }

    @Then("user see the pop window {string}")
    public void SeeWarning(String value) {
        Message.SeeWarningPopUp(value);
    }

    @Then("user is able to view Outbox messages")
    public void user_is_able_to_view_outbox_messages() {
        Message.GetOutBoxDisplay();
    }
    @Then("user click on {int} message")
    public void user_click_on_first_message(int value) {
        Message.ClickFirstMessage(value);
    }
    @Then("user is able to view inbox panel")
    public void user_is_able_to_view_inbox_panel() {
        Message.ClickFirstMessageinboxPanel();
    }
    @Then("user click on reply button")
    public void user_click_on_reply_button() {
        Message.ReplyButtonClick();
    }

    @Then("user select inbox message to delete")
    public void user_select_inbox_message_to_delete() {
        Message.SelectCheckBox();
    }
    @Then("user click on delete icon on message menu")
    public void user_click_on_delete_icon_on_message_menu() {
        Message.DeleteButtn();
    }
    @Then("user click on delete icon on outbox menu")
    public void user_click_on_delete_icon_on_outbox_menu() {
        Message.DeleteButtnOut();
    }

}
