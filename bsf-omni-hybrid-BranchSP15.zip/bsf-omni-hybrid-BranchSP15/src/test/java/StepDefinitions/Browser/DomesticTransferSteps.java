package StepDefinitions.Browser;

import Pages.actions.Browser.Domestic_Transfer;
import io.cucumber.java.en.Then;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DomesticTransferSteps {


    Domestic_Transfer DomesticTransfer = new Domestic_Transfer();

    @Then("user wait for Transfer fields to appear")
    public void click_saving_account() {
        DomesticTransfer.ClickTransferTo();
    }

    @Then("verify user is able to see Account alias of {string}")
    public void VerifyUserIsAbleToSeeAccountAlias(String value) {
        DomesticTransfer.GetAccountAlias(value);
    }

    @Then("verify user is able to see Available balance label of {string}")
    public void VerifyUserIsAbleToSeeAvailableBalanceLabel(String value) {
        DomesticTransfer.GetAvailableBalanceLabel(value);
    }

    @Then("verify user is able to see Available Balance currency of {string}")
    public void VerifyUserIsAbleToSeeAvailableBalanceCurrency(String value) {
        DomesticTransfer.GetSymbolDisplayed(value);
    }

    @Then("user select {string} from purpose of transfer dropdown")
    public void dropDownPurpose(String value) {
        DomesticTransfer.DropdownPurpose(value);
    }

    @Then("user writes {string} in purpose field")
    public void otherPurposeField(String value) {
        DomesticTransfer.OtherPurposeField(value);
    }
    @Then("user clicks purpose field")
    public void clickOtherPurposeField() {
        DomesticTransfer.ClicksOtherPurposeField();
    }

    @Then("verify user is able to see Available Amount of {string} to {string}")
    public void verifyUserIsAbleToSeeAvailableAmount(String value, String amount) {
        DomesticTransfer.GetAmount(value, amount);
    }

    @Then("verify user is able to see Beneficiary Name of {string}")
    public void verifyUserIsAbleToSeeAvailableAmount(String value) {
        DomesticTransfer.GetBeneficiaryName(value);
    }

    @Then("verify user is able to see Beneficiary Account number of {string}")
    public void verifyUserIsAbleToSeeBeneficiaryAccountNumber(String value) {
        DomesticTransfer.BeneficiaryAccountNumber(value);
    }

    @Then("user write {string} in amount field")
    public void user_inputs_in_fields(String value) {
        DomesticTransfer.UserInputsAmount(value);
    }

    @Then("user clicks amount")
    public void user_clicks_on_amount() {
        DomesticTransfer.UserClicksAmountField();
    }

    @Then("User selects the account with {string}")
    public void user_selects_the_account(String value) throws Exception {
        DomesticTransfer.UserSelectsAccount(value);
    }
    @Then("User selects the To account with {string}")
    public void user_selects_the_To_account(String value) throws Exception {
        DomesticTransfer.UserSelectsToAccount(value);
    }

    @Then("user Enter Amount {string}")
    public void user_enter_amount(String value) {
        DomesticTransfer.USerEnterAmount(value);
    }
    @Then("user Verify Amount is {string}")
    public void user_verify_amount(String value) {
        DomesticTransfer.USerVerifyAmount(value);
    }
    @Then("user write in Note {string}")
    public void user_write_Note(String value) {
        DomesticTransfer.UserWritesNote(value);
    }
    @Then("user able to see the {string}")
    public void UserIsOn_Screen(String value) {
        DomesticTransfer.UserIsOnScreen(value);
    }
    @Then("user can not see the {string}")
    public void UserIsNotOn_Screen(String value) {
        DomesticTransfer.UserIsNotOnScreen(value);
    }
    @Then("user clicks the btn {string}")
    public void UserClicksBtn(String value) {
        DomesticTransfer.UserClicksOnBtn(value);
    }

    @Then("user See the default currency unit is {string}")
    public void user_See_the_currency_unit(String value) {
        DomesticTransfer.USerSeeCurrencyUnit(value);
    }

    @Then("user see the Error {string}")
    public void user_see_the_Error(String value) {
        DomesticTransfer.ErrorDisplayed(value);
    }

    @Then("verify user is able to see Beneficiary Bank of {string}")
    public void VerifyUserIsAbleToSeeBeneficiaryBank(String value) {
        DomesticTransfer.BeneficiaryBankName(value);
    }

    @Then("User clicks on {string}")
    public void click_element(String value) throws Exception {
        DomesticTransfer.ElementGetsClicked(value);
    }

    @Then("wait for {int} seconds")
    public void waitForSeconds(int time) throws InterruptedException {
        Thread.sleep(time * 1000L);
    }
}
