package StepDefinitions.Browser;

import Pages.actions.Browser.Beneficiary_Browser;
import Pages.actions.Browser.CaptureTransferDetails_Browser;
import io.cucumber.java.en.Then;

public class CaptureTransferDetailsSteps {

    CaptureTransferDetails_Browser CaptureTransferDetail = new CaptureTransferDetails_Browser();

    @Then("verify account {string} is selected")
    public void VerifyAccountSelected(String AccountName) {
        CaptureTransferDetail.verifyAccountSelected(AccountName);
    }

    @Then("user enter {string} in {string} field")
    public void EnterValueInSpecficField(String value, String field) {
        CaptureTransferDetail.EnterValueInSpecficField(value, field);
    }

    @Then("user enter {string} in {string} fields")
    public void EnterValueInSpecficFields(String value, String field) {
        CaptureTransferDetail.EnterValueInAmountField(value, field);
    }

    @Then("user verify input type of fullName is {string}")
    public void user_verify_input_type_of_is(String value) {
        CaptureTransferDetail.verifyInputType(value);
    }

    @Then("user verify input type of IBAN is {string}")
    public void user_verify_input_type_of_IBAN(String value) {
        CaptureTransferDetail.verifyInputTypeIBAN(value);
    }

    @Then("verify inline error is shown {string} under {string} field")
    public void user_verify_inline_error(String message, String field) {
        CaptureTransferDetail.VerifyInlineError(message, field);
    }

    @Then("verify inline error is shown {string} under Amount Field")
    public void user_verify_inline_errorUnder_Amount(String message) {
        CaptureTransferDetail.VerifyInlineError(message);
    }

    @Then("user press the tab key")
    public void TabKeyPress() {
        CaptureTransferDetail.TabKeyPress();
    }


}