package StepDefinitions.Mobile;

import Pages.actions.Mobile.AndroidSADADPage_Mobile;
import StepDefinitions.RunnerInfo;
import io.cucumber.java.en.Then;

public class AndroidSadadSteps_Mobile {

    AndroidSADADPage_Mobile androidSadad = new AndroidSADADPage_Mobile();

    @Then("user click on {string} button from SADAD bill list screen")
    public void userClickOnButtonFromSADADBillListScreen(String optVal) {
        androidSadad.clickAddNew(optVal);
    }

    @Then("user verify {string} popUp is open and visible")
    public void userVerifyPopUpIsOpenAndVisible(String optVal) {
        androidSadad.verifyAddNewPopUp(optVal);
    }

    @Then("verify {string} option is present")
    public void verifyOptionIsPresent(String optVal) {
        androidSadad.verifyAddNewPopUp(optVal);
    }

    @Then("user click on {string} option from popUp")
    public void userClickOnOptionFromPopUp(String optVal) {
        androidSadad.clickOpt(optVal);
    }

    @Then("verify that user is navigated to {string} page")
    public void verifyThatUserIsNavigatedToPage(String optVal) {
        androidSadad.verifySelectBillrPage(optVal);
    }

    @Then("user click on {string} bill on Select Biller page")
    public void userClickOnBillOnSelectBillerPage(String optVal) throws InterruptedException {
        androidSadad.clickBill(optVal);
    }

    @Then("verify user is on {string} page")
    public void verifyUserIsOnPage(String optVal) {
        androidSadad.verifyAddBillPage(optVal);
    }

    @Then("verify user is on {string} page android")
    public void verifyUserIsOnPageAndroid(String optVal) {
        if (RunnerInfo.getDeviceType().contains("android")) androidSadad.verifyAddBillPage(optVal);
    }

    @Then("verify user is on {string} page ios")
    public void verifyUserIsOnPageIos(String optVal) {
        if (!RunnerInfo.getDeviceType().contains("android")) androidSadad.verifyEditBillPage(optVal);
    }

    @Then("verify {string} subtext is present")
    public void verifySubtextIsPresent(String optVal) {
        androidSadad.verifySubText(optVal);
    }

    @Then("verify {string} is present on Select Biller page")
    public void verifyIsPresentOnSelectBillerPage(String optVal) {
        androidSadad.verifyAccTxt(optVal);
    }

    @Then("user enter {string} in Bill Number Input")
    public void userEnterInBillNumberInput(String optVal) {
        androidSadad.enterVal(optVal);
    }

    @Then("verify {string} button is disabled")
    public void verifyButtonIsDisabled(String optVal) {
        androidSadad.verifyContDisable(optVal);
    }

    @Then("verify {string} button is enabled")
    public void verifyButtonIsEnabled(String optVal) {
        androidSadad.verifyContEnable(optVal);
    }

    @Then("user clicks on {string} button of first bill in Bill pay screen")
    public void userClicksOnButtonOfFirstBillInBillPayScreen(String optVal) {
        androidSadad.clickDetBtn(optVal);
    }

    @Then("verify user is navigated to Bill details screen")
    public void verifyUserIsNavigatedToBillDetailsScreen() {
        androidSadad.verifyBillDet();
    }

    @Then("verify details are displayed on Bill details screen")
    public void verifyDetailsAreDisplayedOnBillDetailsScreen() {
        androidSadad.verifyDtailsBillPay();
    }

    @Then("user click on delete icon on Bill detail screen")
    public void userClickOnDeleteIconOnBillDetailScreen() {
        androidSadad.clickDel();
    }

    @Then("verify popUp {string} for deletion appears")
    public void verifyPopUpForDeletionAppears(String optVal) {
        androidSadad.verifyDelPopUp(optVal);
    }

    @Then("verify {string} button is present and enable")
    public void verifyButtonIsPresentAndEnable(String optVal) { androidSadad.verifyCancelBtn(optVal);
    }

    @Then("verify {string} button is present and enable or not")
    public void verifyButtonIsPresentAndEnableOrNot(String optVal) { androidSadad.verifyRemoveBtn(optVal);
    }

    @Then("user clicks on {string} button of first bill to {string} in Bill pay screen")
    public void userClicksOnButtonOfFirstBillToInBillPayScreen(String optVal1, String optVal2) {
        androidSadad.clickActivateDetailBtn(optVal1,optVal2);
    }

    @Then("verify {string} button is present on bill details screen")
    public void verifyButtonIsPresentOnBillDetailsScreen(String optVal) { androidSadad.verifyActivateBtn(optVal);
    }

    @Then("user clicks on {string} button on popUp screen")
    public void userClicksOnButtonOnPopUpScreen(String optVal) { androidSadad.clickRemoveBtn(optVal);
    }

    @Then("user click on {string} button on popUp")
    public void userClickOnButtonOnPopUp(String optVal) { androidSadad.clickCancelBtn(optVal);
    }

    @Then("user click {string} button on Add bill number page")
    public void userClickButtonOnAddBillNumberPage(String optVal) { androidSadad.clickContinueBtn(optVal);
    }

    @Then("verify error message {string} popUp displayed on screen")
    public void verifyErrorMessagePopUpDisplayedOnScreen(String optVal) { androidSadad.verifyErrorPopUp(optVal);
    }

    @Then("user click on {string} button on error popUp")
    public void userClickOnButtonOnErrorPopUp(String optVal) {
        androidSadad.clickRemoveBtn(optVal);
    }

    @Then("verify user is navigated to Bill amount page")
    public void verifyUserIsNavigatedToBillAmountPage() { androidSadad.verifyBillAmountPage();
    }

    @Then("verify {string} is present over amount text field")
    public void verifyIsPresentOverAmountTextField(String optVal) { androidSadad.verifyAmountField(optVal);
    }

    @Then("verify {string} is present before given amount")
    public void verifyIsPresentBeforeGivenAmount(String optVal) { androidSadad.verifySARField(optVal);
    }

    @Then("verify {string} button is present at the bottom of page")
    public void verifyButtonIsPresentAtTheBottomOfPage(String optVal) { androidSadad.verifyContinueBtn(optVal);
    }

    @Then("user enters an amount less than the min amount in text field")
    public void userEntersAnAmountLessThanTheMinAmountInTextField() { androidSadad.enterAmount();
    }

    @Then("user clicks on {string} button present at the bottom of page")
    public void userClicksOnButtonPresentAtTheBottomOfPage(String optVal) { androidSadad.clickBillContinueBtn(optVal);
    }

    @Then("verify inline error {string} displayed")
    public void verifyInlineErrorDisplayed(String optVal) { androidSadad.verifyBillError(optVal);
    }

    @Then("verify inline error {string} displayed android")
    public void verifyInlineErrorDisplayedAndroid(String optVal) {
        if (RunnerInfo.getDeviceType().contains("android"))
            androidSadad.verifyBillError(optVal);
    }

    @Then("verify inline error {string} displayed ios")
    public void verifyInlineErrorDisplayediOS(String optVal) {
        if (!RunnerInfo.getDeviceType().contains("android"))
            androidSadad.verifyBillError(optVal);
    }

    @Then("user enters a valid amount in text field")
    public void userEntersAValidAmountInTextField() { androidSadad.enterValidAmount();
    }

    @Then("verify {string} popUp appears")
    public void verifyPopUpAppears(String optVal) { androidSadad.verifyPaymentpopUp(optVal);
    }

    @Then("verify {string} option is present on popUp")
    public void verifyOptionIsPresentOnPopUp(String optVal) { androidSadad.verifyCreditCrdOpt(optVal);
    }

    @Then("verify {string} option present on popUp")
    public void verifyOptionPresentOnPopUp(String optVal) { androidSadad.verifyAccountOpt(optVal);
    }

    @Then("user click on back navigator to navigate back")
    public void userClickOnBackNavigatorToNavigateBack() { androidSadad.clickBackNav();
    }

    @Then("verify user navigates to {string} page")
    public void verifyUserNavigatesToPage(String optVal) { androidSadad.verifyRevBillPage(optVal);
    }

    @Then("verify Bill number {string} is displayed")
    public void verifyBillNumberIsDisplayed(String optVal) { androidSadad.verifyBillNum(optVal);
    }

    @Then("verify Bill Date {string} is displayed")
    public void verifyBillDateIsDisplayed(String optVal) { androidSadad.verifyBillDate(optVal);
    }

    @Then("verify Bill Date {string} is displayed android")
    public void verifyBillDateIsDisplayedAndroid(String optVal) {
        if (RunnerInfo.getDeviceType().contains("android")) androidSadad.verifyBillDate(optVal);
    }

    @Then("verify Bill Date {string} is displayed ios")
    public void verifyBillDateIsDisplayediOS(String optVal) {
        if (!RunnerInfo.getDeviceType().contains("android")) androidSadad.verifyBillDate(optVal);
    }

    @Then("verify Bill Status {string} is displayed")
    public void verifyBillStatusIsDisplayed(String optVal) { androidSadad.verifyBillStat(optVal);
    }

    @Then("verify Bill Due Amount {string} is displayed")
    public void verifyBillDueAmountIsDisplayed(String optVal) { androidSadad.verifyBillDueAmnt(optVal);
    }

    @Then("verify {string} button is present on review screen")
    public void verifyButtonIsPresentOnReviewScreen(String optVal) { androidSadad.verifyContBtnOnRevScreen(optVal);
    }

    @Then("user clicks on {string} button on Bill review screen")
    public void userClicksOnButtonOnBillReviewScreen(String optVal) { androidSadad.clickContinueONRevScreen(optVal);
    }

    @Then("user click on {string} option present on popUp")
    public void userClickOnOptionPresentOnPopUp(String optVal) { androidSadad.clickAccountOpt(optVal);
    }

    @Then("verify user is navigated to {string} account screen")
    public void verifyUserIsNavigatedToAccountScreen(String optVal) { androidSadad.verifyRevBillPage(optVal);
    }

    @Then("verify user is navigated to {string} account screen android")
    public void verifyUserIsNavigatedToAccountScreenAndroid(String optVal) {
        if (RunnerInfo.getDeviceType().contains("android")) androidSadad.verifyRevBillPage(optVal);
    }

    @Then("verify user is navigated to {string} account screen ios")
    public void verifyUserIsNavigatedToAccountScreenios(String optVal) {
        if (!RunnerInfo.getDeviceType().contains("android"))androidSadad.verifyRevBillPage(optVal);
    }

    @Then("user click on {string} option on popUp")
    public void userClickOnOptionOnPopUp(String optVal) { androidSadad.clickCreditCardOpt(optVal);
    }

    @Then("verify user is navigated to {string} screen")
    public void verifyUserIsNavigatedToScreen(String optVal) { androidSadad.verifyRevBillPage(optVal);
    }

    @Then("user click on back navigator on Select Card Screen to navigate back")
    public void userClickOnBackNavigatorOnSelectCardScreenToNavigateBack() { androidSadad.clickBackNavigatr();
    }

    @Then("user click on Search icon on Select Biller page")
    public void userClickOnSearchIconOnSelectBillerPage() {  if (RunnerInfo.getDeviceType().contains("android"))androidSadad.clickSearchIcon();
    }

    @Then("user enter Bill in {string} bar")
    public void userEnterBillInBar(String optVal) {  if (RunnerInfo.getDeviceType().contains("android"))androidSadad.enterBillInSearchBar(optVal);
    }

    @Then("verify user is navigated to the {string} page")
    public void verifyUserIsNavigatedToThePage(String optVal) { androidSadad.verifyAddNewPopUp(optVal);
    }

    @Then("verify paying amount is present on review page")
    public void verifyPayingAmountIsPresentOnReviewPage() { androidSadad.verifyPayingAmount();
    }

    @Then("verify From Account name is present on review page")
    public void verifyFromAccountNameIsPresentOnReviewPage() { androidSadad.verifyAccName();
    }

    @Then("verify From Account number is present on review page")
    public void verifyFromAccountNumberIsPresentOnReviewPage() { androidSadad.verifyAccNo();
    }

    @Then("verify Bill Name is present on review page")
    public void verifyBillNameIsPresentOnReviewPage() { androidSadad.verifyBillName();
    }

    @Then("verify Bill Bank is present on review page")
    public void verifyBillBankIsPresentOnReviewPage() { androidSadad.verifyBillBank();
    }

    @Then("verify {string} is present on review page")
    public void verifyIsPresentOnReviewPage(String optVal) { androidSadad.verifyDet(optVal);
    }

    @Then("verify Bill Name and No is present on review page")
    public void verifyBillNameAndNoIsPresentOnReviewPage() { androidSadad.verifyBillDet();
    }

    @Then("verify Bill amount is present on review page")
    public void verifyBillAmountIsPresentOnReviewPage() { androidSadad.verifyBillAmount();
    }

    @Then("verify {string} is present on review section")
    public void verifyIsPresentOnReviewSection(String optVal) { androidSadad.verifyFeesVat(optVal);
    }

    @Then("verify Fees Amount is present on review page")
    public void verifyFeesAmountIsPresentOnReviewPage() { androidSadad.verifyFeesVatAmount();
    }

    @Then("verify {string} button is present on review page")
    public void verifyButtonIsPresentOnReviewPage(String optVal) { androidSadad.verifyPayBillBtn(optVal);
    }

    @Then("user clicks {string} button present on review page")
    public void userClicksButtonPresentOnReviewPage(String optVal) { androidSadad.clickPayBtn(optVal);
    }

    @Then("verify user is navigated to Success Screen")
    public void verifyUserIsNavigatedToSuccessScreen() { androidSadad.verifySuccessScreen();
    }

    @Then("verify Success icon is present")
    public void verifySuccessIconIsPresent() { androidSadad.verifySuccessScreen();
    }

    @Then("verify {string} is present on Success Screen")
    public void verifyIsPresentOnSuccessScreen(String optVal) { androidSadad.verifySuccessLabel(optVal);
    }

    @Then("verify {string} is on Success Screen")
    public void verifyIsOnSuccessScreen(String optVal) { androidSadad.verifySuccessText(optVal);
    }

    @Then("verify {string} button is present on Success Screen")
    public void verifyButtonIsPresentOnSuccessScreen(String optVal) { androidSadad.verifyDoneBtn(optVal);
    }

    @Then("user click on Search icon on SADAD bill pay page")
    public void userClickOnSearchIconOnSADADBillPayPage() { androidSadad.clickSearch();
    }

    @Then("verify Search bar {string} is present on SADAD bill pay page")
    public void verifySearchBarIsPresentOnSADADBillPayPage(String optVal) { androidSadad.verifySearchBar(optVal);
    }

    @Then("verify chip {string} is present on SADAD bill pay page")
    public void verifyChipIsPresentOnSADADBillPayPage(String optVal) { androidSadad.verifyChip(optVal);
    }

    @Then("user click on chip {string} present on SADAD bill pay page")
    public void userClickOnChipPresentOnSADADBillPayPage(String optVal) { androidSadad.clickChip(optVal);
    }

    @Then("user click on {string} button of first bill")
    public void userClickOnButtonOfFirstBill(String optVal) { androidSadad.clickActivateBtn(optVal);
    }

    @Then("verify popup appears {string}")
    public void verifyPopupAppears(String optVal) { androidSadad.verifyPopUp(optVal);
    }

    @Then("verify {string} button on popUp present")
    public void verifyButtonOnPopUpPresent(String optVal) { androidSadad.verifyRemoveBtn(optVal);
    }


    @Then("user enter bill amount in {string} Bill due amount section")
    public void userEnterBillAmountInBillDueAmountSection(String optVal) { androidSadad.enterBillDueAmount(optVal);
    }

    @Then("Verify the {string} showing on the page")
    public void verifyBillDetails(String details) {
        androidSadad.VerifyBillDetails(details);
    }

    @Then("Verify the CTA Add a bill showing on the page")
    public void VerifyAddBill() {
        androidSadad.VerifyAddBill();
    }

    @Then("user scroll to the bottom")
    public void ScrollToBottom() {
        androidSadad.ScrollToBottom();
    }

    @Then("Verify the empty bill list will displayed when there is not any bill returned in Bill inquiry")
    public void VerifyEmptyBillList() {
        androidSadad.VerifyEmptyBillList();
    }

    @Then("click on the Activate button for bill of {string}")
    public void ClickActivateButton(String number) {
        androidSadad.ClickActivateButton(number);
    }

    @Then("verify the loading popup displayed while polling for result")
    public void VerifyLoadingpopup() {
        androidSadad.VerifyLoadingpopup();
    }
}
