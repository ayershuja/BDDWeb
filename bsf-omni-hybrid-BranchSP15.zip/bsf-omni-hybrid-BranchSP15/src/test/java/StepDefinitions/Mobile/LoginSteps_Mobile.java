package StepDefinitions.Mobile;

import DriverManager.Driver;
import Pages.actions.Browser.LoginPage_Browser;
import Pages.actions.Mobile.LoginPage_Mobile;
import Pages.actions.Mobile.MyProductsPage_Mobile;
import StepDefinitions.RunnerInfo;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.testng.Reporter;



public class LoginSteps_Mobile {

    LoginPage_Mobile loginPage_mobile;
    MyProductsPage_Mobile myProductsPage_mobile;

    LoginPage_Browser loginPage_browser;
    Driver driver = new Driver();



    @Given("the application is open")
    public void opening_app() {

        String env = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("deviceType");
        String URL = null;
        System.out.println("ENV:" + env);
        if (env == null) {
            if (RunnerInfo.getName().toLowerCase().contains("android")) {
                env = "android";
            } else if (RunnerInfo.getName().toLowerCase().contains("browserstack-ios")) {
                env = "browserstack-ios";
            } else if (RunnerInfo.getName().toLowerCase().contains("ios")) {
                env = "Ios";
            } else {
                URL = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("url");
                if (URL == null) {
                    URL = RunnerInfo.getURL().toLowerCase();
                }
                env = "browser";
            }
        }
        System.out.println("Before Setup Started");
        try {
            driver.setUp(env);
            if (env.equals("browser")) {
                loginPage_browser = new LoginPage_Browser();
                loginPage_browser.openURL1(URL);
            } else if (env.equals("android") | env.equals("browserstack-ios") | env.equals("Ios")) {
                loginPage_mobile = new LoginPage_Mobile();
                myProductsPage_mobile = new MyProductsPage_Mobile();
            }
        } catch (Exception e) {
            System.out.println("Cause: " + e.getCause());
            System.out.println("Message: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("Application Started");
    }

    @Then("user inputs the username {string} on the screen")
    public void userInputsTheUsernameOnTheScreen(String username) {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();

        loginPageMobile.enterUsername(username);
    }

    @Then("user inputs the password {string} on the screen")
    public void userInputsThePasswordOnTheScreen(String password) {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.enterPassword(password);
    }

    @Then("user enters the otp password {string}")
    public void userEntersTheOtpPassword(String optValue) {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.enterOTP(optValue);
    }

    @Then("verify the My Products page is open")
    public void verifyTheMyProductsPageIsOpen() {
        myProductsPage_mobile = new MyProductsPage_Mobile();
        myProductsPage_mobile.verifyMyProductsScreen();
    }

    @Then("user verifies the screen select your language is open")
    public void userVerifiesTheScreenSelectYourLanguageIsOpen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();

        loginPageMobile.verifySelectYourScreen();
    }

    @Then("user selects the language english from the screen")
    public void userSelectsTheLanguageEnglishFromTheScreen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();

        loginPageMobile.selectEnglishLanguage();
    }

    @Then("user clicks on the button continue on the screen")
    public void userClicksOnTheButtonContinueOnTheScreen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectContinueLanguage();
    }

    @Then("user verifies the screen Let's get started is open")
    public void userVerifiesTheScreenLetSGetStartedIsOpen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyLetsGetStartedScreen();
    }

    @Then("user clicks on the button Sign in on the screen")
    public void userClicksOnTheButtonSignInOnTheScreen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectSignInButton();
    }

    @Then("user verifies the screen Enter one-time password is open")
    public void userVerifiesTheScreenEnterOneTimePasswordIsOpen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyOTPScreen();
    }

    @Then("user clicks on the button Submit on the screen")
    public void userClicksOnTheButtonSubmitOnTheScreen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectSubmitButton();
    }

    @Then("user verifies the screen Create passcode is open")
    public void userVerifiesTheScreenCreatePasscodeIsOpen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyCreatePasscodeScreen();
    }

    @Then("user clicks on the button 0 on the screen")
    public void userClicksOnTheButtonOnThe0Screen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectZeroDigitButton();
    }

    @Then("user clicks on the button 2 on the screen")
    public void userClicksOnTheButtonOnThe2Screen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectTwoDigitButton();
    }

    @Then("user clicks on the button 4 on the screen")
    public void userClicksOnTheButtonOnThe4Screen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectFourDigitButton();
    }

    @Then("user clicks on the button 6 on the screen")
    public void userClicksOnTheButtonOnThe6Screen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectSixDigitButton();
    }

    @Then("user clicks on the button 8 on the screen")
    public void userClicksOnTheButtonOnThe8Screen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectEightDigitButton();
    }

    @Then("user verifies the screen Confirm passcode is open")
    public void userVerifiesTheScreenConfirmPasscodeIsOpen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyConfirmPasscodeScreen();
    }

    @Then("user verifies the screen Well done! is open")
    public void userVerifiesTheScreenWellDoneIsOpen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyWellDoneScreen();
    }

    @Then("user clicks on the button Let's get started on the screen")
    public void userClicksOnTheButtonLetSGetStartedOnTheScreen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectLetsGetStartedButton();
//        loginPageMobile.selectProfile();
    }

    @Then("user verifies the screen Enable Biometrics is open")
    public void userVerifiesTheScreenEnableBiometricsIsOpen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyEnableBiometricScreen();
    }

    @Then("user clicks on the button enable biometrics on the screen")
    public void userClicksOnTheButtonEnableBiometricsOnTheScreen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectEnableBiometricsButton();
    }

    @Then("complete the biometrics")
    public void completeTheBiometrics() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.completeBiometrics();
    }

    @Then("verify the password is masked {string}")
    public void verifyThePasswordIsVisible(String bool) {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyPasswordTextShown(Boolean.valueOf(bool));
    }

    @Then("user clicks on the eye icon")
    public void userClicksOnTheEyeIcon() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectPasswordEyeIcon();
    }

    @Then("verify the incorrect error message is shown")
    public void verifyTheIncorrectErrorMessageIsShown() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyIncorrectMessageIsDisplayed();
    }

    @Then("user clicks on Forgot Credentials Icon")
    public void userClicksOnForgotCredentialsIcon() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectForgotCredentialsButton();
    }

    @Then("user verifies the screen Forgot Credentials is open")
    public void userVerifiesTheScreenForgotCredentialsIsOpen() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyForgotCredentialsScreenIsDisplayed();
    }

    @Then("verify the splash screen")
    public void verifyTheSplashScreen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifySplashScreen();
    }

    @Then("user verifies the invalid otp code error")
    public void userVerifiesTheInvalidOtpCodeError() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyInvalidOTPCodeError();
    }

    @Then("user verifies the account is temporarily locked on the screen")
    public void userVerifiesTheAccountIsTemporarilyLockedOnTheScreen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyAccountBlockedCode();
    }

    @Then("verify repeating number error is shown")
    public void verifyRepeatingNumberErrorIsShown() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyRepeatingNumberError();
    }

    @Then("verify passcode mismatch error is shown")
    public void verifyPasscodeMismatchErrorIsShown() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyPasscodeMismatchError();
    }

    @Then("user verifies the enable biometrics pop up is open")
    public void userVerifiesTheEnableBiometricsPopUpIsOpen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyEnableBiometricPopUp();
    }

    @Then("user clicks on the button maybe later on the screen")
    public void userClicksOnTheButtonMaybeLaterOnTheScreen() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.selectMayBeLaterButton();
    }

    @Then("user fails the biometrics")
    public void userFailsTheBiometrics() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.failBiometrics();

    }

    @Then("user verifies the failed biometrics error is shown")
    public void userVerifiesTheFailedBiometricsErrorIsShown() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifyFailBiometricError();
    }

    @Then("user logs in with username {string} password {string} otp {string}")
    public void userLogsInWithUsernamePasswordOtp(String username, String password, String otpValue) {
//		try {
//			loginPage_mobile.selectAllowNotification();
//		}
//		catch (Exception e){
//
//		}

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifySelectYourScreen();
        loginPageMobile.selectEnglishLanguage();
        loginPageMobile.selectContinueLanguage();
//		if (!driver.getClass().toString().toLowerCase().contains("android"))
        loginPageMobile.verifyWelcomeScreen();
//		if (!driver.getClass().toString().toLowerCase().contains("android"))
        loginPageMobile.clickLoginButton();
        loginPageMobile.verifyLetsGetStartedScreen();
        loginPageMobile.enterUsername("loginCredentials", username);
        loginPageMobile.selectPasswordEyeIcon();
        loginPageMobile.enterPassword("loginCredentials", password);
        loginPageMobile.selectSignInButton();
//		loginPage_mobile.verifyOTPScreen();
//		loginPage_mobile.enterOTP(otpValue);
//		loginPage_mobile.selectSubmitButton();
        if (!RunnerInfo.getDeviceType().contains("android")) loginPageMobile.verifyEnableBiometricScreen();
        if (!RunnerInfo.getDeviceType().contains("android"))loginPageMobile.selectEnableBiometricsButton();
        if (!RunnerInfo.getDeviceType().contains("android"))loginPageMobile.completeBiometrics();
        loginPageMobile.verifyCreatePasscodeScreen();
        loginPageMobile.selectZeroDigitButton();
        loginPageMobile.selectTwoDigitButton();
        loginPageMobile.selectFourDigitButton();
        loginPageMobile.selectSixDigitButton();
        loginPageMobile.selectEightDigitButton();
        loginPageMobile.verifyConfirmPasscodeScreen();
        loginPageMobile.selectZeroDigitButton();
        loginPageMobile.selectTwoDigitButton();
        loginPageMobile.selectFourDigitButton();
        loginPageMobile.selectSixDigitButton();
        loginPageMobile.selectEightDigitButton();
        loginPageMobile.verifyWellDoneScreen();
        loginPageMobile.selectLetsGetStartedButton();
    //    loginPageMobile.selectProfile();
        loginPageMobile.acceptNotification();
    }

    @Then("accept the popup notification if the device is ios")
    public void acceptThePopupNotificationIfTheDeviceIsIos() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.acceptNotification();
    }

    @Then("close the appium driver")
    public void closeTheAppiumDriver() {

        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.closeDriver();
    }

    @Then("the testcase {string} is complete")
    public void theTestcaseIsComplete(String testCaseID) {

        System.out.println("TestCase " + testCaseID + " is completed");
    }

    @Then("user verifies the welcome screen is open")
    public void userVerifiesTheWelcomeScreenIsOpen() {
        if (!RunnerInfo.getDeviceType().contains("android"))
        {
            LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();

            loginPageMobile.verifyWelcomeScreen();}
    }

    @Then("user clicks on login button")
    public void userClicksLoginButton() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();

        loginPageMobile.clickLoginButton();
    }


}
