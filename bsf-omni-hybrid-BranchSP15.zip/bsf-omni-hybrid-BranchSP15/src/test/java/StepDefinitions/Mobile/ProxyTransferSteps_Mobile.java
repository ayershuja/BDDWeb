package StepDefinitions.Mobile;

import Pages.actions.Mobile.*;
import io.cucumber.java.en.Then;

public class ProxyTransferSteps_Mobile {

    ProxyTransferPage_Mobile proxyTransfer = new ProxyTransferPage_Mobile();
    PaymentsPage_Mobile paymentsPage_mobile = new PaymentsPage_Mobile();

    AndroidSADADPage_Mobile androidSadad = new AndroidSADADPage_Mobile();

    @Then("verify the Payments page is open")
    public void verifyThePaymentsPageIsOpen() {
        proxyTransfer.verifyPaymentPage();
    }

    @Then("verify Beneficiary page is open")

    public void verifyBeneficiaryPageIsOpen() {
        proxyTransfer.verifyBeneficiaryPage();
    }

//    @Then("verify {string} is present")
//    public void verifyIsPresent(String arg0) {proxyTransfer.verifyStringPresent();
//    }

    @Then("user click on {string} option")
    public void userClickOnOption(String arg0) {
    }

    @Then("user selects an account from the list")
    public void userSelectsAnAccountFromTheList() {
        proxyTransfer.selectFirstAcc();

    }

    @Then("user verify the Account details page is open")
    public void userVerifyTheAccountDetailsPageIsOpen() {
        proxyTransfer.verifyAccDetailsPage();
    }

    @Then("user select {string} from purpose dropdown")
    public void userSelectFromPurposeDropdown(String arg0) {
    }

    @Then("user verify {string} message is shown")
    public void userVerifyMessageIsShown(String arg0) {
    }

    @Then("user enters greater amount than the available balance in the Amount field")
    public void userEntersGreaterAmountThanTheAvailableBalanceInTheAmountField() {
        String amount = "10000000000";
        paymentsPage_mobile.verifyTransferAmount(amount);

    }

//    @Then("user verify {string} is displayed")
//    public void userVerifyIsDisplayed(String arg0) {
//    }

    @Then("user verify IP consent screen is displayed")
    public void userVerifyIPConsentScreenIsDisplayed() {
    }

    @Then("user set limit SAR {int}")
    public void userSetLimitSAR(int arg0) {
    }

    @Then("user select toggle button for phone")
    public void userSelectToggleButtonForPhone() {
    }

    @Then("user click on Done button")
    public void userClickOnDoneButton() {
    }

    @Then("user select send without beneficiary")
    public void userSelectSendWithoutBeneficiary() {
    }

    @Then("user click on Main Checking account")
    public void userClickOnMainCheckingAccount() {
    }

    @Then("user click on Email Switcher and Enter Email")
    public void userClickOnEmailSwitcherAndEnterEmail() {
    }


    @Then("user verifies that {string} is displayed")
    public void userVerifiesThatIsDisplayed(String arg0) {
    }

    @Then("verify Transfer money between accounts is present")
    public void verifyTransferMoneyBetweenAccountsIsPresent() {
        proxyTransfer.verifyTrnsfrMonBtwOwnAcc();
    }

    @Then("verify Transfer money to someone is present")
    public void verifyTransferMoneyToSomeoneIsPresent() {
        proxyTransfer.verifyTrnsfrMonSomeOneAcc();
    }

    @Then("verify Bill pay is present")
    public void verifyBillPayIsPresent() {
        proxyTransfer.verifyBillPay();
    }

    @Then("verify MOI payments is present")
    public void verifyMOIPaymentsIsPresent() {
        proxyTransfer.verifyMOIPay();
    }

    @Then("verify Request to pay is present")
    public void verifyRequestToPayIsPresent() {
        proxyTransfer.reqToPay();
    }

    @Then("user click on Transfer money to someone option")
    public void userClickOnTransferMoneyToSomeoneOption() {
        proxyTransfer.clickTrnsfrMonSomOnEAcc();
    }

    @Then("user verify From page is present")
    public void userVerifyFromPageIsPresent() {
        proxyTransfer.verifyFromPage();
    }

    @Then("user click on account from the accounts list in From page")
    public void userClickOnAccountFromTheAccountsListInFromPage() {
        proxyTransfer.clickAccfromList();
    }

    @Then("user click on account from the accounts list in {string} page")
    public void userClickOnAccountFromTheAccountsListInFromPage(String accountType) {
        proxyTransfer.clickAccfromList(accountType);
    }

    @Then("user click on account from the accounts list in {string} page with currency {string}")
    public void userClickOnAccountFromTheAccountsListInFromPage(String accountType, String currency) {
        proxyTransfer.clickAccfromList(accountType, currency);
    }

    @Then("user verify Transfer Details page")
    public void userVerifyTransferDetailsPage() {
        proxyTransfer.verifyTransferDetPage();
    }

    @Then("user clicks on purpose selector with option {string}")
    public void userClicksOnPurposeSelectorWithOption(String option) {
        proxyTransfer.selectPurpose(option);
    }

    @Then("user click on button {string}")
    public void userClickOnButton(String optionVal) {
        proxyTransfer.clickButton(optionVal);
    }

    @Then("verify the account name is displayed and is {string}")
    public void verifyTheAccountNameIsDisplayedAndIs(String optVal) {
        proxyTransfer.verifyAccName(optVal);
    }

    @Then("verify the account no is displayed and is {string}")
    public void verifyTheAccountNoIsDisplayedAndIs(String optVal) {
        proxyTransfer.verifyAccNo(optVal);
    }

    @Then("verify the bank country is displayed and is {string}")
    public void verifyTheBankCountryIsDisplayedAndIs(String optVal) {
        proxyTransfer.verifyBankCountry(optVal);
    }

    @Then("verify to and from account name and account numbers")
    public void verifyToAndFromAccountNameAndAccountNumbers() {
        proxyTransfer.verifyToAndFromAccountNameAndAccountNumber();
    }

    @Then("verify purpose error message {string}")
    public void verifyPurposeErrorMessage(String optVal) { paymentsPage_mobile.verifyOtherPurposeErrorMessage(optVal);
    }

    @Then("user click on {string} on Select Beneficiary screen")
    public void userClickOnOnSelectBeneficiaryScreen(String optVal) { proxyTransfer.clickOneTimeTrnsfr(optVal);
    }

    @Then("verify chip {string} is present on Transfer Details screen")
    public void verifyChipIsPresentOnTransferDetailsScreen(String optVal) { proxyTransfer.verifyChips(optVal);
    }

    @Then("user click on {string} chip present on Transfer Details screen")
    public void userClickOnChipPresentOnTransferDetailsScreen(String optVal) { proxyTransfer.clickChip(optVal);
    }

    @Then("verify {string} is present on Transfer Details screen")
    public void verifyIsPresentOnTransferDetailsScreen(String optVal) { proxyTransfer.verifyChips(optVal);
    }

    @Then("verify {string} present on Transfer screen")
    public void verifyPresentOnTransferScreen(String optVal) { proxyTransfer.verifyFullNameTxt(optVal);
    }

    @Then("verify IBAN to enter present on Transfer screen")
    public void verifyIBANToEnterPresentOnTransferScreen() { proxyTransfer.verifyIBANTxt();
    }

    @Then("enter {string} in Full Name Text bar")
    public void enterInFullNameTextBar(String optVal) { proxyTransfer.enterFullName(optVal);
    }

    @Then("enter {string} in IBAN Text Bar")
    public void enterInIBANTextBar(String optVal) { proxyTransfer.enterIBAN(optVal);
    }

    @Then("enter {string} phone no in field")
    public void enterPhoneNoInField(String optVal) { proxyTransfer.enterPhoneNo(optVal);
    }

    @Then("user click on Bank dropdown field")
    public void userClickOnBankDropdownField() { proxyTransfer.clickBankDropdown();
    }

    @Then("user select {string} option from Bank dropdown")
    public void userSelectOptionFromBankDropdown(String optVal) { proxyTransfer.clickChip(optVal);
    }

    @Then("verify error message {string} below Phone No field")
    public void verifyErrorMessageBelowPhoneNoField(String optVal) { proxyTransfer.verifyPhoneErr(optVal);
    }

    @Then("user enter email {string} in Email address field")
    public void userEnterEmailInEmailAddressField(String optVal) { proxyTransfer.enterEmail(optVal);
    }

    @Then("user clicks on Bank dropdown field in EMAIL section")
    public void userClicksOnBankDropdownFieldInEMAILSection() { proxyTransfer.clickBankDrpDwn();
    }

    @Then("user enter ID or Iqama No {string} in Iqama field")
    public void userEnterIDOrIqamaNoInIqamaField(String optVal) { proxyTransfer.enterIqama(optVal);
    }

    @Then("verify error message {string} below Bank field")
    public void verifyErrorMessageBelowBankField(String optVal) { proxyTransfer.verifyPhoneErr(optVal);
    }

    @Then("user clicks on Bank dropdown field in IQAMA section")
    public void userClicksOnBankDropdownFieldInIQAMASection() { proxyTransfer.SelectBank();
    }

    @Then("verify {string} is present in Note field")
    public void verifyIsPresentInNoteField(String optVal) { proxyTransfer.verifyFullNameTxt(optVal);
    }

    @Then("verify popUp {string} is present after IBAN input")
    public void verifyPopUpIsPresentAfterIBANInput(String optVal) { proxyTransfer.verifyServiceNotAvlblePopUp(optVal);
    }

    @Then("verify {string} button is present on poPuP")
    public void verifyButtonIsPresentOnPoPuP(String optVal) { androidSadad.verifyRemoveBtn(optVal);
    }
}
