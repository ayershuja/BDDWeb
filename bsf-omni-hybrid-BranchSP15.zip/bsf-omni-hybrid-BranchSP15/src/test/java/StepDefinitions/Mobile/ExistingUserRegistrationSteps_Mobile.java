package StepDefinitions.Mobile;

import DriverManager.Driver;
import Pages.actions.Mobile.DraftPage_Mobile;
import Pages.actions.Mobile.ExistingUserRegistrationPage_Mobile;
import Pages.actions.Mobile.LoginPage_Mobile;
import Pages.actions.Mobile.MorePage_Mobile;
import io.cucumber.java.en.Then;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ExistingUserRegistrationSteps_Mobile {
    ExistingUserRegistrationPage_Mobile existingUserRegistrationPageMobile = new ExistingUserRegistrationPage_Mobile();
    static Properties prop = new Properties();

    Driver driver = new Driver();
    @Then("user click on register to bsf")
    public void clickOnRegisterToBsf() {
        LoginPage_Mobile loginPageMobile = new LoginPage_Mobile();
        loginPageMobile.verifySelectYourScreen();
        loginPageMobile.selectEnglishLanguage();
        loginPageMobile.selectContinueLanguage();
//		if (!driver.getClass().toString().toLowerCase().contains("android"))
        loginPageMobile.verifyWelcomeScreen();
        existingUserRegistrationPageMobile.selectRegisterToBsf();
    }
    @Then("user verify {string} : {string}")
    public void clickOnMoreIconOnTheScreen(String key, String value) {
        existingUserRegistrationPageMobile.verifyText(key, value);
    }

    @Then("user enter {string} into input field")
    public void enterUserName(String key) throws IOException {
        String PropFilePath = System.getProperty("user.dir") + "/src/test/resources/data/existingUser.properties";
        FileInputStream fis = new FileInputStream(PropFilePath);
        prop.load(fis);
        String value = prop.get(key).toString();
        existingUserRegistrationPageMobile.enterUserName(value);
    }
    @Then("user enter value into {string} field")
    public void enterPassword(String key) throws  IOException {
        String PropFilePath = System.getProperty("user.dir") + "/src/test/resources/data/existingUser.properties";
        FileInputStream fis = new FileInputStream(PropFilePath);
        prop.load(fis);
        existingUserRegistrationPageMobile.enterPassword(key, prop.get(key).toString());
    }

    @Then("user select {string} digit")
    public void clickOnDigitNumber(String digitValue) throws  IOException {
        existingUserRegistrationPageMobile.clickOnDigitNumber(digitValue);
    }
    @Then("user verify and select the card")
    public void selectFirstCard() {
        existingUserRegistrationPageMobile.selectFirstCard();
    }
}
