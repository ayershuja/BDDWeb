package StepDefinitions.Mobile;

import DriverManager.Driver;
import Pages.actions.Mobile.DraftPage_Mobile;
import Pages.actions.Mobile.MorePage_Mobile;
import StepDefinitions.RunnerInfo;
import Utils.PropertiesOperations;
import io.cucumber.java.en.Then;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.support.PageFactory;



public class DraftSteps_Mobile {
    DraftPage_Mobile draftPage_mobile = new DraftPage_Mobile();
    MorePage_Mobile morePage_mobile = new MorePage_Mobile();

    Driver driver = new Driver();
    @Then("user click on more icon")
    public void clickOnMoreIconOnTheScreen() {
        draftPage_mobile.clickMoreIcon();
    }

    @Then("user click on message icon")
    public void clickOnMessageIconOnTheScreen() {
        morePage_mobile.clickMessageIcon();
    }

    @Then("user click on drafts icon")
    public void clickOnDraftIconOnTheScreen() {
        draftPage_mobile.clickDraftIcon();
    }

    @Then("user click on new message icon")
    public void clickOnNewMessageIconOnTheScreen() {
        draftPage_mobile.clickNewMessageIcon();
    }

    @Then("user select topic for message screen")
    public void selectTopicOnTheScreen() throws InterruptedException {
        draftPage_mobile.selectTopicSpinner();
    }

    @Then("user select {string} topic for message screen")
    public void selectTopicSpinnerValue(String topic) throws InterruptedException {
        draftPage_mobile.selectTopicSpinnerValue(topic);
    }

    @Then("user enter {string} text into the subject")
    public void enterSubjectTextOnTheScreen(String subjectText) throws InterruptedException {
        if (subjectText.contains("Limit")) {
            draftPage_mobile.enterSubject(PropertiesOperations.getPropertyValueByKey("Message", subjectText).trim());
        } else {
            draftPage_mobile.enterSubject(subjectText);
        }
    }

    @Then("user enter {string} text into the message")
    public void enterMessageTextOnTheScreen(String messageText) {
        draftPage_mobile = null;
        draftPage_mobile = new DraftPage_Mobile();
        draftPage_mobile.enterMessage(messageText);
    }

    @Then("user click on cancel icon")
    public void clickOnCancelIconOnTheScreen() {
        draftPage_mobile.clickCancelIcon();
    }

    @Then("user click on {string} icon")
    public void clickOnIconOnTheScreen(String title) {
        draftPage_mobile.clickIcon(title);
    }

    @Then("user verify {string} icon is displayed")
    public void verifyIconIsDisplayed(String title) {
        draftPage_mobile.verifyIconIsDisplayed(title);
    }

    @Then("user verify {string} topic text is displayed")
    public void verifySelectTopicIsDisplayed(String title) {
        draftPage_mobile.verifySelectTopicIsDisplayed(title);
    }

    @Then("user click on select topic")
    public void clickOnSelectTopic() throws InterruptedException {
        draftPage_mobile.clickOnSelectTopic();
    }

    @Then("user click on button {string} icon")
    public void clickOnButtonIcon(String title) {
        draftPage_mobile.clickOnButtonIcon(title);
    }

    @Then("user click on the button {string} icon")
    public void clickOnTheButtonIcon(String title) {
        draftPage_mobile.clickOnTheButtonIcon(title);
    }

    @Then("user select {string}")
    public void clickOnTextOnTheScreen(String title) {
        if (RunnerInfo.getDeviceType().contains("android")) draftPage_mobile.clickIcon(title);
    }

    @Then("user clicked on {string} icon")
    public void clickOnIconIdOnTheScreen(String title) {
        draftPage_mobile.clickOnIdIcon(title);
    }

    @Then("user clicked on show roots icon")
    public void clickOnShowRootsOnTheScreen() {
        if (RunnerInfo.getDeviceType().contains("android")) draftPage_mobile.clickOnShowRootsIcon();
    }

    @Then("user select pdf file")
    public void selectFileOnTheScreen() {
        if (RunnerInfo.getDeviceType().contains("android")) draftPage_mobile.selectFile();
    }

    @Then("user click on send button")
    public void clickOnSendButton() throws InterruptedException {
        draftPage_mobile.clickOnSendIcon();
    }

    @Then("user click on attached file icon")
    public void clickOnAttachIconOnTheScreen() {
        if (RunnerInfo.getDeviceType().contains("android")) draftPage_mobile.clickOnAttachIcon();
    }

    @Then("user click on navigation back icon")
    public void clickOnBackIconOnTheScreen() {
        draftPage_mobile.clickOnNavigation();
    }

    @Then("user click on message navigation back icon")
    public void clickOnMessageNavigation() {
        draftPage_mobile.clickOnMessageNavigation();
    }

    @Then("user click on download button")
    public void clickOnDownloadIconOnTheScreen() {
        if (RunnerInfo.getDeviceType().contains("android")) draftPage_mobile.clickOnDownload();
    }

    @Then("user verify the draft message is displayed")
    public void verifyMessage() {
        draftPage_mobile.verifyDraftMessageIsDisplay();
    }

    @Then("user clicks on sent icon")
    public void userClicksOnSentIcon() {
        draftPage_mobile.clickOnSentIcon();
    }

    @Then("verify a recent draft message is created with subject {string} message {string} time {string}")
    public void verifyARecentDraftMessageIsCreatedWithSubjectMessageTimeAndTopic(String subject, String message, String time) {
        draftPage_mobile.verifyLatestDraftMessage(subject, message, time);
    }

    @Then("verify a recent sent message is created with subject {string} time {string} user {string}")
    public void verifyARecentSentMessageIsCreatedWithSubjectMessageTimeAndTopic(String subject, String time, String user) {
        draftPage_mobile = new DraftPage_Mobile();
        draftPage_mobile.verifyLatestSentMessage(subject, time, PropertiesOperations.getPropertyValueByKey("loginCredentials", user));
    }

    @Then("verify more screen is open")
    public void verifyMoreScreenIsOpen() {
        morePage_mobile = new MorePage_Mobile();
        morePage_mobile.verifyMoreScreen();
    }

    @Then("verify message screen is open")
    public void verifyMessageScreenIsOpen() {
        draftPage_mobile.verifyMessageScreen();
    }

    @Then("verify the {string} icon is selected")
    public void verifyTheIconIsSelected(String iconType) {
        draftPage_mobile.verifySelectedIcon(iconType);
    }

    @Then("user click on sent icon")
    public void userClickOnSentIcon() {
        draftPage_mobile.clickOnIconSent();
    }

    @Then("user click on inbox icon")
    public void userClickOnInboxIcon() {
        draftPage_mobile.clickOnIconInbox();
    }

    @Then("user click on draft icon")
    public void userClickOnDraftIcon() {
        draftPage_mobile.clickOnIconDraft();
    }

    @Then("delete all existing {string} messages")
    public void deleteAllExistingDraftMessages(String messageType) {
        draftPage_mobile.deleteAllMessages(messageType);
    }

    @Then("verify {string} icon is present with sentence {string}")
    public void verifyIconIsPresentWithSentence(String edgeCaseIcon, String edgeCaseSentence) {
        draftPage_mobile.initializer();
        draftPage_mobile.verifyEdgeCase(edgeCaseIcon, edgeCaseSentence);
    }

    // Sent screen
    @Then("user select first conversation from send screen")
    public void selectConversationFirstMessage() {
        draftPage_mobile.initializer();
        draftPage_mobile.selectConversationFirstMessage();
    }

    @Then("user verify conversation from send screen is displayed")
    public void verifyConversationFirstMessage() {
//        draftPage_mobile = null;
//        draftPage_mobile = new DraftPage_Mobile();
//        draftPage_mobile = PageFactory.initElements(draftPage_mobile.driver,DraftPage_Mobile.class);
        draftPage_mobile.initializer();
        draftPage_mobile.verifyConversationFirstMessage();
    }

    @Then("user verify {string} conversation message is displayed")
    public void verifyConversationIsDisplayed(String message) {

        draftPage_mobile.verifyConversationIsDisplayed(message);
    }

    @Then("user verify {string} error message")
    public void verifyCreateBeneficiaryErrorMessage(String errorMessageText) {
        draftPage_mobile.verifyCreateBeneficiaryErrorMessage(errorMessageText);
    }
}
