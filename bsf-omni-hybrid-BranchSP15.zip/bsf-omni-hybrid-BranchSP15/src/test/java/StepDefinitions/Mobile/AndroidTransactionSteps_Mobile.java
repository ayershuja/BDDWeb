package StepDefinitions.Mobile;

import Pages.actions.Mobile.AndroidTransactionsPage_Mobile;
import StepDefinitions.RunnerInfo;
import io.cucumber.java.en.Then;

import java.text.ParseException;

public class AndroidTransactionSteps_Mobile {

    AndroidTransactionsPage_Mobile androidTransactions = new AndroidTransactionsPage_Mobile();

    @Then("verify {string} is present on Products screen")
    public void verifyIsPresentOnProductsScreen(String optVal) { androidTransactions.verifyCurrentAcc(optVal);

    }

    @Then("verify user is navigated to Transaction Detail screen")
    public void verifyUserIsNavigatedToTransactionDetailScreen() { androidTransactions.verifyTransactionScreen();
    }

    @Then("verify {string} is displayed on Screen")
    public void verifyIsDisplayedOnScreen(String optVal) { androidTransactions.verifyNoTransactionsMsg(optVal);
    }

    @Then("user selects an account from the Current Account list")
    public void userSelectsAnAccountFromTheCurrentAccountList() { androidTransactions.selectAcc();
    }

    @Then("user click on first transaction on Details screen")
    public void userClickOnFirstTransactionOnDetailsScreen() { androidTransactions.selectFirstTransact();
    }

    @Then("verify user is navigated to Transaction Description screen")
    public void verifyUserIsNavigatedToTransactionDescriptionScreen() { androidTransactions.verifyTransDesc();
    }

    @Then("user click on Incoming Transaction from Transaction Details Screen")
    public void userClickOnIncomingTransactionFromTransactionDetailsScreen() { androidTransactions.clickIncomingTrans();
    }

    @Then("user selects {string} account in products screen")
    public void userSelectsAccountInProductsScreen(String optValue) { androidTransactions.selectFirstAcc(optValue);;
    }

    @Then("user clicks on Search button on Transaction Detail screen")
    public void userClicksOnSearchButtonOnTransactionDetailScreen() { androidTransactions.clickSearchBtn();
    }

    @Then("user enter transaction details in search bar")
    public void userEnterTransactionDetailsInSearchBar() { androidTransactions.enterTransDet();
    }

    @Then("verify transaction is displayed on screen according to search result")
    public void verifyTransactionIsDisplayedOnScreenAccordingToSearchResult() { androidTransactions.verifyTransactViaSearch();
    }

    @Then("verify filter {string} is displayed on Search Transaction screen")
    public void verifyFilterIsDisplayedOnSearchTransactionScreen(String optVal) { androidTransactions.verifyFilterVal(optVal);
    }

    @Then("verify filter {string} is displayed on Search Transaction screen android")
    public void verifyFilterIsDisplayedOnSearchTransactionScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyFilterVal(optVal);
    }

    @Then("verify filter {string} is displayed on Search Transaction screen ios")
    public void verifyFilterIsDisplayedOnSearchTransactionScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyFilterVal(optVal);
    }

    @Then("user click on {string} filter button on Search Transaction screen")
    public void userClickOnFilterButtonOnSearchTransactionScreen(String optVal) {
        androidTransactions.clickFilterOpt(optVal);
    }

    @Then("user click on {string} filter button on Search Transaction screen android")
    public void userClickOnFilterButtonOnSearchTransactionScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickFilterOpt(optVal);

    }

    @Then("user click on {string} filter button on Search Transaction screen ios")
    public void userClickOnFilterButtonOnSearchTransactionScreeniOS(String optVal) { androidTransactions.clickFilterOpt(optVal);
    }

    @Then("verify user is navigated to {string} fields screen")
    public void verifyUserIsNavigatedToFieldsScreen(String optVal) { androidTransactions.verifyAmountRngScreen(optVal);
    }

    @Then("verify user is navigated to {string} fields screen android")
    public void verifyUserIsNavigatedToFieldsScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android")) androidTransactions.verifyAmountRngScreen(optVal);
    }
    @Then("verify user is navigated to {string} fields screen ios")
    public void verifyUserIsNavigatedToFieldsScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyAmountRngScreen(optVal);
    }


    @Then("verify {string} button is present on Amount Range fields screen")
    public void verifyButtonIsPresentOnAmountRangeFieldsScreen(String optVal) { androidTransactions.verifyRstBtn(optVal);
    }

    @Then("verify {string} button is present on Amount Range fields screen android")
    public void verifyButtonIsPresentOnAmountRangeFieldsScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyRstBtn(optVal);
    }

    @Then("verify {string} button is present on Amount Range fields screen ios")
    public void verifyButtonIsPresentOnAmountRangeFieldsScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyRstBtn(optVal);
    }

    @Then("verify label {string} is present on Amount Range fields screen")
    public void verifyLabelIsPresentOnAmountRangeFieldsScreen(String optVal) { androidTransactions.verifyLblAmntRnge(optVal);
    }

    @Then("verify label {string} is present on Amount Range fields screen android")
    public void verifyLabelIsPresentOnAmountRangeFieldsScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyLblAmntRnge(optVal);
    }

    @Then("verify label {string} is present on Amount Range fields screen ios")
    public void verifyLabelIsPresentOnAmountRangeFieldsScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyLblAmntRnge(optVal);
    }

    @Then("verify label {string} present on Amount Range fields screen")
    public void verifyLabelPresentOnAmountRangeFieldsScreen(String optVal) { androidTransactions.verifyMaxAmntLbl(optVal);
    }

    @Then("verify label {string} present on Amount Range fields screen android")
    public void verifyLabelPresentOnAmountRangeFieldsScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyMaxAmntLbl(optVal);
    }

    @Then("verify label {string} present on Amount Range fields screen ios")
    public void verifyLabelPresentOnAmountRangeFieldsScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyMaxAmntLbl(optVal);
    }

    @Then("verify button {string} present on Amount Range fields screen")
    public void verifyButtonPresentOnAmountRangeFieldsScreen(String optVal) { androidTransactions.verifyApplyBtn(optVal);
    }

    @Then("user enter minimum amount {string} in Minimum Amount field")
    public void userEnterMinimumAmountInMinimumAmountField(String optVal) { androidTransactions.enterMinAmountInField(optVal);
    }

    @Then("user enter maximum amount {string} in Maximum Amount field")
    public void userEnterMaximumAmountInMaximumAmountField(String optVal) { androidTransactions.enterMaxAmountInField(optVal);
    }

    @Then("user click on button {string} present on Amount Range fields screen")
    public void userClickOnButtonPresentOnAmountRangeFieldsScreen(String optVal) { androidTransactions.clickApplyBtn(optVal);
    }

    @Then("verify label {string} is present on Date fields screen")
    public void verifyLabelIsPresentOnDateFieldsScreen(String optVal) { androidTransactions.verifyDateFieldLbl(optVal);
    }

    @Then("verify label {string} present on Date fields screen")
    public void verifyLabelPresentOnDateFieldsScreen(String optVal) { androidTransactions.verifyDateLblTo(optVal);
    }

    @Then("user click on {string} From field on Date fields screen")
    public void userClickOnFromFieldOnDateFieldsScreen(String optVal) { androidTransactions.clickFromDate(optVal);
    }

    @Then("user click on {string} From field on Date fields screen android")
    public void userClickOnFromFieldOnDateFieldsScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickFromDate(optVal);
    }

    @Then("user click on {string} From field on Date fields screen ios")
    public void userClickOnFromFieldOnDateFieldsScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickFromDate(optVal);
    }

    @Then("user click on {string} To field on Date fields screen")
    public void userClickOnToFieldOnDateFieldsScreen(String optVal) { androidTransactions.clickToDate(optVal);
    }

    @Then("user click on {string} To field on Date fields screen android")
    public void userClickOnToFieldOnDateFieldsScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickToDate(optVal);
    }

    @Then("user click on {string} To field on Date fields screen ios")
    public void userClickOnToFieldOnDateFieldsScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickToDate(optVal);
    }

    @Then("verify {string} Date picker Calender is displayed on screen")
    public void verifyDatePickerCalenderIsDisplayedOnScreen(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyDatePicker(optVal);
    }

    @Then("user click on {string} button on date picker calender")
    public void userClickOnButtonOnDatePickerCalender(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickCancel(optVal);
    }

    @Then("user select a date for From field")
    public void userSelectADateForFromField() throws InterruptedException { androidTransactions.selectDateFrom();
    }

    @Then("user click on button {string} on calender")
    public void userClickOnButtonOnCalender(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android")) androidTransactions.clickOk(optVal);
    }

    @Then("user select a date for To field")
    public void userSelectADateForToField() throws InterruptedException { androidTransactions.selectDateTo();
    }

    @Then("verify button {string} present on Date fields screen")
    public void verifyButtonPresentOnDateFieldsScreen(String optVal) { androidTransactions.verifyApplyBtnOnDateScreen(optVal);
    }

    @Then("user click on button {string} present on Date fields screen")
    public void userClickOnButtonPresentOnDateFieldsScreen(String optVal) { androidTransactions.clickApply(optVal);
    }

    @Then("verify {string} is present on In or Out Screen")
    public void verifyIsPresentOnInOrOutScreen(String optVal) { androidTransactions.verifyDebitLbl(optVal);
    }

    @Then("verify subText {string} below Debit is present on In or Out Screen")
    public void verifySubTextBelowDebitIsPresentOnInOrOutScreen(String optVal) { androidTransactions.veriySubDebitTrans(optVal);
    }

    @Then("verify subText {string} below Debit is present on In or Out Screen android")
    public void verifySubTextBelowDebitIsPresentOnInOrOutScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.veriySubDebitTrans(optVal);
    }

    @Then("verify subText {string} below Debit is present on In or Out Screen ios")
    public void verifySubTextBelowDebitIsPresentOnInOrOutScreenIOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.veriySubDebitTrans(optVal);
    }

    @Then("verify {string} present on In or Out Screen")
    public void verifyPresentOnInOrOutScreen(String optVal) { androidTransactions.verifyCredTrans(optVal);
    }

    @Then("verify subText {string} below Credit is present on In or Out Screen")
    public void verifySubTextBelowCreditIsPresentOnInOrOutScreen(String optVal) { androidTransactions.verifySubCred(optVal);
    }

    @Then("verify subText {string} below Credit is present on In or Out Screen android")
    public void verifySubTextBelowCreditIsPresentOnInOrOutScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifySubCred(optVal);
    }

    @Then("verify subText {string} below Credit is present on In or Out Screen ios")
    public void verifySubTextBelowCreditIsPresentOnInOrOutScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifySubCred(optVal);
    }

    @Then("user click on {string} present on In or Out Screen")
    public void userClickOnPresentOnInOrOutScreen(String optVal) { androidTransactions.clickCredTrans(optVal);
    }

    @Then("verify button {string} present on In or Out screen")
    public void verifyButtonPresentOnInOrOutScreen(String optVal) { androidTransactions.verifyApplyBtnOnInOutScreen(optVal);
    }

    @Then("user click on button {string} present on In or Out screen")
    public void userClickOnButtonPresentOnInOrOutScreen(String optVal) { androidTransactions.clickBtnApplyInOut(optVal);
    }

    @Then("user click on {string} icon present on In or Out Screen")
    public void userClickOnIconPresentOnInOrOutScreen(String optVal) { androidTransactions.clickDebtTrans(optVal);
    }

    @Then("user enter invalid transaction details in search bar")
    public void userEnterInvalidTransactionDetailsInSearchBar() { androidTransactions.enterInvalidTransDet();
    }

    @Then("verify {string} on Transaction details screen")
    public void verifyOnTransactionDetailsScreen(String optVal) { androidTransactions.verifyNoDataVis(optVal);
    }

    @Then("user click on cross icon to navigate back to Search Transaction screen")
    public void userClickOnCrossIconToNavigateBackToSearchTransactionScreen() { androidTransactions.clickCrossIcon();
    }

    @Then("user click on {string} button is present on Amount Range fields screen")
    public void userClickOnButtonIsPresentOnAmountRangeFieldsScreen(String optVal) { androidTransactions.clickResetBtn(optVal);
    }

    @Then("user click on {string} button is present on Amount Range fields screen android")
    public void userClickOnButtonIsPresentOnAmountRangeFieldsScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickResetBtn(optVal);
    }

    @Then("user click on {string} button is present on Amount Range fields screen ios")
    public void userClickOnButtonIsPresentOnAmountRangeFieldsScreenios(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickResetBtn(optVal);
    }

    @Then("verify amount is resetted to {string} in Minimum Amount field")
    public void verifyAmountIsResettedToInMinimumAmountField(String optVal) { androidTransactions.verifyResettedVal(optVal);
    }

    @Then("verify amount is resetted to {string} in Maximum Amount field")
    public void verifyAmountIsResettedToInMaximumAmountField(String optVal) { androidTransactions.verifyResettedVal(optVal);
    }

    @Then("user click on {string} button is present on Date fields screen")
    public void userClickOnButtonIsPresentOnDateFieldsScreen(String optVal) { androidTransactions.clickResetBtn(optVal);
    }

    @Then("user click on {string} button is present on In or Out screen")
    public void userClickOnButtonIsPresentOnInOrOutScreen(String optVal) { androidTransactions.clickResetBtn(optVal);
    }

    @Then("user click on {string} button is present on In or Out screen android")
    public void userClickOnButtonIsPresentOnInOrOutScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickResetBtn(optVal);
    }

    @Then("user click on {string} button is present on In or Out screen ios")
    public void userClickOnButtonIsPresentOnInOrOutScreeniOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.clickResetBtn(optVal);
    }

    @Then("verify transaction icon is present on Transaction Description screen")
    public void verifyTransactionIconIsPresentOnTransactionDescriptionScreen() { androidTransactions.verifyTransIcon();
    }

    @Then("verify Transaction Amount is present on Transaction Description screen")
    public void verifyTransactionAmountIsPresentOnTransactionDescriptionScreen() { androidTransactions.verifyTransAmount();
    }

    @Then("verify Transaction Date is present on Transaction Description screen")
    public void verifyTransactionDateIsPresentOnTransactionDescriptionScreen() { androidTransactions.verifyTransDate();
    }

    @Then("verify label {string} is present on Transaction Description screen")
    public void verifyLabelIsPresentOnTransactionDescriptionScreen(String optVal) { androidTransactions.verifyType(optVal);
    }

    @Then("user click on {string} icon on Transaction Detail screen")
    public void userClickOnIconOnTransactionDetailScreen(String optVal) { androidTransactions.clickStatementIcn(optVal);
    }

    @Then("verify user navigates to {string} screen")
    public void verifyUserNavigatesToScreen(String optVal) { androidTransactions.verifyAmountRngScreen(optVal);
    }

    @Then("verify back icon is present on Account Statement screen")
    public void verifyBackIconIsPresentOnAccountStatementScreen() { androidTransactions.verifyBackIcn();
    }

    @Then("verify Filter  is present on Account Statement screen")
    public void verifyFilterIsPresentOnAccountStatementScreen() { androidTransactions.verifyFilterBtn();
    }

    @Then("verify Image icon present on Account Statement screen")
    public void verifyImageIconPresentOnAccountStatementScreen() { androidTransactions.verifyImgIcon();
    }

    @Then("verify Account Name {string} is present on Account Statement screen")
    public void verifyAccountNameIsPresentOnAccountStatementScreen(String optVal) { androidTransactions.verifyAccName(optVal);
    }

    @Then("verify Account Number {string} is present on Account Statement screen")
    public void verifyAccountNumberIsPresentOnAccountStatementScreen(String optVal) { androidTransactions.verifyAccNo(optVal);
    }

    @Then("verify Amount {string} is present on Account Statement screen")
    public void verifyAmountIsPresentOnAccountStatementScreen(String optVal) { androidTransactions.verifyAccAmount(optVal);
    }

    @Then("verify Table containing Account Statement list items is present on Account Statement screen")
    public void verifyTableContainingAccountStatementListItemsIsPresentOnAccountStatementScreen() { androidTransactions.verifyList();
    }

    @Then("user click on Account Statement type in the list present on Account Statement screen")
    public void userClickOnAccountStatementTypeInTheListPresentOnAccountStatementScreen() { androidTransactions.clickAccStatmntType();
    }

    @Then("verify user navigated to Account Statement view screen")
    public void verifyUserNavigatedToAccountStatementViewScreen() { androidTransactions.verifyStatmntView();
    }

    @Then("verify whole statement is present by clicking on statement type")
    public void verifyWholeStatementIsPresentByClickingOnStatementType() { androidTransactions.verifyWholeStatmnt();
    }

    @Then("verify share statement icon is present on Account Statement view screen")
    public void verifyShareStatementIconIsPresentOnAccountStatementViewScreen() { androidTransactions.verifyShareStatmnt();
    }

    @Then("user selects credit card from the credit list")
    public void userSelectsCreditCardFromTheCreditList() { androidTransactions.selectCreditCard();
    }

    @Then("user scroll down to the Credit Cards section")
    public void userScrollDownToTheCreditCardsSection() { androidTransactions.scrollToCreditCrd();
    }

    @Then("verify user is navigated to Transaction Detail screen for credit card")
    public void verifyUserIsNavigatedToTransactionDetailScreenForCreditCard() { androidTransactions.verifyTransactionScreenCreditCrd();
    }

    @Then("user click on back arrow to navigate back to Transaction Detail screen for credit card")
    public void userClickOnBackArrowToNavigateBackToTransactionDetailScreenForCreditCard() { androidTransactions.clickBackIcon();
    }

    @Then("user click on Filter Icon present on Account Statement screen")
    public void userClickOnFilterIconPresentOnAccountStatementScreen() { androidTransactions.clickFilterIcn();
    }

    @Then("verify user is navigated to {string} screeen")
    public void verifyUserIsNavigatedToScreeen(String optVal) { androidTransactions.verifyAmountRngScreen(optVal);
    }

    @Then("verify {string} button on Account statement Filter screen")
    public void verifyButtonOnAccountStatementFilterScreen(String optVal) { androidTransactions.verifyResetBtn(optVal);
    }

    @Then("verify Cross Icon present on Account statement Filter screen")
    public void verifyCrossIconPresentOnAccountStatementFilterScreen() { androidTransactions.verifyCrossIcon();
    }

    @Then("verify {string} present on Account statement Filter screen")
    public void verifyPresentOnAccountStatementFilterScreen(String optVal) { androidTransactions.verifyDateRng(optVal);
    }

    @Then("verify label {string} present on Account statement Filter screen")
    public void verifyLabelPresentOnAccountStatementFilterScreen(String optVal) { androidTransactions.verifyFromField(optVal);
    }

    @Then("verify {string} field under {string} label present on Account statement Filter screen")
    public void verifyFieldUnderLabelPresentOnAccountStatementFilterScreen(String optVal1, String optVal2) { androidTransactions.verifyDateField(optVal1,optVal2);
    }

    @Then("verify {string} is present on Account statement Filter screen")
    public void verifyIsPresentOnAccountStatementFilterScreen(String optVal) { androidTransactions.verifyStatmntType(optVal);
    }

    @Then("verify {string} present under Statement Types")
    public void verifyPresentUnderStatementTypes(String optVal) { androidTransactions.verifyAmountRngScreen(optVal);
    }

    @Then("user click on PDF FULL switch under Statement Types")
    public void userClickOnPDFFULLSwitchUnderStatementTypes() { androidTransactions.clickPDFSwitch();
    }

    @Then("verify {string} is present on Acc statement Filter screen")
    public void verifyIsPresentOnAccStatementFilterScreen(String optVal) { androidTransactions.verifyApplyFilterBtn(optVal);
    }

    @Then("user click on {string} present on Acc statement Filter screen")
    public void userClickOnPresentOnAccStatementFilterScreen(String optVal) { androidTransactions.clickApplyFilterBtn(optVal);
    }

    @Then("verify {string} stamp present on Account Statement screen")
    public void verifyStampPresentOnAccountStatementScreen(String optVal) { androidTransactions.verifyFilterVal(optVal);
    }

    @Then("user click on share statement icon present on Account Statement view screen")
    public void userClickOnShareStatementIconPresentOnAccountStatementViewScreen() { androidTransactions.clickShareIcon();
    }

    @Then("verify cross icon  is present on Account Statement view screen")
    public void verifyCrossIconIsPresentOnAccountStatementViewScreen() { androidTransactions.verifyCrossIcnOnStatmntView();
    }

    @Then("user click on cross icon present on Account Statement view screen")
    public void userClickOnCrossIconPresentOnAccountStatementViewScreen() { androidTransactions.clickCrossIconOnStatView();
    }

    @Then("user click {string} button on Account statement Filter screen")
    public void userClickButtonOnAccountStatementFilterScreen(String optVal) { androidTransactions.clickFilterResetBtn(optVal);
    }

    @Then("user click on cross Icon on filtered stamp present on Account Statement screen")
    public void userClickOnCrossIconOnFilteredStampPresentOnAccountStatementScreen() { androidTransactions.clickCrossFilterStamp();
    }

    @Then("verify label {string} is present on Transaction Description screen android")
    public void verifyLabelIsPresentOnTransactionDescriptionScreenAndroid(String optVal) {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyType(optVal);
    }

    @Then("verify label {string} is present on Transaction Description screen ios")
    public void verifyLabelIsPresentOnTransactionDescriptionScreenIOS(String optVal) {
        if(!RunnerInfo.getDeviceType().equalsIgnoreCase("android"))androidTransactions.verifyType(optVal);
    }

    @Then("Click on {string} icon")
    public void UserClickOnStatementicon(String optVal)
    {
        androidTransactions.clickStatementIcon(optVal);
    }

    @Then("On Account statements screen click on filter icon at the top right corner")
    public void ClickOnFilterIcon()
    {
        androidTransactions.ClickFilterIcon();
    }

    @Then("On the {string} screen click on the X closure icon at the top left corner")
    public void ClickOnCloseIcon(String optVal)
    {
        androidTransactions.ClickClosecon(optVal);
    }

    @Then("Verify that on closing the filter screen complete account statements list should be displayed")
    public void VerifyXClosureFunctionality()
    {
        androidTransactions.VerifyFilterCloseIconFunctionality();
    }

    @Then("Verify that {string} screen appears")
    public void VerifyAccountStatementScreen(String optVal)
    {
        androidTransactions.VerifyAccountStatementScreen(optVal);
    }

    @Then("Click on back arrow icon")
    public void ClickBackArrow()
    {
        androidTransactions.ClickBackArrow();
    }

    @Then("Verify that user should route to filter statement flow {string}")
    public void VerifyDateStatement(String optVal)
    {
        androidTransactions.VerifyDateStatement(optVal);
    }

    @Then("Verify the {string} displayed on the page")
    public void VerifyFlterContent(String filterContent)
    {
        androidTransactions.VerifyFlterContent(filterContent);
    }

    @Then("Verify the list of {string} displayed on the page")
    public void StatementTypes(String statementtypes)
    {
        androidTransactions.VerifyStatementTypes(statementtypes);
    }

    @Then("Verify that each item of the {string} displayed a toggle")
    public void StatementTypesToggle(String statementtypes)
    {
        androidTransactions.VerifyStatementTypesToggle(statementtypes);
    }

    @Then("Verify that each toggle of the {string} allow user to move it ON")
    public void ToggleON(String statementtypes)
    {
        androidTransactions.VerifyToggleON(statementtypes);
    }

    @Then("Verify that each toggle of the {string} allow user to move it OFF")
    public void ToggleOFF(String statementtypes)
    {
        androidTransactions.VerifyToggleOFF(statementtypes);
    }

    @Then("Turn ON the toggle button for statment type {string}")
    public void ToggleButtonON(String statementtypes)
    {
        androidTransactions.ToggleButtonON(statementtypes);
    }

    @Then("Click on Apply filter button")
    public void ClickApplyBtn()
    {
        androidTransactions.ClickApplyBtn();
    }

    @Then("Verify that filter chip got displayed for {string} and {string}")
    public void VerifyStatementTypeFilterChip(String text1,String text2)
    {
        androidTransactions.VerifyStatementTypeFilterChip( text1, text2);
    }

    @Then("Verify that filtered statements contains {string} or {string}")
    public void VerifyStatementTypeFilter(String text1,String text2)
    {
        androidTransactions.VerifyStatementTypeFilter( text1, text2);
    }

    @Then("Select {string} by clicking on Set a date of {string} field")
    public void SelectDate(String text1,String text2)
    {
        androidTransactions.SelectDate( text1, text2);
    }

    @Then("Verify that account statements page updated with date range selected {string} to {string}")
    public void VerifyDateRange(String text1,String text2)
    {
        androidTransactions.VerifyDateRange( text1, text2);
    }

    @Then("Verify the Verbiage displayed when no results found")
    public void VerifyNoResultVerbiage()
    {
        androidTransactions.VerifyNoResultVerbiage();
    }

    @Then("Verify that {string} field after From selection allow the user to select a date >= {string}")
    public void ValidateToFiled(String text1,String text2)
    {
        androidTransactions.ValidateToFromFiled(text1, text2);
    }

    @Then("Verify that {string} field after To selection allow the user to select a date <= {string}")
    public void ValidateFromFiled(String text1,String text2)
    {
        androidTransactions.ValidateToFromFiled(text1, text2);
    }

    @Then("Verify that {string} field allow the user to select a date <= Today")
    public void VerifyToFromFiled(String text1)
    {
        androidTransactions.VerifyToFromFiled( text1);
    }

    @Then("verify user is navigated to Incoming Transaction Description screen")
    public void verifyUserIsNavigatedToIncomingTransactionDescriptionScreen() { androidTransactions.verifyIcmngTransactDescScreen();
    }

    @Then("Verify that {string} appears against each transaction")
    public void VerifyTransactioType(String type)
    {
        androidTransactions.VerifyTransactionType(type);
    }

    @Then("Verify that {string} appearss against each transaction")
    public void VerifyTransactionAmount(String amount)
    {
        androidTransactions.VerifyTransactionAmount(amount);
    }

    @Then("Verify that the transactions are displayed in descending order")
    public void VerifyTransactionDescending() throws ParseException
    {
        androidTransactions.VerifyTransactionDescending();
    }
}
