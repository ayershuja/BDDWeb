package StepDefinitions.Mobile;

import Pages.actions.Mobile.InternationalBeneficiaryAccountPage_Mobile;
import StepDefinitions.RunnerInfo;
import io.cucumber.java.en.Then;

public class InternationalBeneficiaryAccountSteps_Mobile {
    InternationalBeneficiaryAccountPage_Mobile internationalBeneficiaryAccountPage_mobile = new InternationalBeneficiaryAccountPage_Mobile();

    @Then("verify inline error message is shown {string} under {string} field")
    public void verify_inline_error_message(String message, String field) throws InterruptedException {
        internationalBeneficiaryAccountPage_mobile.VerifyInlineErrorMessage(message, field);
    }

    @Then("verify ghost message is shown {string} under {string} field")
    public void VerifyGhostText(String message, String field) throws InterruptedException {
        internationalBeneficiaryAccountPage_mobile.VerifyGhostText(message, field);
    }

    @Then("verify ghost message is shown {string} under {string} field android")
    public void VerifyGhostTextAndroid(String message, String field) throws InterruptedException {
        if (RunnerInfo.getDeviceType().contains("android")) internationalBeneficiaryAccountPage_mobile.VerifyGhostText(message, field);
    }

    @Then("verify ghost message is shown {string} under {string} field ios")
    public void VerifyGhostTextiOS(String message, String field) throws InterruptedException {
        if (!RunnerInfo.getDeviceType().contains("android")) internationalBeneficiaryAccountPage_mobile.VerifyGhostText(message, field);
    }
    @Then("user enter {string} name")
    public void enterEnterFullName(String fullName) {
        internationalBeneficiaryAccountPage_mobile.enterEnterFullName("internationalBeneficiaryAccount", fullName);
    }

    @Then("user enter {string} swift code")
    public void enterSwiftCode(String value) {
        internationalBeneficiaryAccountPage_mobile.enterSwiftCode("internationalBeneficiaryAccount", value);
    }

    @Then("user {string} swift code switch")
    public void switchSwiftCode(String key) {
        internationalBeneficiaryAccountPage_mobile.switchSwiftCode(key);
    }

    @Then("user enter {string} value in search text box")
    public void enterValueInSearch(String key) {
        internationalBeneficiaryAccountPage_mobile.enterValueInSearch("internationalBeneficiaryAccount", key);
    }

    @Then("user enter {string} account number")
    public void enterAccountNumber(String key) {
        internationalBeneficiaryAccountPage_mobile.enterAccountNumber("internationalBeneficiaryAccount", key);
    }

    @Then("verify characters are not more than under {int} for swift code field")
    public void verifyCharactersAreNotMoreThanUnderForSwiftCodeField(int characerLimit) {
        internationalBeneficiaryAccountPage_mobile.verifySwiftCodeLimit(characerLimit);
    }
}
