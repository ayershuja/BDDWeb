package StepDefinitions.Mobile;

import DriverManager.Driver;
import Pages.actions.Mobile.InternalTransferPage_Mobile;
import StepDefinitions.RunnerInfo;
import io.cucumber.java.en.Then;


public class InternalTransferSteps_Mobile {

    InternalTransferPage_Mobile internalTransfer = new InternalTransferPage_Mobile();
    Driver driver = new Driver();

//    @Then("verify {string} page is open")
//    public void verifyPageIsOpen(String arg0) {
//    }

    @Then("user click on from to select account to transfer from")
    public void userClickOnToSelectAccountToTransferFrom() {
        internalTransfer.clickFrom();
    }

//    @Then("verify {string}  page is open")
//    public void verifyPageIsOpen(String arg0) {
//    }

    @Then("user selects {string} account")
    public void userSelectsAccount(String optVal) {
        internalTransfer.selectAcc(optVal);
    }

    @Then("user click on to section to select account to transfer to")
    public void userClickOnToSelectAccountToTransferTo() {
        internalTransfer.clickTo();
    }


    @Then("user click on {string} button in transfer across my accounts page")
    public void userClickOnButtonInTransferAcrossMyAccountsPage(String optVal) {
        internalTransfer.clickButtnContinue(optVal);
    }

    @Then("verify the entered amount is visible")
    public void verifyTheEnteredAmountIsVisible() {
        internalTransfer.verifyEnteredAmount();
    }

    @Then("user click on {string} button in review page")
    public void userClickOnButtonInReviewPage(String optionVal) {
        internalTransfer.clickButtnContinue(optionVal);
    }

    @Then("user click on {string} button on transfer completion")
    public void userClickOnButtonOnTransferCompletion(String optVal) {
        internalTransfer.clickButtnCompletion(optVal);
    }

//    @Then("verify {string} page is open")
//    public void verifyPageIsOpen(String arg0) {
//    }

    @Then("user verify {string} page is open")
    public void userVerifyPageIsOpen(String optionVal) {
        internalTransfer.verifySlctAccPage(optionVal);
    }

    @Then("user verify {string} page is open android")
    public void userVerifyPageIsOpenAndroid(String optionVal) {
        if (RunnerInfo.getDeviceType().contains("android"))  internalTransfer.verifySlctAccPage(optionVal);
    }

    @Then("user verify {string} page is open ios")
    public void userVerifyPageIsOpenIos(String optionVal) {
        if (!RunnerInfo.getDeviceType().contains("android"))  internalTransfer.verifySlctAccPage(optionVal);
    }

    @Then("user click on Transfer money between accounts option")
    public void userClickOnTransferMoneyBetweenAccountsOption() {
        internalTransfer.clickTransferMonBtwnOwnAcc();
    }

    @Then("user verify Transfer across my accounts page is open")
    public void userVerifyTransferAcrossMyAccountsPageIsOpen() {
        internalTransfer.verifyTransferAccrsMyAccPage();
    }

    @Then("user verify Review page is open")
    public void userVerifyReviewPageIsOpen() {
        internalTransfer.verifyReviewPage();
    }

    @Then("user click on back navigator")
    public void userClickOnBackNavigator() {
        internalTransfer.clickNavigateBack();
    }

    @Then("user verify transaction is successfull")
    public void userVerifyTransactionIsSuccessfull() {
        internalTransfer.verifySuccess();
    }

    @Then("verify From Account error message {string}")
    public void verifyFromAccountErrorMessage(String optVal) {
        internalTransfer.verifyAccErrorMsg(optVal);
    }

    @Then("verify To Account error message {string}")
    public void verifyToAccountErrorMessage(String optVal) {
        internalTransfer.verifyToAccErrMsg(optVal);
    }

    @Then("user click on Bill Pay option")
    public void userClickOnBillPayOption() {
        internalTransfer.clickBillPay();
    }

    @Then("verify Bill Pay page is open")
    public void verifyBillPayPageIsOpen() {
        internalTransfer.verifyBillPay();
    }

    @Then("user verify the selected account previously is selectable or not")
    public void userVerifyTheSelectedAccountpreviouslyIsSelectableOrNot() {
        if (RunnerInfo.getDeviceType().contains("android")) internalTransfer.verifyAccClickable();
    }

    @Then("user verify the selected account in To is selectable or not")
    public void userVerifyTheSelectedAccountInToIsSelectableOrNot() {
        if (RunnerInfo.getDeviceType().contains("android")) internalTransfer.verifyAccFromClickable();
    }

    @Then("verify amount input default should be {string}")
    public void verifyAmountInputDefaultShouldBe(String optVal) {
        internalTransfer.verifyDefaultAmount(optVal);
    }

    @Then("verify currency is default set to source account currency {string}")
    public void verifyCurrencyIsDefaultSetToSourceAccountCurrency(String optVal) {
        internalTransfer.verifySourceCurreny(optVal);
    }

    @Then("user click on currency selector button")
    public void userClickOnCurrencySelectorButton() {
        internalTransfer.clickCurrencySlctr();
    }

    @Then("user click on currency option {string}")
    public void userClickOnCurrencyOption(String optVal) {
        internalTransfer.clickCurrency(optVal);
    }

    @Then("user select an accout with same currency as From account")
    public void userSelectAnAccoutWithSameCurrencyAsFromAccount() {
        internalTransfer.clickAccSameCurr();
    }

    @Then("user click on back navigator on From page")
    public void userClickOnBackNavigatorOnFromPage() {
        internalTransfer.clickBackNavigator();
    }


    @Then("verify {string} button is present")
    public void verifyButtonIsPresent(String optVal) {
        internalTransfer.verifyContBtn(optVal);
    }

    @Then("user verify {string} button is present on review screen")
    public void userVerifyButtonIsPresentOnReviewScreen(String optVal) { internalTransfer.verifyConfirmSendBtn(optVal);
    }

    @Then("user clicks {string} button on review screen")
    public void userClicksButtonOnReviewScreen(String optVal) { internalTransfer.clickConfirmSendBtn(optVal);
    }

    @Then("verify {string} is present on review screen")
    public void verifyIsPresentOnReviewScreen(String optVal) { internalTransfer.verifyTransferAmount(optVal);
    }

    @Then("verify label {string} is present on review screen")
    public void verifyLabelIsPresentOnReviewScreen(String optVal) { internalTransfer.verifyDetailLabel(optVal);
    }

    @Then("verify {string} is displayed in details section")
    public void verifyIsDisplayedInDetailsSection(String optVal) { internalTransfer.verifyInclTransferFee(optVal);
    }

    @Then("verify label {string} is displayed on review screen")
    public void verifyLabelIsDisplayedOnReviewScreen(String optVal) { internalTransfer.verifyLabelOnRevScreen(optVal);
    }
}
