package StepDefinitions.Mobile;

import Pages.actions.Mobile.MorePage_Mobile;
import io.cucumber.java.en.Then;

public class UnlinkDeviceSteps_Mobile {

    MorePage_Mobile morePage_mobile = new MorePage_Mobile();

    @Then("user clicks on settings icon")
    public void userClicksOnSettingsIcon() {
        morePage_mobile.clickSettingsIcon();
    }

    @Then("verify settings page is open")
    public void verifySettingsPageIsOpen() {
        morePage_mobile.verifySettingsScreen();
    }

    @Then("user taps on unlink device option")
    public void userTapsOnUnlinkDeviceOption() {
        morePage_mobile.clickOnUnlinkDeviceOption();
    }

    @Then("verify popup for unlink device")
    public void verifyPopupForUnlinkDevice() {
        morePage_mobile.verifyModalPopUp();
    }

    @Then("user clicks on unlink button")
    public void userClicksOnUnlinkButton() {
        morePage_mobile.clickUnlinkDevice();
    }

    @Then("user click on cancel icon on settings page")
    public void userClickOnCancelIconOnSettingsPage() {
        morePage_mobile.clickCancelButton();
    }
}
