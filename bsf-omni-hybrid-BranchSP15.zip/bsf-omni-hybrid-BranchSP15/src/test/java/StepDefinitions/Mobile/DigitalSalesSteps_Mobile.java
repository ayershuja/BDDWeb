package StepDefinitions.Mobile;

import Pages.actions.Mobile.DigitalSalesPage_Mobile;
import io.cucumber.java.en.Then;

public class DigitalSalesSteps_Mobile {

    DigitalSalesPage_Mobile digitalSales = new DigitalSalesPage_Mobile();

    @Then("user clicks on {string} button on Welcome Screen")
    public void userClicksOnButtonOnWelcomeScreen(String optVal) {
        digitalSales.clickOpenAcc(optVal);
    }

    @Then("user clicks on {string} button from the first Walkthrough Marketing screen")
    public void userClicksOnButtonFromTheFirstWalkthroughMarketingScreen(String optVal) {
        digitalSales.clickNextBtn(optVal);
    }

    @Then("user clicks on {string} button from the second Walkthrough Marketing screen")
    public void userClicksOnButtonFromTheSecondWalkthroughMarketingScreen(String optVal) {
        digitalSales.clickNextBtn(optVal);
    }

    @Then("user taps on Terms and Conditions Checkbox")
    public void userTapsOnTermsAndConditionsCheckbox() {
        digitalSales.tapCheckBox();
    }

    @Then("user clicks on {string} button in the bottom of page")
    public void userClicksOnButtonInTheBottomOfPage(String optVal) {
        digitalSales.clickGetStrtdBtn(optVal);
    }

    @Then("verify user is navigated to {string} page")
    public void verifyUserIsNavigatedToPage(String optVal) {
        digitalSales.verifyRegst(optVal);
    }

    @Then("user verify {string} label is present")
    public void userVerifyLabelIsPresent(String optVal) {
        digitalSales.verifyLabel(optVal);
    }

    @Then("verify label {string} is present")
    public void verifyLabelIsPresent(String optVal) {
        digitalSales.verifyLbl(optVal);
    }

    @Then("verify {string} is present above text bar")
    public void verifyIsPresentAboveTextBar(String optVal) {
        digitalSales.verifyTxt(optVal);
    }

    @Then("verify {string} below the text bar")
    public void verifyBelowTheTextBar(String optVal) {
        digitalSales.verifyErr(optVal);
    }

    @Then("user enter Iqama Number less than ten characters in text field")
    public void userEnterIqamaNumberLessThanCharactersInTextField() {
        digitalSales.enterIqama();
    }

    @Then("verify error message {string} is present")
    public void verifyErrorMessageIsPresent(String optVal) {
        digitalSales.verifyErr(optVal);
    }

    @Then("user enter Iqama Number that doesnot starts from numeric one or two")
    public void userEnterIqamaNumberThatDoesnotStartsFromumericOneOrTwo() {
        digitalSales.enterIqama();
    }

    @Then("user enter non Numeric value in Iqama Number text field")
    public void userEnterNonNumericValueInIqamaNumberTextField() {
        digitalSales.enterIqamaNonNum();
    }

    @Then("user clicks on {string} button from the second Walkthrough Marketing screen to navigate back")
    public void userClicksOnButtonFromTheSecondWalkthroughMarketingScreenToNavigateBack(String optVal) {
        digitalSales.clickBack(optVal);
    }

    @Then("verify user is navigated to first walkthrough screen")
    public void verifyUserIsNavigatedToFirstWalkthroughScreen() {
        digitalSales.verifyFirstWalkthroughScreen();
    }

    @Then("verify user is navigated to Terms and Conditions screen")
    public void verifyUserIsNavigatedToTermsAndConditionsScreen() {
        digitalSales.verifyTermsScreen();
    }

    @Then("verify user is navigated to second walkthrough screen")
    public void verifyUserIsNavigatedToSecondWalkthroughScreen() {
        digitalSales.verifySecondWalkthroughScreen();
    }

    @Then("verify Image is displayed on second walkthrough screen")
    public void verifyImageIsDisplayedOnSecondWalkthroughScreen() {
        digitalSales.verifyImg();
    }

    @Then("verify heading {string} is present on second walkthrough screen")
    public void verifyHeadingIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifyHeading(optVal);
    }

    @Then("verify sub text {string} is present on second walkthrough screen")
    public void verifySubTextIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifySubText(optVal);
    }

    @Then("verify first point {string} is present on second walkthrough screen")
    public void verifyFirstPointIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifyFirstPoint(optVal);
    }

    @Then("vreify first point subText {string} is present on second walkthrough screen")
    public void vreifyFirstPointSubTextIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifyFirstPointSubText(optVal);
    }

    @Then("verify second point {string} is present on second walkthrough screen")
    public void verifySecondPointIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifyScndPoint(optVal);
    }

    @Then("verify third point {string} is present on second walkthrough screen")
    public void verifyThirdPointIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifyThrdPoint(optVal);
    }

    @Then("verify fourth point {string} is present on second walkthrough screen")
    public void verifyFourthPointIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifyForthPoint(optVal);
    }

    @Then("verify fifth point {string} is present on second walkthrough screen")
    public void verifyFifthPointIsPresentOnSecondWalkthroughScreen(String optVal) {
        digitalSales.verifyFifthPoint(optVal);
    }

    @Then("verify {string} button from the second Walkthrough Marketing screen is present")
    public void verifyButtonFromTheSecondWalkthroughMarketingScreenIsPresent(String optVal) {
        digitalSales.verifyBackBtn(optVal);
    }

    @Then("verify {string} button on the second Walkthrough Marketing screen is present")
    public void verifyButtonOnTheSecondWalkthroughMarketingScreenIsPresent(String optVal) {
        digitalSales.verifyNextBtn(optVal);
    }

    @Then("user Taps on {string} button from first Walkthrough Marketing screen")
    public void userTapsOnButtonFromFirstWalkthroughMarketingScreen(String optVal) {
        digitalSales.clickSkipBtn(optVal);
    }

    @Then("verify Image is displayed on first walkthrough screen")
    public void verifyImageIsDisplayedOnFirstWalkthroughScreen() {
        digitalSales.verifyImg();
    }

    @Then("verify heading {string} is present on first walkthrough screen")
    public void verifyHeadingIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifyHeadingFrstWalkThrough(optVal);
    }

    @Then("verify sub text {string} is present on first walkthrough screen")
    public void verifySubTextIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifySubTextFirstWlkThru(optVal);
    }

    @Then("verify first point {string} is present on first walkthrough screen")
    public void verifyFirstPointIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifyFirstPointFrstWlkThru(optVal);
    }

    @Then("verify first point subText {string} is present on first walkthrough screen")
    public void verifyFirstPointSubTextIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifyFrstPointSubTxt(optVal);
    }

    @Then("verify second point {string} is present on first walkthrough screen")
    public void verifySecondPointIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifySecondPoint(optVal);
    }

    @Then("verify second point subText {string} is present on first walkthrough screen")
    public void verifySecondPointSubTextIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifyScndPointSubTxt(optVal);
    }

    @Then("verify third point {string} is present on first walkthrough screen")
    public void verifyThirdPointIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifyThirdPoint(optVal);
    }

    @Then("verify third point subText {string} is present on first walkthrough screen")
    public void verifyThirdPointSubTextIsPresentOnFirstWalkthroughScreen(String optVal) {
        digitalSales.verifyThirdPointSubTxt(optVal);
    }

    @Then("verify {string} button from the first Walkthrough Marketing screen is present")
    public void verifyButtonFromTheFirstWalkthroughMarketingScreenIsPresent(String optVal) {
        digitalSales.verifyBackBtn(optVal);
    }

    @Then("verify {string} button on the first Walkthrough Marketing screen is present")
    public void verifyButtonOnTheFirstWalkthroughMarketingScreenIsPresent(String optVal) {
        digitalSales.verifyNextBtn(optVal);
    }

    @Then("user clicks on {string} button from Terms and Conditions screen")
    public void userClicksOnButtonFromTermsAndConditionsScreen(String optVal) {
        digitalSales.clickBack(optVal);
    }

    @Then("verify {string} button is enabled in the bottom of screen")
    public void verifyButtonIsEnabledInTheBottomOfScreen(String optVal) {
        digitalSales.verifyGetStartBtn(optVal);
    }

    @Then("verify Image is displayed on Terms and Conditions screen")
    public void verifyImageIsDisplayedOnTermsAndConditionsScreen() {
        digitalSales.verifyImg();
    }

    @Then("verify heading {string} is present on Terms and Conditions screen")
    public void verifyHeadingIsPresentOnTermsAndConditionsScreen(String optVal) {
        digitalSales.verifyHdingTC(optVal);
    }

    @Then("verify sub text {string} is present on Terms and Conditions screen")
    public void verifySubTextIsPresentOnTermsAndConditionsScreen(String optVal) {
        digitalSales.verifySubHding(optVal);
    }

    @Then("verify {string} is present on Terms and Conditions screen")
    public void verifyIsPresentOnTermsAndConditionsScreen(String optVal) {
        digitalSales.verifyTandCtext(optVal);
    }

    @Then("verify {string} button from the Terms and Condition screen is present")
    public void verifyButtonFromTheTermsAndConditionScreenIsPresent(String optVal) {
        digitalSales.verifyBackBtn(optVal);
    }

    @Then("verify non Numeric values are unable to enter in text field")
    public void verifyNonNumericValuesAreUnableToEnterInTextField() {
        digitalSales.verifyNonNumTxtField();
    }

    @Then("user enter Iqama Number greater than ten characters in text field")
    public void userEnterIqamaNumberGreaterThanTenCharactersInTextField() {
        digitalSales.verifyTxTgreterThnTen();
    }

    @Then("verify that user is not allowed to enter more than ten characters")
    public void verifyThatUserIsNotAllowedToEnterMoreThanTenCharacters() {
        digitalSales.verifyTxtArea();
    }

    @Then("user enter Iqama Number that doesnot pass the checkSum rules")
    public void userEnterIqamaNumberThatDoesnotPassTheCheckSumRules() {
        digitalSales.enterIqama();
    }
}
