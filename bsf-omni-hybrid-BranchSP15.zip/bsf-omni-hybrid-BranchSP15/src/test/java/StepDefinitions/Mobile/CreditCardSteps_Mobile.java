package StepDefinitions.Mobile;

import io.cucumber.java.en.Then;
import Pages.actions.Mobile.MyProductsPage_Mobile;
import Pages.actions.Mobile.CreditCardPage_Mobile;


public class CreditCardSteps_Mobile {
    MyProductsPage_Mobile myProductsPage_mobile = new MyProductsPage_Mobile();
    CreditCardPage_Mobile creditCardPage_mobile = new CreditCardPage_Mobile();

    @Then("user select credit card")
    public void selectCreditCard() {
        myProductsPage_mobile.clickOnCreditCard();
    }

    @Then("user verify {string} header and {string} message is displayed or not")
    public void verifyHeaderMessage(String header, String message) {
        creditCardPage_mobile.verifyHeaderMessage(header, message);
    }

    @Then("user verify transaction detail is displayed in descending order")
    public void verifyTransactionDetailInDescendingOrder() {
        creditCardPage_mobile.verifyTransactionDate();
    }

    @Then("user verify card holder name is displayed")
    public void verifyCardHolderName() {
        creditCardPage_mobile.verifyCardHolderNameIsDisplayed();
    }

    @Then("user verify card expiry date is displayed")
    public void verifyCardExpiryDate() {
        creditCardPage_mobile.verifyExpiryDateIsDisplayed();
    }

    @Then("verify the {string} screen")
    public void verifyTheTitle(String titleText) {
        creditCardPage_mobile.verifyTitle(titleText);
    }

    @Then("verify the account icon is displayed")
    public void verifyTheAccountIcon() {
        creditCardPage_mobile.verifyAccountIcon();
    }

    @Then("user click on edit account name")
    public void clickOnEditAccountName() {
        creditCardPage_mobile.clickOnEditAccountName();
    }

    @Then("user click on closes button")
    public void clickOnCloseButton() {
        creditCardPage_mobile.clickOnCloseButton();
    }

    @Then("user clicks on the navigate back icon my credit cards page")
    public void userClicksOnTheNavigateBackIconMyCreditCardsPage() {
        creditCardPage_mobile = new CreditCardPage_Mobile();
        creditCardPage_mobile.selectBackButton();
    }

    @Then("save the credit card name")
    public void saveTheCreditCardName() {
        creditCardPage_mobile.saveCreditCardName();
    }

    @Then("user clicks on the edit icon")
    public void userClicksOnTheEditIcon() {
        creditCardPage_mobile.clickOnEditAccountName();
    }

    @Then("verify do you want rename this account popup is open")
    public void verifyDoYouWantRenameThisAccountPopupIsOpen() {
        creditCardPage_mobile.verifyRenameCardScreen();
    }

    @Then("clear the credit card name input field")
    public void clearTheCreditCardNameInputField() {
        creditCardPage_mobile.clearCreditCardField();
    }

    @Then("verify error {string}")
    public void verifyError(String errorMessage) {
        creditCardPage_mobile.nameFieldError(errorMessage);
    }

    @Then("user inputs {string} into the credit card field name")
    public void userInputsCharactersIntoTheCreditCardFieldName(String cardName) {
        creditCardPage_mobile.inputCharacterIntoCardField(cardName);
    }

    @Then("user clicks on save button")
    public void userClicksOnSaveButton() {
        creditCardPage_mobile.clickSaveButton();
    }

    @Then("verify the success screen is open")
    public void verifyTheSuccessScreenIsOpen() {
        creditCardPage_mobile.verifySuccessScreen();
    }

    @Then("user click on close button on success screen")
    public void userClickOnCloseButtonOnSuccessScreen() {
        creditCardPage_mobile.successScreenCloseButton();
    }

    @Then("verify credit card name is {string}")
    public void verifyCreditCardNameIs(String creditCardName) {
        creditCardPage_mobile.verifyCreditCardName(creditCardName);
    }

    @Then("revert the name to orignal value")
    public void revertTheNameToOrignalValue() {
        creditCardPage_mobile.revertToOrignalValue();
    }

    @Then("verify available cash limit is {string}")
    public void verifyAvailableCashLimitIs(String cashLimit) {
        creditCardPage_mobile.verifyAvailableCashLimit(cashLimit);
    }

    @Then("verify minimum payment percentage is {string}")
    public void verifyMinimumPaymentPercentageIs(String minimumPayment) {
        creditCardPage_mobile.verifyMinimumPaymentPercentage(minimumPayment);
    }

    @Then("verify total due amount is {string}")
    public void verifyTotalDueAmountIs(String totalDueAmount) {
        creditCardPage_mobile.verifyTotalDueAmount(totalDueAmount);
    }

    @Then("verify minimum due amount is {string}")
    public void verifyMinimumDueAmountIs(String minimumDueAmount) {
        creditCardPage_mobile.verifyMinimumDueAmount(minimumDueAmount);
    }

    @Then("verify payment due amount is {string}")
    public void verifyPaymentDueAmountIs(String paymentDueAmount) {
        creditCardPage_mobile.verifyPaymentDueDate(paymentDueAmount);
    }
}
