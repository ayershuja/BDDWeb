package StepDefinitions.Mobile;

import Pages.actions.Mobile.PaymentsPage_Mobile;
import StepDefinitions.RunnerInfo;
import io.cucumber.java.en.Then;

public class PaymentsSteps_Mobile {
    PaymentsPage_Mobile paymentsPage_mobile = new PaymentsPage_Mobile();

    @Then("verify user the payments screen is open")
    public void verifyThePaymentsPageIsOpen() {
        paymentsPage_mobile = new PaymentsPage_Mobile();
        paymentsPage_mobile.verifyPaymentsScreen();
    }

    @Then("user clicks on transfer money to someone button")
    public void userClicksOnTransferMoneyToSomeoneButton() {
        paymentsPage_mobile.clickPaymentTransferToSomeone();
    }

    @Then("verify select beneficiary screen is open")
    public void verifySelectBeneficiaryScreenIsOpen() {
        paymentsPage_mobile.verifySelectBeneficiaryScreen();
    }

    @Then("user clicks on beneficiary with name {string}")
    public void userClicksOnBeneficiaryWithName(String beneficiaryName) {
        paymentsPage_mobile.selectBeneficiary(beneficiaryName);
    }

    @Then("verify user the {string} is open")
    public void verifyUserTheIsOpen(String screenName) {
        paymentsPage_mobile.verifyScreenOpen(screenName);
    }

    @Then("verify option-text {string} is available")
    public void verifyOptionTextIsAvailable(String optionValue) {
        paymentsPage_mobile.verifyOptionValue(optionValue);
    }

    @Then("verify search field is displayed")
    public void verifySearchFieldIsDisplayed() {
        paymentsPage_mobile.verifySearchField();
    }

    @Then("verify all account on select beneficiary page are in alphabetical order")
    public void verifyAllAccountOnSelectBeneficiaryPageAreInAlphabeticalOrder() {
        paymentsPage_mobile.verifyAccountsInAlphabeticalOrder();
    }

    @Then("verify all users have {string} displayed")
    public void verifyAllUsersHaveDisplayed(String verifyLabel) {
        paymentsPage_mobile.verifyBeneficiariesDetails(verifyLabel);
    }

    @Then("verify select account details {string} is {string}")
    public void verifySelectAccountDetailsNameIs(String label, String accountName) {
        paymentsPage_mobile.verifySelectAccountScreenDetails(label, accountName);
    }

    @Then("user clicks on account with name {string} with currency {string}")
    public void userClicksOnAccountWithName(String selectAccountName, String currencyType) {
        paymentsPage_mobile.selectAccount(selectAccountName, currencyType);
    }

    @Then("verify label {string} is available on the screen with type {string}")
    public void verifyLabelIsAvailableOnTheScreen(String labelValue, String type) {
        paymentsPage_mobile.verifyLabelValue(labelValue, type);
    }

    @Then("verify label {string} is available on the screen with type {string} android")
    public void verifyLabelIsAvailableOnTheScreenAndroid(String labelValue, String type) {
        if (RunnerInfo.getDeviceType().contains("android"))paymentsPage_mobile.verifyLabelValue(labelValue, type);
    }

    @Then("verify label {string} is available on the screen with type {string} ios")
    public void verifyLabelIsAvailableOnTheScreeniOS(String labelValue, String type) {
        if (!RunnerInfo.getDeviceType().contains("android"))paymentsPage_mobile.verifyLabelValue(labelValue, type);
    }

    @Then("verify label-button {string} is available on the screen with type {string}")
    public void verifyLabelButtonIsAvailableOnTheScreen(String labelValue, String type) {
        paymentsPage_mobile.verifyLabelButtonValue(labelValue, type);
    }

    @Then("click label-button {string} is available on the screen with type {string}")
    public void clickLabelButtonIsAvailableOnTheScreen(String labelValue, String type) {
        paymentsPage_mobile.clickLabelButtonValue(labelValue, type);
    }

    @Then("verify amount helper text is {string}")
    public void verifyAmountHelperTextIs(String helperText) {
        paymentsPage_mobile.verifyHelperTextr(helperText);
    }

    @Then("user clicks on purpose selecter with option {string}")
    public void userClicksOnPurposeSelecterWithOption(String optionValue) {
        paymentsPage_mobile.clickPuposeSelector(optionValue);
    }

    @Then("verify other purpose helper selector is {string}")
    public void verifyOtherPurposeHelperSelectorIs(String helperText) {
        paymentsPage_mobile.verifyOtherPurposeHelperText(helperText);
    }

    @Then("user clicks on Button {string}")
    public void userClicksOnButton(String button) {
        paymentsPage_mobile.clickOnButton(button);
    }

    @Then("verify other purpose error message {string}")
    public void verifyOtherPurposeErrorMessage(String errorMessage) {
        paymentsPage_mobile.verifyOtherPurposeErrorMessage(errorMessage);
    }

    @Then("verify select purpose error message {string}")
    public void verifySelectPurposeErrorMessage(String errorMessage) {
        paymentsPage_mobile.verifySelectErrorMessage(errorMessage);
    }

    @Then("verify amount input error message {string}")
    public void verifyAmountInputErrorMessage(String amountError) {
        paymentsPage_mobile.verifyAmountError(amountError);
    }

    @Then("input transfer amount {string}")
    public void inputTransferAmount(String amount) {
        paymentsPage_mobile.verifyTransferAmount(amount);
    }

    @Then("verify transfer complete success icon")
    public void verifyTransferCompleteSuccessIcon() {
        paymentsPage_mobile.verifyTransferCompleteSuccessIcon();
    }
}
