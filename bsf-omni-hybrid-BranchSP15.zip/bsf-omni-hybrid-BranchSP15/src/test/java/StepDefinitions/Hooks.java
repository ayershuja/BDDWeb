package StepDefinitions;

import DriverManager.Driver;
import Utils.API;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.stream.Collectors;


public class Hooks {
    private Scenario scenario;
    RunnerInfo runnerInfo;

    Driver driver;


//	@Before("@android")
//	public void setUpAndroid() {
//		System.out.println("Before Setup Started");
//		try {
//			Driver.setUp("Android");
//		} catch (Exception e) {
//			System.out.println("Cause: " + e.getCause());
//			System.out.println("Message: " + e.getMessage());
//			e.printStackTrace();
//		}
//		System.out.println("Application Started");
//	}
//
//	@Before("@iOS")
//	public void setUpIos() {
//		System.out.println("Before Setup Started");
//		try {
//			Driver.setUp("IOS");
//		} catch (Exception e) {
//			System.out.println("Cause: " + e.getCause());
//			System.out.println("Message: " + e.getMessage());
//			e.printStackTrace();
//		}
//		System.out.println("Application Started");
//	}

    //    @Before("@browser")
//    public void setUpBrowser() {
//        System.out.println("Before Setup Started");
//        try {
//            Driver.setUp("browser");
//        } catch (Exception e) {
//            System.out.println("Cause: " + e.getCause());
//            System.out.println("Message: " + e.getMessage());
//            e.printStackTrace();
//        }
//        System.out.println("Application Started");
//    }
@Before("@mobile")
public void before(Scenario scenario) {
         scenario.log("Test scenario for " + RunnerInfo.getDeviceType());
//        String featureName = "Test cases for android";
//        String rawFeatureName = scenario.getName().split(";")[0].replace("-"," ");
//        featureName = featureName + rawFeatureName.substring(0, 1).toUpperCase() + rawFeatureName.substring(1);
//        JsonParser.Feature feature = JsonParser.Feature.valueOf(featureName);
//    }
//    else{
//
//    }
    }

    @After("@mobile")
    public void tearDownMobile() {
        String name = RunnerInfo.getDeviceType();


//
//        Set<String> keys = Driver.driver.keySet();
//        // Iterate over the keys and print them
//        for (String key : keys) {
//            if(key.contains("android")) {
//                name = key;
//            }
//        }
//        if(name.contains("browserstack")){
//            ((AppiumDriver) Driver.driver.get(name)).quit();
////            ((AppiumDriverLocalService) Driver.appiumDriverLocalServices.get(name)).stop();
//        }
//        else {
//            for (AppiumDriverLocalService appiumDriver : Driver.appiumDriverLocalServices.get(name)) {
//                ((AppiumDriver) Driver.driver.get(name)).quit();
//                appiumDriver.stop();
//            }
//        }
        ((AppiumDriver) Driver.driver.get(name)).quit();
//        for (AppiumDriverLocalService appiumDriver : Driver.appiumDriverLocalServices.get(name)) {
//            appiumDriver.stop();
//        }
        Driver.stopAppium();
    }

    @After("@browser")
    public void tearDownBrowser(Scenario scenario) {
//        ((AppiumDriver) driver).quit();
        String name = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("deviceType");
//
//        String name  = RunnerInfo.getName();
        ((WebDriver) Driver.driver.get(name)).quit();

        API api_url = new API();
        String status = String.valueOf(scenario.getStatus());
        String tc_name = scenario.getName();
        String tc_id = getTag((List<String>) scenario.getSourceTagNames());
        api_url.myMethod(String.valueOf(scenario.getStatus()), tc_id, tc_name);
//        driver.stopBrowserDriver();
    }


    @AfterMethod
    @AfterStep
    public void TakeScreenshotFailure(Scenario scenario) throws FileNotFoundException {
        if (scenario.isFailed() || String.valueOf(scenario.getStatus()).contains("undefined")) {
            TakesScreenshot ts = (TakesScreenshot) Driver.driver.get(RunnerInfo.getDeviceType());
            byte[] src = ts.getScreenshotAs(OutputType.BYTES);
            scenario.attach(src, "image/png", "screenshot");
        }
    }
    protected String getTag(List<String> tagsNames) {
        return tagsNames.stream()
                .filter(filter -> filter.startsWith("@tag:"))
                .map(filter -> filter.substring(5)).collect(Collectors.joining());
    }
}
