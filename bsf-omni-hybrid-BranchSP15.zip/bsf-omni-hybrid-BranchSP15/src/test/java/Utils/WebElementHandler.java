package Utils;

import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

public class WebElementHandler {
    public List<String> getTextFromWebElements(List<WebElement> elementArray) {
        List<String> elementList = new ArrayList<>();
        elementArray.forEach(element -> {
            System.out.println("Element:" + element.getText());
            elementList.add(element.getText());
        });
        return elementList;
    }
}
