package Utils;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class API {
    private OkHttpClient client;
    private JsonObject apiUrls;

    public API() {
        client = new OkHttpClient.Builder()
                .connectTimeout(800, TimeUnit.SECONDS)
                .build();
    }
    //This method is used to get the response the api
    public String hitAPI(String postData, String url) {
        OkHttpClient client = new OkHttpClient();

        // Define the media type of the request body
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");

        // Create the request body with the postData
        RequestBody requestBody = RequestBody.create(mediaType, postData);

        Request request = new Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Accept", "application/json")
                .build();



//        MediaType mediaType = MediaType.parse("text/plain");
//
//// Create the response body with the string content
////        RequestBody requestBody = RequestBody.create(mediaType, postData);
////        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain"), postData);
//
//        RequestBody requestBody = new FormBody.Builder()
//                .add("postData", postData)
//                .build();
//        Request request = new Request.Builder()
//                .url(url)
//                .post(requestBody)
//                .addHeader("Content-Type", "application/x-www-form-urlencoded")
//                .addHeader("accept", "application/json")
//                .build();

        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                String responseBody = response.body().string();
                return responseBody;
            } else {
                System.out.println("Error: " + response.code());
            }
            response.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }
    //This method is used to call with status , tc_id and tc_name from hook
    public String myMethod(String status, String tc_id, String tc_name){
        String postData = "token=3ba17e55ea31afefd3ef34cf51f8d2aa&project_id=13685&status=" + status + "&tc_id[]=" + tc_id + "&tc_name=" + tc_name;
        this.loadApiUrls();
        String responseBody = hitAPI(postData, this.getApiUrl("attachPostData"));
        System.out.println(responseBody);
        return responseBody;
    }
    //This method is used to get url from json
    private void loadApiUrls() {
        try (FileReader reader = new FileReader(System.getProperty("user.dir") + "/src/test/resources/data/url.json")) {
            JsonParser parser = new JsonParser();
            apiUrls = parser.parse(reader).getAsJsonObject();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //This method is used to get the api from key
    public String getApiUrl(String key) {
        System.out.println(apiUrls);
        if (apiUrls != null && apiUrls.has(key)) {
            return apiUrls.get(key).getAsString();
        }
        return null;
    }

}