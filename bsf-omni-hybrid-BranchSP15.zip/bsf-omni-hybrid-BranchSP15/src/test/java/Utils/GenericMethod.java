package Utils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.*;
import org.testng.Assert;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;

public class GenericMethod {
    public List<String> getTextOfElements(AppiumDriver driver, List<WebElement> elementsList) {
        List<String> elementText = new ArrayList<>();
        elementsList.forEach(element -> {
            var elementValue = element.getText();
            if (elementValue != null) elementText.add(elementValue.toLowerCase().trim());
        });
        return elementText;
    }

    public boolean isElementPresent(WebElement elementsList) {
        try {
            elementsList.isDisplayed();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isSorted(List<String> listOfStrings, int index) {
        if (index < 2) {
            return true;
        } else if (listOfStrings.get(index - 2).compareTo(listOfStrings.get(index - 1)) > 0) {
            return false;
        } else {
            return isSorted(listOfStrings, index - 1);
        }
    }

    public void scrollToTop(WebDriver driver) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String scrollToTop = "window.scrollTo(document.body.scrollHeight,0)";
        js.executeScript(scrollToTop);
    }

    public void scroll(WebDriver driver) {
        Dimension dimensions = driver.manage().window().getSize();
        int Startpoint = (int) (dimensions.getHeight() * 0.5);
        int scrollEnd = (int) (dimensions.getHeight() * 0.5);
//        driver.swipe(200, Startpoint,200,scrollEnd,2000);
    }

    //Swipe by elements
    public void swipeByElements (WebDriver driver, WebElement startElement, WebElement endElement) {
        int startX = startElement.getLocation().getX() + (startElement.getSize().getWidth() / 2);
        int startY = startElement.getLocation().getY() + (startElement.getSize().getHeight() / 2);
        int endX = endElement.getLocation().getX() + (endElement.getSize().getWidth() / 2);
        int endY = endElement.getLocation().getY() + (endElement.getSize().getHeight() / 2);
        new TouchAction((PerformsTouchActions)driver)
                .press(PointOption.point(startX,startY))
                .waitAction(waitOptions(ofMillis(1000)))
                .moveTo(PointOption.point(endX, endY))
                .release().perform();
    }

    public void scrollDown(WebDriver driver) {//Scroll down using TouchAction Class

        org.openqa.selenium.Dimension size = driver.manage().window().getSize();
        TouchAction action = new TouchAction((PerformsTouchActions) driver);
        int startX = size.width/2;
        int startY = (int) (size.height*0.8);
        int endY = (int) (size.width*0.2);
        action.press(PointOption.point(startX, startY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
                .moveTo(PointOption.point(startX, endY)).release().perform();

    }

    public void scrollUp(WebDriver driver) {
        // Scroll up using TouchAction Class

        org.openqa.selenium.Dimension size = driver.manage().window().getSize();
        TouchAction action = new TouchAction((PerformsTouchActions) driver);
        int startX = size.width / 2;
        int startY = (int) (size.height * 0.2); // Start from 20% of the screen height
        int endY = (int) (size.height * 0.8);   // Scroll to 80% of the screen height
        action.press(PointOption.point(startX, startY)).waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
                .moveTo(PointOption.point(startX, endY)).release().perform();
    }

    public void scrollUPMobile(WebDriver driver) {//Scroll up using TouchAction Class
        org.openqa.selenium.Dimension size = driver.manage().window().getSize();
        int scrollStart = (int) (size.height * 0.3);
        int scrollEnd = (int) (size.height * 0.7);
        scroll(driver, scrollStart, scrollEnd);

    }


    private static void scroll(WebDriver driver, int scrollStart, int scrollEnd) {
        new TouchAction((PerformsTouchActions) driver)
                .press(PointOption.point(0, scrollStart))
                .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
                .moveTo(PointOption.point(0, scrollEnd))
                .release().perform();
    }

    public void scrollToDown(WebDriver driver) {
        try {
//            JavascriptExecutor js = (JavascriptExecutor) driver;
//            HashMap<String, String> scrollObject = new HashMap<String, String>();
//            scrollObject.put("direction", "down");
//            js.executeScript("mobile: scroll", scrollObject);
//            System.out.println("Scroll to end");
            // assuming you have already instantiated the driver object and navigated to the desired screen

// get the dimensions of the screen
//            JavascriptExecutor js = (JavascriptExecutor) driver;
//            HashMap<String, String> scrollObject = new HashMap<String, String>();
//            scrollObject.put("direction", "down");
//            js.executeScript("mobile: scroll", scrollObject);
            Dimension size = driver.manage().window().getSize();
            int startX = size.width / 2;
            int startY = (int) (size.height * 0.8);
            int endY = (int) (size.height * 0.2);

            // Swipe up/down until the element is visible
            TouchAction action = new TouchAction((PerformsTouchActions) driver);
            action.press(PointOption.point(startX, startY))
                    .moveTo(PointOption.point(startX, endY))
                    .release()
                    .perform();

        } catch (Exception e) {
            System.out.println("Failed to scroll to end : " + e);
        }
    }

    public void scrollToLastElement(WebDriver driver, WebElement element) {
        try {
            Dimension size = driver.manage().window().getSize();

            // Set the start and end points for the swipe gesture
            int startX = size.width / 2;
            int startY = (int) (size.height * 0.8);
            int endY = (int) (size.height * 0.2);

            // Swipe up/down until the element is visible
            while (!this.isElementPresent(element)) {
                TouchAction action = new TouchAction((PerformsTouchActions) driver);
                action.press(point(startX, startY))
                        .moveTo(point(startX, endY))
                        .release()
                        .perform();
            }

//            Dimension size = driver.manage().window().getSize();
//            int startX = size.width / 2;
//            int startY = (int) (size.height * 0.8);
//            int endX = size.width / 2;
//            int endY = (int) (size.height * 0.2);
//
//// perform the scroll using the swipe method
//            new TouchAction((PerformsTouchActions) driver)
//                    .press(PointOption.point(startX, startY))
//                    .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
//                    .moveTo(PointOption.point(endX, endY))
//                    .release()
//                    .perform();


        } catch (Exception e) {
            System.out.println("Failed to scroll to end : " + e);
        }
    }

    public void mobileScrollElementIOS(AppiumDriver driver, WebElement el, String dir) {
        System.out.println("mobileScrollElementIOS(): dir: '" + dir + "'"); // always log your actions

        // Animation default time:
        //  - iOS: 200 ms
        // final value depends on your app and could be greater
        final int ANIMATION_TIME = 200; // ms
        final HashMap<String, Object> scrollObject = new HashMap<String, Object>();
        scrollObject.put("direction", dir.toLowerCase());
        scrollObject.put("element", el);
        try {
            driver.executeScript("mobile:scroll", scrollObject); // swipe faster then scroll
            Thread.sleep(ANIMATION_TIME); // always allow swipe action to complete
        } catch (Exception e) {
            System.err.println("mobileScrollElementIOS(): FAILED\n" + e.getMessage());
        }
    }

    public void mobileScrollTillEndOfPage(AppiumDriver driver, WebElement el) {
        boolean endOfPage = false;
        String previousPageSource = driver.getPageSource();
        while (!endOfPage) {
            if (isElementPresent(el)) {
                break;
            } else {
                scrollDown(driver);
            }
            endOfPage = previousPageSource.equals(driver.getPageSource());
            previousPageSource = driver.getPageSource();

        }

    }

    public void mobileScrollTillUpOfPage(AppiumDriver driver, WebElement el) {
        boolean upOfPage = false;
        String previousPageSource = driver.getPageSource();
        while (!upOfPage) {
            if (isElementPresent(el)) {
                break;
            } else {
                scrollUPMobile(driver);
            }
            upOfPage = previousPageSource.equals(driver.getPageSource());
            previousPageSource = driver.getPageSource();

        }

    }

    public void setPicker(AppiumDriver driver, WebElement elementPicker, String value, WebElement donePicker) throws InterruptedException {
        System.out.println("Picker: " + elementPicker.getAttribute("value"));
        while (!Objects.equals(elementPicker.getAttribute("value").trim(), value.trim())) {
            HashMap<Object, Object> params = new HashMap<>();
            params.put("order", "next");
            params.put("offset", 0.15);
            params.put("element", elementPicker);
            driver.executeScript("mobile: selectPickerWheelValue", params);
            System.out.println("Picker: " + elementPicker.getAttribute("value"));
        }
        //        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30),Duration.ofSeconds(60));
        while (donePicker.isDisplayed()) {
            donePicker.click();
            Thread.sleep(5000);
            try {
                donePicker.click();
            } catch (Exception e) {
                System.out.println("Done Picker No longer available exitting");
                return;
            }
        }
//        donePicker.click();
//        System.out.println("Clicked Done Picker");
//        Thread.sleep(5000);
    }

    public void setPicker(AppiumDriver driver, WebElement elementPicker, String value, WebElement donePicker,String order) throws InterruptedException {
        System.out.println("Picker: " + elementPicker.getAttribute("value"));
        while (!Objects.equals(elementPicker.getAttribute("value").trim(), value.trim())) {
            HashMap<Object, Object> params = new HashMap<>();
            params.put("order", order);
            params.put("offset", 0.15);
            params.put("element", elementPicker);
            driver.executeScript("mobile: selectPickerWheelValue", params);
            System.out.println("Picker: " + elementPicker.getAttribute("value"));
        }
        //        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30),Duration.ofSeconds(60));
        while (donePicker.isDisplayed()) {
            donePicker.click();
            Thread.sleep(5000);
            try {
                donePicker.click();
            } catch (Exception e) {
                System.out.println("Done Picker No longer available exitting");
                return;
            }
        }
//        donePicker.click();
//        System.out.println("Clicked Done Picker");
//        Thread.sleep(5000);
    }

    protected String xpath1toLowerCase(String string) {
        return String.format("translate(%s,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')", string);
    }

    public boolean convertToBoolean(String value) {
        boolean returnValue = false;
        if ("1".equalsIgnoreCase(value) || "yes".equalsIgnoreCase(value) ||
                "true".equalsIgnoreCase(value) || "on".equalsIgnoreCase(value))
            returnValue = true;
        return returnValue;
    }

    public WebElement swipeDown(AppiumDriver driver,String previousPageSource,String xpath,int swipeCount){
        boolean endOfPage = false;
        WebElement element = null;
        try {
            element = driver.findElement(By.xpath(xpath));
            System.out.println("Exception not found but found element");
            return element;
        }catch (Exception e){
            swipe(driver);
            try {
                Thread.sleep(5000);
            }catch (Exception ex){
                throw new RuntimeException(ex);
            }
            String currentPageSource = driver.getPageSource();
//            System.out.println("Current"+currentPageSource);
//            System.out.println("Previous"+previousPageSource);
            System.out.println("Swipe Count: "+swipeCount);
            endOfPage = currentPageSource.contentEquals(previousPageSource);
            if(swipeCount==5) Assert.assertTrue(false,"The App has been swiped 20 times and element was not found");
            swipeCount++;
            if(!endOfPage) element = swipeDown(driver,currentPageSource,xpath,swipeCount);
        }
        return element;
    }

    public void swipe(AppiumDriver driver){
        HashMap<String, String> scrollObject = new HashMap<>();
        JavascriptExecutor js = driver;
        scrollObject.put("direction","down");
        js.executeScript("mobile: scroll",scrollObject);
    }
}
