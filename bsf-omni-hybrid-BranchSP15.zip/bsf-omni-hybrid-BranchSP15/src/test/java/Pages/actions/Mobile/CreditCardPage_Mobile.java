package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.JsonHandler;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.WebElement;
import Utils.GenericMethod;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class CreditCardPage_Mobile {
    GenericMethod genericMethod = new GenericMethod();

    public AppiumDriver driver;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@value,'No transactions')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='No transactions yet']")
    public WebElement noTransactionsHeaderMessage;
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textViewErrorSubtitle")
    public WebElement noTransactionsMessage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,'TransactionTableHeaderDateLabel')]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsTransactionsJourney_listView_sectionHeader")
    public List<WebElement> detailsDate;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Cardholder name']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Cardholder name']//following-sibling::android.widget.TextView")
    public WebElement cardHolderName;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Expiry date']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Expiry date']//following-sibling::android.widget.TextView")
    public WebElement cardExpiryDate;

    @iOSXCUITFindBy(accessibility = "ExternalAction")
    @AndroidFindBy(accessibility = "Edit account name")
    public WebElement editAccountName;

    @iOSXCUITFindBy(accessibility = "Do you want to rename this account?")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/transactionsJourney_transactionsDetailScreen_editAlias_titleView")
    public WebElement titleText;

    @iOSXCUITFindBy(accessibility = "Card")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/icon")
    public WebElement accountIcon;
    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionJourney_accountDetailsFieldEditorScreen_textNameInout")
    public WebElement accountName;

    @iOSXCUITFindBy(accessibility = "AccountDetailsFieldEditorViewControllerCloseButton")
    @AndroidFindBy(accessibility = "Close")
    public WebElement closeButton;

    @iOSXCUITFindBy(accessibility = "Close")
    @AndroidFindBy(accessibility = "Close")
    public WebElement secondCloseButton;
    @AndroidFindBy(id = "com.bsf.retail.uat:id/transactionsJourney_completeScreen_bottomButton")
    public WebElement gotItButton;

    @iOSXCUITFindBy(accessibility = "Transactions")
    @AndroidFindBy(accessibility = "Navigate up")
    public WebElement navigateBackButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Card name\"]/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Card name']//following-sibling::android.widget.TextView")
    public WebElement creditCardName;
    @iOSXCUITFindBy(accessibility = "Do you want to rename this account?")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/transactionsJourney_transactionsDetailScreen_editAlias_titleView")
    public WebElement renameScreen;
    @iOSXCUITFindBy(accessibility = "FieldEditorTextField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionJourney_accountDetailsFieldEditorScreen_textNameInout")
    public WebElement creditCardNameField;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement creditCardNameFieldError;

    @iOSXCUITFindBy(accessibility = "FieldEditorSaveButton")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/transactionsJourney_transactionsDetailScreen_editAlias_button")
    public WebElement saveButton;

    @iOSXCUITFindBy(accessibility = "Success")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Success!']")
    public WebElement successScreen;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Available cash limit']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Available cash limit')]//following-sibling::android.widget.TextView")
    public WebElement availableCashLimit;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Minimum payment percentage']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Minimum payment percentage')]//following-sibling::android.widget.TextView")
    public WebElement minimumPaymentPercentage;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Total due amount']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Total due amount')]//following-sibling::android.widget.TextView")
    public WebElement totalDueAmount;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Minimum due amount']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Minimum due amount')]//following-sibling::android.widget.TextView")
    public WebElement minimumDueAmount;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Payment due date']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Payment Due Date')]//following-sibling::android.widget.TextView")
    public WebElement paymentDueDate;

    public CreditCardPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void verifyHeaderMessage(String header, String message) {
        if (genericMethod.isElementPresent(noTransactionsHeaderMessage)) {
            noTransactionsMessage.isDisplayed();
        }

    }

    public void verifyTransactionDate() {
        List<String> elementText = new ArrayList<>();
        elementText = genericMethod.getTextOfElements(driver, detailsDate);
        genericMethod.isSorted(elementText, elementText.size());
    }

    public void successScreenCloseButton() {
        try {
            secondCloseButton.click();
        } catch (Exception e) {
            gotItButton.click();
        }
    }


    public void verifyCardHolderNameIsDisplayed() {
        Assert.assertTrue(cardHolderName.isDisplayed());
        System.out.println(cardHolderName.getText() + " card holder name is displayed");
    }

    public void verifyExpiryDateIsDisplayed() {
        Assert.assertTrue(cardExpiryDate.isDisplayed());
        System.out.println(cardExpiryDate.getText() + " card expiry date is displayed");
    }

    public void clickOnEditAccountName() {
        Assert.assertTrue(editAccountName.isDisplayed());
        editAccountName.click();
    }

    public void clickOnCloseButton() {
        Assert.assertTrue(closeButton.isDisplayed());
        closeButton.click();
    }


    public void verifyTitle(String title) {
        Assert.assertTrue(titleText.isDisplayed());
        Assert.assertTrue(title.contains(titleText.getText()));
//        Assert.assertEquals(titleText.getText(), title);
    }

    public void verifyAccountIcon() {
        Assert.assertTrue(accountIcon.isDisplayed());
    }

    public void verifyAccountName() {
        Assert.assertTrue(genericMethod.isElementPresent(accountName), "Element is not editable");
        Assert.assertTrue(accountIcon.isDisplayed());
    }

    public void selectBackButton() {
        System.out.println("Tap Back Button");
        navigateBackButton.click();
    }

    public void saveCreditCardName() {
        new JsonHandler().writeJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", "Credit_Card_Name", creditCardName.getText());
    }

    public void verifyRenameCardScreen() {
        Assert.assertTrue(renameScreen.isDisplayed());
    }

    public void clearCreditCardField() {
        creditCardNameField.clear();
    }

    public void nameFieldError(String errorMessage) {
        try {
            Assert.assertEquals(creditCardNameFieldError.getText(), errorMessage);
        } catch (Exception e) {
            System.out.println("Error message : " + errorMessage + " not displayed");
        }
    }

    public void inputCharacterIntoCardField(String cardName) {
        String value = new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", cardName);
        creditCardNameField.sendKeys(value);
        if (!cardName.contains("max")) {
            new JsonHandler().writeJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", "Credit_Card_Name", value);
        }

    }

    public void clickSaveButton() {
        saveButton.click();
    }

    public void verifySuccessScreen() {
        Assert.assertTrue(successScreen.isDisplayed());
    }

    public void verifyCreditCardName(String creditCardName) {
        String value = new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", creditCardName);

        Assert.assertEquals(this.creditCardName.getText(), value);
    }

    public void revertToOrignalValue() {
        clickOnEditAccountName();
        clearCreditCardField();
        inputCharacterIntoCardField(new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", "Credit_Card_Name"));
        clickSaveButton();
        verifySuccessScreen();
        successScreenCloseButton();
    }

    public void verifyAvailableCashLimit(String cashLimit) {
        Assert.assertTrue(availableCashLimit.getText().contains(new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", cashLimit)));
    }

    public void verifyMinimumPaymentPercentage(String cashLimit) {
        Assert.assertEquals(minimumPaymentPercentage.getText(), new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", cashLimit));
    }

    public void verifyTotalDueAmount(String cashLimit) {
        Assert.assertTrue(totalDueAmount.getText().contains(new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", cashLimit)));
    }

    public void verifyMinimumDueAmount(String cashLimit) {
        Assert.assertTrue(minimumDueAmount.getText().contains(new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", cashLimit)));
    }

    public void verifyPaymentDueDate(String cashLimit) {
//        Assert.assertTrue(paymentDueDate.getText().contains(new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "CreditCardDetails", cashLimit)));
        Assert.assertFalse(paymentDueDate.getText().isEmpty());
    }
}
