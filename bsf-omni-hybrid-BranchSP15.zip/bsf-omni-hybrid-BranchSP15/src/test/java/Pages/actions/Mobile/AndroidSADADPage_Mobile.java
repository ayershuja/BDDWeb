package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.JsonHandler;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

public class AndroidSADADPage_Mobile {

    public AppiumDriver driver;
    GenericMethod genericMethod = new GenericMethod();


    @iOSXCUITFindBy(accessibility = "Add with bill number")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billNumberButton")
    public WebElement AddBillNo;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Select biller\"")
    @AndroidFindBy(accessibility = "Select biller")
    public WebElement SelectBiller;

    @iOSXCUITFindBy(accessibility = "Add bill number")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/titleLabel")
    public WebElement AddBill;

    @iOSXCUITFindBy(accessibility = "Enter bill number")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/titleLabel")
    public WebElement EditBill;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"Please enter the bill or account number to retrieve details\")]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/subtitleLabel")
    public WebElement SubText;

    @iOSXCUITFindBy(accessibility = "Account Number")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billerFieldLabel")
    public WebElement AccText;

    @iOSXCUITFindBy(className = "XCUIElementTypeTextField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billNumberInput")
    public WebElement AccNoInput;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Continue\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billNumberContinueButton")
    public WebElement ContBtn;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther/following-sibling::XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billNameLabel")
    public WebElement BillName;

    @iOSXCUITFindBy(accessibility = "ic edit")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/iconEdit")
    public WebElement BillEditIcn;

    @iOSXCUITFindBy(accessibility = "ic delete")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/iconBin")
    public WebElement BillDelIcn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Details\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Details']")
    public WebElement DetailsBill;

    @iOSXCUITFindBy(accessibility = "Biller")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billerNameLabel")
    public WebElement BillerTxt;

    @iOSXCUITFindBy(accessibility = "Account/Bill number")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billNumberLabel")
    public WebElement AccBillNo;

    @iOSXCUITFindBy(accessibility = "Standing amount")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/amountLabel")
    public WebElement StandingAmt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Are you sure?\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Are you sure?']")
    public WebElement popUpSure;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Close\"]|//XCUIElementTypeButton[@name=\"Remove\"]")
    @AndroidFindBy(id = "android:id/button1")
    public WebElement rmvBtn;

    @iOSXCUITFindBy(accessibility = "Cancel")
    @AndroidFindBy(id = "android:id/button2")
    public WebElement cancelBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Activate\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/bottomButton")
    public WebElement actvateBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"No Bills Found\")]")
    @AndroidFindBy(id = "android:id/message")
    public WebElement errMsgPopUp;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Make a payment\"]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc='Bill amount']")
    public WebElement billAmtPage;

    @iOSXCUITFindBy(accessibility = "transferLimitLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/amountFieldTitle")
    public WebElement amountField;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"currencyLabel\"])[2]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_prefix_text")
    public WebElement sarField;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Continue\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/changeBillAmountContinueButton")
    public WebElement contBtn;

    @iOSXCUITFindBy(accessibility = "amountTextInputID.textInput.textField")
    @AndroidFindBy(xpath = "//android.widget.EditText[@text='0.00']")
    public WebElement billAmount;

    @AndroidFindBy(xpath = "//android.widget.EditText[@text='0']")
    public WebElement ValidbillAmount;

    @iOSXCUITFindBy(accessibility = "amountTextInputID.errorLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement billError;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Select a payment method\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Select a payment method']")
    public WebElement paymntMthdTxt;

    @iOSXCUITFindBy(accessibility = "Credit card")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/creditCardButton")
    public WebElement crdtCardBtn;

    @iOSXCUITFindBy(accessibility = "Account")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountButton")
    public WebElement accBtn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"close\"]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Bill amount\"]/android.view.ViewGroup/android.widget.ImageButton")
    public WebElement backNav;

    @iOSXCUITFindBy(accessibility = "accountNumberLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billIdLabel")
    public WebElement billNo;

    @iOSXCUITFindBy(accessibility = "dateLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billDate")
    public WebElement billDate;

    @iOSXCUITFindBy(accessibility = "statusLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billStatusLabel")
    public WebElement billStatus;

    @iOSXCUITFindBy(accessibility = "amountLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/billAmountLabel")
    public WebElement billDue;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Continue\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/reviewBillContinueButton")
    public WebElement ContinueBttn;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Back\"]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"Select card\"]/android.view.ViewGroup/android.widget.ImageButton")
    public WebElement backNavigatr;

    @iOSXCUITFindBy(accessibility = "Search billers")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/search_button")
    public WebElement SearchIcon;

    @iOSXCUITFindBy(accessibility = "Search billers")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/search_src_text")
    public WebElement SearchBar;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/amountReviewValue")
    public WebElement payingAmount;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/fromAccountName")
    public WebElement AccName;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/fromAccountNumber")
    public WebElement AccNo;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/toAccountName")
    public WebElement Billname;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/toAccountBank")
    public WebElement BillBank;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/descriptionTitle")
    public WebElement RevDetails;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/billValueLabel")
    public WebElement BillAmount;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/feesVatLabel")
    public WebElement FeesVat;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/feesVatValue")
    public WebElement FeesVatAmount;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnPayBill")
    public WebElement PayBillBtn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/ivPaymentStatus")
    public WebElement SuccessIcon;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/tvPaymentStatusTitle")
    public WebElement SuccessLbl;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/tvPaymentStatusDesc")
    public WebElement SuccessTxt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnPrimary")
    public WebElement DoneBtn;

    @iOSXCUITFindBy(accessibility = "ic search")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/search_button")
    public WebElement SearchIcn;

    @iOSXCUITFindBy(accessibility = "Search")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/search_src_text")
    public WebElement Searchbar;

    @iOSXCUITFindBy(accessibility = "Inactive")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/chipsInactive")
    public WebElement ChipInactive;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Activate\"])[1]")
    @AndroidFindBy(xpath = "(//android.widget.Button[@text='Activate'])[1]")
    public WebElement ActvateBtn;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/billerNameLabel\"])[1]")
    public WebElement BillNamee;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/billIdLabel\"])[1]")
    public WebElement BillNumber;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/billStatusLabel\"])[1]")
    public WebElement BillStatus;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/billAmountLabel\"])[1]")
    public WebElement BillAmountt;

    @AndroidFindBy(xpath = "(//android.widget.Button[@resource-id=\"com.bsf.retail.uat:id/buttonOption\"])[1]")
    public WebElement AddBillCTA;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/iqamaNumberButton")
    public WebElement AddID;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/errorTitleLabel")
    public WebElement EmptyBillCTA;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/progress_bar")
    public WebElement loadingbar;

    public AndroidSADADPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }


    public void clickAddNew(String optVal) {

        if (RunnerInfo.getDeviceType().contains("android"))
            driver.findElement(By.xpath("//android.widget.TextView[@text='" + optVal + "']")).click();
        else
            driver.findElement(By.xpath("//XCUIElementTypeButton[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + optVal.toUpperCase() + "']")).click();
    }

    public void verifyAddNewPopUp(String optVal) {

        String elementValue;

        if (RunnerInfo.getDeviceType().contains("android"))
            elementValue = driver.findElement(By.xpath("//android.widget.TextView[@text='" + optVal + "']")).getText();
        else
            elementValue = driver.findElement(By.xpath("//XCUIElementTypeStaticText[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + optVal.toUpperCase() + "']|//XCUIElementTypeButton[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + optVal.toUpperCase() + "']")).getText();

        Assert.assertEquals(elementValue, optVal);
    }


    public void clickOpt(String optVal) {
        System.out.println("???????????????????"+optVal);

        if(optVal.contains("Add with ID/Iqama number"))
        {

            AddID.click();
        }
        else
        {
            AddBillNo.isDisplayed();
            AddBillNo.click();
        }
    }

    public void verifySelectBillrPage(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SelectBiller.isDisplayed());
            System.out.println("Select Biller page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void clickBill(String optVal) throws InterruptedException {

        if (RunnerInfo.getDeviceType().contains("android"))
            driver.findElement(By.xpath("//android.widget.TextView[translate(@text,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + optVal.toUpperCase() + "']")).click();
        else {
            WebElement ele = driver.findElement(By.xpath("//XCUIElementTypeStaticText[translate(@name,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + optVal.toUpperCase() + "']"));
            ele.click();
            try{
                ele.isDisplayed();
            }catch (Exception e){
                ele = driver.findElement(By.xpath("//XCUIElementTypeStaticText[translate(@name,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + optVal.toUpperCase() + "']"));
                while (ele.isDisplayed()) {
                    ele.click();
                    Thread.sleep(5000);
                    try {
                        ele.click();
                    } catch (Exception ex) {
                        System.out.println("Element No longer available exitting");
                        return;
                    }
                }
            }
        }
    }

    public void verifyAddBillPage(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(AddBill.isDisplayed());
            System.out.println("Add Bill Number page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void verifyEditBillPage(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(EditBill.isDisplayed());
            System.out.println("Add Bill Number page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(EditBill.getText(),optVal);
    }

    public void verifySubText(String optVal) {

        SubText.isDisplayed();

        Assert.assertTrue(optVal.contains(SubText.getText()),"Verification Failed: Expected"+optVal+": Found: "+SubText.getText());
    }

    public void verifyAccTxt(String optVal) {

        AccText.isDisplayed();

        Assert.assertEquals(AccText.getText(), optVal);
    }

    public void enterVal(String optVal) {

        AccNoInput.clear();
        AccNoInput.sendKeys(optVal);
    }

    public void verifyContDisable(String optVal) {

        Assert.assertEquals(ContBtn.getText(), optVal);

        Assert.assertFalse(ContBtn.isEnabled());

    }

    public void verifyContEnable(String optVal) {

        Assert.assertEquals(ContBtn.getText(), optVal);

        Assert.assertTrue(ContBtn.isEnabled());

    }

    public void clickDetBtn(String optVal) {
        WebElement element;
        if (RunnerInfo.getDeviceType().contains("android")) {

            driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"Recharge\").instance(0))"));

            driver.findElement(By.xpath("(//android.widget.Button[@text='" + optVal + "'])[1]")).click();
          //  genericMethod.mobileScrollTillEndOfPage(driver, element);
        }
        else
            {
            String xpath = "(//XCUIElementTypeStaticText[@name='" + optVal + "'])[1]";
            element = genericMethod.swipeDown(driver,driver.getPageSource(),xpath,0);
                while(element.isDisplayed()){
                    element.click();
                }
        }
//        while(element.isDisplayed()){
//            element.click();
//        }
//        element.click();
    }

    public void verifyBillDet() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(BillName.isDisplayed());
            System.out.println("Bill Details page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyDtailsBillPay() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(BillEditIcn.isDisplayed());
            System.out.println("Bill Edit icon verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        try {
            Thread.sleep(6000);
            Assert.assertTrue(BillDelIcn.isDisplayed());
            System.out.println("Bill Delete icon verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        DetailsBill.isDisplayed();
        Assert.assertEquals(DetailsBill.getText(), "Details");

        BillerTxt.isDisplayed();
        Assert.assertEquals(BillerTxt.getText(), "Biller");

        AccBillNo.isDisplayed();
        Assert.assertEquals(AccBillNo.getText(), "Account/Bill number");

        StandingAmt.isDisplayed();
        Assert.assertEquals(StandingAmt.getText(), "Standing amount");

    }

    public void clickDel() {

        BillDelIcn.isEnabled();
        BillDelIcn.click();
    }

    public void verifyDelPopUp(String optVal) {

        popUpSure.isDisplayed();
        Assert.assertEquals(popUpSure.getText(), optVal);

    }

    public void verifyCancelBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(cancelBtn.isDisplayed());
            System.out.println("Cancel Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(cancelBtn.isEnabled());
        Assert.assertEquals(cancelBtn.getText().toLowerCase(), optVal.toLowerCase());

    }

    public void verifyRemoveBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(rmvBtn.isDisplayed());
            System.out.println("Remove Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(rmvBtn.isEnabled());
        Assert.assertEquals(rmvBtn.getText().toLowerCase(), optVal.toLowerCase());
    }

    public void clickActivateDetailBtn(String optVal1, String optVal2) {

       WebElement ActvDetBtn = null;
           if (RunnerInfo.getDeviceType().contains("android")){

               driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"Mobily 966503745904\").instance(0))"));

               ActvDetBtn = driver.findElement(By.xpath("(//android.widget.Button[@text='"+optVal2+"'])[1]//preceding-sibling::android.widget.Button[@text='"+optVal1+"']"));
//               ActvDetBtn = driver.findElement(By.xpath("(//android.widget.Button[@text='" + optVal2 + "'])[1]//preceding-sibling::android.widget.Button[@text='" + optVal1 + "']"));
//        driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector())" +
//                ".scrollIntoView(new UiSelector().text('"+optVal2+"'));"));
//               ActvDetBtn = genericMethod.swipeDown(driver, driver.getPageSource(), xpath,0);

           }
           else{
                   String xpath = "(//XCUIElementTypeButton[@label='" + optVal2 + "']//following-sibling::XCUIElementTypeButton[@label='" + optVal1 + "'])[1]";
                   ActvDetBtn = genericMethod.swipeDown(driver, driver.getPageSource(), xpath,0);
               }
//        try {
//            Thread.sleep(6000);
//            Assert.assertTrue(ActvDetBtn.isDisplayed());
//            System.out.println("Detail Btn verification");
//            Thread.sleep(5000);
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }

        Assert.assertTrue(ActvDetBtn.isEnabled());
        Assert.assertEquals(ActvDetBtn.getText().toLowerCase(), optVal1.toLowerCase());
        ActvDetBtn.click();
    }

    public void verifyActivateBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(actvateBtn.isDisplayed());
            System.out.println("Activate Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(actvateBtn.isEnabled());
        Assert.assertEquals(actvateBtn.getText(), optVal);
    }

    public void clickRemoveBtn(String optVal) {

        Assert.assertTrue(rmvBtn.isEnabled());
        Assert.assertEquals(rmvBtn.getText().toLowerCase(), optVal.toLowerCase());
        rmvBtn.click();
    }

    public void clickCancelBtn(String optVal) {

        Assert.assertTrue(cancelBtn.isEnabled());
        Assert.assertEquals(cancelBtn.getText().toLowerCase(), optVal.toLowerCase());
        cancelBtn.click();
    }

    public void clickContinueBtn(String optVal) {

        Assert.assertEquals(ContBtn.getText(), optVal);

        ContBtn.click();

    }

    public void verifyErrorPopUp(String optVal) {


        try {
            Thread.sleep(6000);
            Assert.assertTrue(errMsgPopUp.isDisplayed());
            System.out.println("Error Message verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(errMsgPopUp.getText(),optVal);
      //  Assert.assertTrue(errMsgPopUp.getText().contains(optVal));
    }

    public void verifyBillAmountPage() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(billAmtPage.isDisplayed());
            System.out.println("bill Amount Page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyAmountField(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(amountField.isDisplayed());
            System.out.println("amount Field verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(amountField.getText(), optVal);
    }

    public void verifySARField(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(sarField.isDisplayed());
            System.out.println("sar Field verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(sarField.getText(), optVal);
    }

    public void verifyContinueBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(contBtn.isDisplayed());
            System.out.println("continue Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(contBtn.isEnabled());
        Assert.assertEquals(contBtn.getText(), optVal);
    }

    public void enterAmount() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(billAmount.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(billAmount.isEnabled());

        billAmount.clear();
        billAmount.sendKeys("0");
    }

    public void clickBillContinueBtn(String optVal) {

        Assert.assertTrue(contBtn.isDisplayed());
        Assert.assertEquals(contBtn.getText(), optVal);
        contBtn.click();

    }

    public void verifyBillError(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(billError.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(billError.getText(), optVal);
    }

    public void enterValidAmount() {

        ValidbillAmount.clear();
        billAmount.sendKeys("1");
    }

    public void verifyPaymentpopUp(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(paymntMthdTxt.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(paymntMthdTxt.getText(), optVal);
    }

    public void verifyCreditCrdOpt(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(crdtCardBtn.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(crdtCardBtn.isEnabled());
        Assert.assertEquals(crdtCardBtn.getText(), optVal);
    }

    public void verifyAccountOpt(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(accBtn.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(accBtn.isEnabled());
        Assert.assertEquals(accBtn.getText(), optVal);
    }

    public void clickBackNav() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(backNav.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(backNav.isEnabled());
        backNav.click();
    }

    public void verifyRevBillPage(String optVal) {

        WebElement RevBill = driver.findElement(By.xpath("//android.widget.FrameLayout[@content-desc='"+optVal+"']|//XCUIElementTypeStaticText[@name='"+optVal+"']"));

     //   String[] contentDescription = element.getAttribute(attribute).split(", ");

        try {
            Thread.sleep(6000);
            Assert.assertTrue(RevBill.isDisplayed());
            System.out.println("Detail Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        if (RunnerInfo.getDeviceType().contains("android")) {

            Assert.assertEquals(RevBill.getAttribute("content-desc").trim(),optVal);
        }else{

            Assert.assertEquals(RevBill.getText().trim(),optVal);
        }

    }

    public void verifyBillNum(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(billNo.isDisplayed());
            System.out.println("Detail Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(billNo.getText(), optVal);
    }

    public void verifyBillDate(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(billDate.isDisplayed());
            System.out.println("Detail Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(billDate.getText(), optVal);
    }

    public void verifyBillStat(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(billStatus.isDisplayed());
            System.out.println("Detail Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(billStatus.getText(), optVal);
    }

    public void verifyBillDueAmnt(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(billDue.isDisplayed());
            System.out.println("Detail Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(billDue.getText(), optVal);
    }

    public void verifyContBtnOnRevScreen(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ContinueBttn.isDisplayed());
            System.out.println("Detail Btn verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(ContinueBttn.isEnabled());
        Assert.assertEquals(ContinueBttn.getText(), optVal);
    }

    public void clickContinueONRevScreen(String optVal) {

        Assert.assertTrue(ContinueBttn.isEnabled());
        Assert.assertEquals(ContinueBttn.getText(), optVal);
        ContinueBttn.click();

    }

    public void clickAccountOpt(String optVal) {

        Assert.assertTrue(accBtn.isEnabled());
        Assert.assertEquals(accBtn.getText(), optVal);
        accBtn.click();
    }


    public void clickCreditCardOpt(String optVal) {

        Assert.assertTrue(crdtCardBtn.isEnabled());
        Assert.assertEquals(crdtCardBtn.getText(), optVal);
        crdtCardBtn.click();
    }

    public void clickBackNavigatr() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(backNavigatr.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(backNavigatr.isEnabled());
        backNavigatr.click();
    }

    public void clickSearchIcon() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SearchIcon.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(SearchIcon.isEnabled());
        SearchIcon.click();
    }

    public void enterBillInSearchBar(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SearchBar.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertEquals(SearchBar.getText(), optVal);

        SearchBar.clear();
        SearchBar.sendKeys("go");

    }

    public void verifyPayingAmount() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(payingAmount.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(payingAmount.isEnabled());
    }

    public void verifyAccName() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(AccName.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(AccName.isEnabled());
    }

    public void verifyAccNo() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(AccNo.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(AccNo.isEnabled());
    }

    public void verifyBillName() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(Billname.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(Billname.isEnabled());
    }

    public void verifyBillBank() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(BillBank.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(BillBank.isEnabled());
    }

    public void verifyDet(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(RevDetails.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(RevDetails.isEnabled());
        Assert.assertEquals(RevDetails.getText(),optVal);
    }


    public void verifyBillAmount() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(BillAmount.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(BillAmount.isEnabled());
    }

    public void verifyFeesVat(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(FeesVat.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FeesVat.isEnabled());
        Assert.assertEquals(FeesVat.getText(),optVal);
    }

    public void verifyFeesVatAmount() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(FeesVatAmount.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FeesVatAmount.isEnabled());
    }

    public void verifyPayBillBtn(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(PayBillBtn.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(PayBillBtn.isEnabled());
        Assert.assertEquals(PayBillBtn.getText(),optVal);

    }

    public void clickPayBtn(String optVal) {
        Assert.assertTrue(PayBillBtn.isEnabled());
        Assert.assertEquals(PayBillBtn.getText(),optVal);
        PayBillBtn.click();
    }

    public void verifySuccessScreen() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(SuccessIcon.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SuccessIcon.isEnabled());
    }

    public void verifySuccessLabel(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SuccessLbl.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SuccessLbl.isEnabled());
        Assert.assertEquals(SuccessLbl.getText(),optVal);
    }

    public void verifySuccessText(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(SuccessTxt.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SuccessTxt.isEnabled());
        Assert.assertEquals(SuccessTxt.getText(),optVal);
    }

    public void verifyDoneBtn(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(DoneBtn.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(DoneBtn.isEnabled());
        Assert.assertEquals(DoneBtn.getText(),optVal);
    }

    public void clickSearch() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(SearchIcn.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SearchIcn.isEnabled());
        if (RunnerInfo.getDeviceType().contains("android")) Assert.assertEquals(SearchIcn.getAttribute("content-desc").trim(),"Search");
        else Assert.assertEquals(SearchIcn.getAttribute("label").trim(),"ic search");
        SearchIcn.click();

    }

    public void verifySearchBar(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(Searchbar.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(Searchbar.isEnabled());
        if (RunnerInfo.getDeviceType().contains("android")) Assert.assertEquals(Searchbar.getText(),optVal);
        else Assert.assertTrue(Searchbar.getText().contains(optVal),"Value is not same expected: "+optVal+" but found "+Searchbar.getText());
    }

    public void verifyChip(String optVal) {

      WebElement Chips = driver.findElement(By.xpath("//android.widget.Button[@text='"+optVal+"']|//XCUIElementTypeStaticText[@name='"+optVal+"']"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(Chips.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(Chips.isEnabled());
        Assert.assertEquals(Chips.getText(),optVal);
    }

    public void clickChip(String optVal) {

        Assert.assertTrue(ChipInactive.isEnabled());
        Assert.assertEquals(ChipInactive.getText(),optVal);
        ChipInactive.click();

    }

    public void clickActivateBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ActvateBtn.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ActvateBtn.isEnabled());
        Assert.assertEquals(ActvateBtn.getText(),optVal);
        ActvateBtn.click();
    }

    public void verifyPopUp(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(errMsgPopUp.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(errMsgPopUp.isEnabled());
        Assert.assertEquals(errMsgPopUp.getText(),optVal);
    }

    public void enterBillDueAmount(String optVal) {

        this.verifyBillDueAmnt(optVal);
        billDue.sendKeys("10");
    }

    public void VerifyBillDetails(String details)
    {
        String Expected_Billname = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "SadadDetails",details, "Bill_name");
        System.out.println("Expected Bill name >>>>> " +Expected_Billname);
        System.out.println("Actual Bill name >>>>> " +BillNamee.getText());
        Assert.assertEquals(BillNamee.getText(),Expected_Billname);

        String Expected_Billnumber = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "SadadDetails",details, "Bill_number");
        System.out.println("Expected Bill number >>>>> " +Expected_Billnumber);
        System.out.println("Actual Bill number >>>>> " +BillNumber.getText());
        Assert.assertEquals(BillNumber.getText(),Expected_Billnumber);

        String Expected_Billstatus = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "SadadDetails",details, "Bill_status");
        System.out.println("Expected Bill status >>>>> " +Expected_Billstatus);
        System.out.println("Actual Bill status >>>>> " +BillStatus.getText());
        Assert.assertEquals(BillStatus.getText(),Expected_Billstatus);

        String Expected_Billamount = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "SadadDetails",details, "Bill_Amount");
        System.out.println("Expected Bill amount >>>>> " +Expected_Billamount);
        System.out.println("Actual Bill amount >>>>> " +BillAmountt.getText());
        Assert.assertEquals(BillAmountt.getText(),Expected_Billamount);
    }
    public void VerifyAddBill()
    {
        Assert.assertEquals(AddBillCTA.getText(),"Add a bill");

    }

    public void ScrollToBottom()
    {
        genericMethod.scrollUp(driver);
        try{
        Thread.sleep(10000);

    } catch (Exception e) {
        throw new RuntimeException(e);
    }
    }

    public void VerifyEmptyBillList()
    {
        Assert.assertEquals(EmptyBillCTA.getText(),"No bills seem to appear");

    }

    public void ClickActivateButton(String number)
    {
        int allBills = driver.findElements(By.xpath("//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/billIdLabel\"]")).size();
        for (int i = 1; i<= allBills; i++)
        {
            WebElement BillNumber =  driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/billIdLabel\"])["+i+"]"));
            String billnumber = BillNumber.getText();

            String BillNo = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "SadadDetails", number);
            if(billnumber.equals(BillNo))
            {
                System.out.println(">>>>>>>>>>>>>>>>>>>>clickedddd ");
                WebElement ActivateBTn =  driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/billIdLabel\"]/parent::android.view.ViewGroup//android.widget.Button[@resource-id=\"com.bsf.retail.uat:id/buttonOption\"])["+i+"]"));
                i = allBills+1;
            }

        }
    }

    public void VerifyLoadingpopup()
    {
        loadingbar.isDisplayed();

    }
}
