package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.JsonHandler;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.clipboard.HasClipboard;
import io.appium.java_client.pagefactory.*;
import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;


import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class AccountDetailsPage_Mobile {


    public AppiumDriver driver;
    JsonHandler jsonHandler = new JsonHandler();

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Account details\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Account details']")
    public WebElement accountDetailsPage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Account type']//following-sibling::XCUIElementTypeStaticText|//XCUIElementTypeStaticText[@label='Account type']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Account Type']//following-sibling::*")
    public WebElement accountType;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Account name' or  @label='Account name ']/..//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Account Name']//following-sibling::*")
    public WebElement accountName;

    @iOSXCUITFindBy(iOSNsPredicate = "type == \"XCUIElementTypeImage\"")
    @AndroidFindBy(id = "com.bsf.retail.dev:id/icon")
    public WebElement accountProductIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText)[5]")
    @AndroidFindBy(xpath = "(//android.widget.TextView)[1]")
    public WebElement accountNameText;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText)[6]")
    @AndroidFindBy(xpath = "(//android.widget.LinearLayout[@resource-id=\"com.bsf.retail.uat:id/transactionsJourney_summaryStackView\"]//android.widget.TextView)[1]")
    public WebElement accountNumber;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText)[7]")
    @AndroidFindBy(xpath = "(//android.widget.TextView)[3]")
    public WebElement accountBalance;

    @iOSXCUITFindAll({
            @iOSXCUITBy(className = "XCUIElementTypeStaticText")
    })
    @AndroidFindAll({
            @AndroidBy(className = "android.widget.TextView")
    })
    public List<WebElement> headingLabels;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='General']//following-sibling::*//XCUIElementTypeStaticText")
    })

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='General']//..//following-sibling::androidx.cardview.widget.CardView//android.widget.TextView")
    public List<WebElement> headingLabelsUnderGeneralSection;


    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Transactions\"]|//XCUIElementTypeButton[@name=\"Add a beneficiary\"]")
    @AndroidFindBy(accessibility = "Navigate up")
    public WebElement navigateBackButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"close\"]")
    @AndroidFindBy(accessibility = "Navigate up")
    public WebElement crossButton;

    @iOSXCUITFindBy(accessibility = "ExternalAction")
    @AndroidFindBy(accessibility = "Edit account name")
    public WebElement accountNameEditIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name='CopyButton'])[0]")
    @AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc='Copied to Clipboard'])[1]")
    public WebElement accountNameCopyToClipboard;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name='CopyButton'])[1]")
    @AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc='Copied to Clipboard'])[2]")
    public WebElement accountNumberCopyToClipboard;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name='CopyButton'])[2]")
    @AndroidFindBy(xpath = "(//android.widget.ImageView[@content-desc='Copied to Clipboard'])[3]")
    public WebElement accountIbanNoCopyToClipboard;

    @iOSXCUITFindBy(iOSNsPredicate = "label == 'Share'")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Share']")
    public WebElement accountShareText;
    @AndroidFindBy(id = "com.bsf.retail.dev:id/continueWith")
    public WebElement selectProfile;

    @iOSXCUITFindBy(accessibility = "Usuario1 Apellido1")
    @AndroidFindBy(id = "com.google.android.apps.messaging:id/name")
    public WebElement selectFirstContactNumber;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"To:\" AND name == \"To:\" AND type == \"XCUIElementTypeTextField\"")
    public WebElement textFileNameInput;

    @iOSXCUITFindBy(accessibility = "messageBodyField")
    public WebElement textFileNameMessageBody;

    @iOSXCUITFindBy(accessibility = "ComposeRecipientAddButton")
    public WebElement addRecipientButton;

    @AndroidFindBy(id = "android:id/button1")
    public WebElement selectNewMessageButton;

    @AndroidFindBy(id = "com.google.android.apps.messaging:id/recipient_text_view")
    public WebElement enterNumber;

    @AndroidFindBy(id = "com.google.android.apps.messaging:id/contact_name")
    public WebElement sendTo;

    @iOSXCUITFindBy(accessibility = "Send")
    @AndroidFindBy(accessibility = "Send SMS")
    public WebElement clickSendSMS;

    GenericMethod genericMethod = new GenericMethod();

    public AccountDetailsPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void verifyAccountDetailsScreen() {
        System.out.println("Verifying Details Screen");
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        accountDetailsPage.isDisplayed();
        Assert.assertTrue(accountDetailsPage.isDisplayed());
    }


    public void selectBackButton() {
        System.out.println("Tap Back Button");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOf(navigateBackButton));
        navigateBackButton.click();
    }

    public void selectCrossButton() {
        System.out.println("Tap Back Button");
        crossButton.click();
    }

    public void verifyAccountName(MyProductsPage_Mobile myProductsPage_mobile) {
        accountName.isDisplayed();
        Assert.assertEquals(accountName.getText(), jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName"));
    }

    public void verifyAccountName(MyProductsPage_Mobile myProductsPage_mobile, String heading) {
        accountName.isDisplayed();
        Assert.assertEquals(accountName.getText(), jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName"));
        Assert.assertEquals(accountType.getText(), heading);
    }

    public void verifyAccountProductIcon() {
        accountProductIcon.isDisplayed();
        Assert.assertTrue(accountProductIcon.isDisplayed());
    }

    public void verifyAccountName() {
        accountNameText.isDisplayed();
        Assert.assertTrue(accountNameText.isDisplayed());
    }

    public void verifyAccountNumber() {
        accountNumber.isDisplayed();
        Assert.assertTrue(accountNumber.isDisplayed());
    }

    public void verifyAccountBalance() {
        accountBalance.isDisplayed();
        Assert.assertTrue(accountBalance.isDisplayed());
    }

    public List<String> getTextOfElements(List<WebElement> elementsList) {
        List<String> elementText = new ArrayList<>();
//		System.out.println("List Size:"+elementsList.size());
        elementsList.forEach(element -> {
            var elementValue = element.getText();
//			System.out.println("Value: "+elementValue);
            if (elementValue != null) elementText.add(elementValue.toLowerCase().trim());
        });
        return elementText;
    }

    public void labelExists(String headingLabel, String exists) {
        if(headingLabel.contains("Other"))
        {
            genericMethod.scrollDown(driver);
        }
        List<String> elementsText = getTextOfElements(headingLabels);
        if (exists.equalsIgnoreCase("if any")) {
            try {
                Assert.assertTrue(elementsText.contains(headingLabel));
                return;
            } catch (AssertionError error) {
                System.out.println("No Heading Found:" + headingLabel);
                return;
            }
        }
        Assert.assertTrue(elementsText.contains(headingLabel.toLowerCase()));
    }


    public void verifyLabelUnderGeneralSection(String label) {
        try {
            List<String> elementsText = getTextOfElements(headingLabelsUnderGeneralSection);
            System.out.println("elementsText " +elementsText);

            Assert.assertTrue(elementsText.contains(label.toLowerCase()));
        } catch (AssertionError e) {
            genericMethod.scrollToDown(driver);
            List<String> elementsText = getTextOfElements(headingLabelsUnderGeneralSection);
            Assert.assertTrue(elementsText.contains(label.toLowerCase()));
        }


    }

    public void verifyLabelWithEditIcon() {
        accountNameEditIcon.isDisplayed();
        Assert.assertTrue(accountNameEditIcon.isDisplayed());
        Assert.assertTrue(accountName.isDisplayed());
    }

    public void verifyAccountNumberCopied(String title) {
        String result = null;
        if (RunnerInfo.getDeviceType().contains("android")) {
            if (title.toLowerCase().contains("name")) {
                result = ((HasClipboard) driver).getClipboardText();
            } else if (title.toLowerCase().contains("number")) {
                result = ((HasClipboard) driver).getClipboardText();
            } else {
                result = ((HasClipboard) driver).getClipboardText();
            }
        } else {
            System.out.println("Skipping Verification for iOS");
            return;
        }

        Assert.assertFalse(result.isEmpty());
    }

    public void clickOnCopyToClipBoard(String title) {
        if (title.toLowerCase().contains("name")) {
            accountNameCopyToClipboard.click();
        } else if (title.toLowerCase().contains("number")) {
            accountNumberCopyToClipboard.click();
        } else {
            accountIbanNoCopyToClipboard.click();
        }
    }

    public void selectProfile() {
        selectProfile.isDisplayed();
        selectProfile.click();
    }

    public void selectShare() {
        accountShareText.isDisplayed();
        accountShareText.click();
    }

    public void selectContactNumber() throws InterruptedException {
        if (RunnerInfo.getDeviceType().contains("android")) {
            if (genericMethod.isElementPresent(selectFirstContactNumber)) {
                selectFirstContactNumber.click();
            } else {
                selectNewMessageButton.click();

                enterNumber.sendKeys("0999999999");
                Map<String, String> params = new HashMap<>();
                params.put("action", "done");
                driver.executeScript("mobile:performEditorAction", params);
                Thread.sleep(2000);
//                sendTo.click();

            }
        } else {
//			addRecipientButton.click();
            textFileNameInput.sendKeys("u");
            selectFirstContactNumber.click();
            String value = textFileNameMessageBody.getText();
            System.out.println("Body: " + value);
//			Assert.assertTrue(value.toLowerCase().contains("name"));
            Assert.assertTrue(value.toLowerCase().contains("account number"));
            Assert.assertTrue(value.toLowerCase().contains("iban"));
        }
        clickSendSMS.click();
        if (RunnerInfo.getDeviceType().contains("android")) driver.navigate().back();

    }
}
