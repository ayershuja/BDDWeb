package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

public class ExistingUserRegistrationPage_Mobile {

    AppiumDriver driver;

    @iOSXCUITFindBy(xpath = "/XCUIElementTypeButton[@name=\"Register to BSF\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/registerActionButton")
    public WebElement registerToBsfButton;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[1]")
//    @AndroidFindBy(xpath = "(//android.widget.TextView[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[1] | //android.widget.TextView[@text='Registration']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Registration'] | //android.widget.TextView[@text='Select a card'] | //android.widget.TextView[@text='Please enter your PIN'] | //android.widget.TextView[@text='Username setup'] | //android.widget.TextView[@text='Password screen'] | //android.widget.TextView[@text='Confirm Password']")
    public WebElement title;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[2]")
//    @AndroidFindBy(xpath = "(//android.widget.TextView[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[2] | //android.widget.TextView[@text='Please enter the ID you registered with while opening your account']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Please enter the ID you registered with while opening your account'] | //android.widget.TextView[@text='Please select a card for validation'] | //android.widget.TextView[@text='Please create a 4-digit login passcode for your BSF app'] | //android.widget.TextView[@text='Enter username'] | //android.widget.TextView[@text='Enter password'] | //android.widget.TextView[@text='Enter confirm password']")
    public WebElement subTitle;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[3]")
//    @AndroidFindBy(xpath = "(//android.widget.TextView[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[3] | //android.widget.TextView[@text='National ID']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='National ID'] | //android.widget.TextView[@text='Please enter username'] | //android.widget.TextView[@text='Password']")
    public WebElement headerTitle;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[4]")
//    @AndroidFindBy(xpath = "(//android.widget.TextView[contains(translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('titleView', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))])[4]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Forget user'] | //android.widget.TextView[@text='Forget']")
    public WebElement subHeaderTitle;

    @iOSXCUITFindBy(accessibility = "registration.governmentId.nationalid.input.textInput.textField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/register_usernameField")
    public WebElement inputUserNameField;

    @iOSXCUITFindBy(accessibility = "registration.governmentId.nationalid.input.textInput.textField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/newPasswordEditText")
    public WebElement inputPasswordField;
    @AndroidFindBy(id = "com.bsf.retail.uat:id/confirmPasswordEditText")
    public WebElement inputConfirmPasswordField;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/authenticator_otpInputScreen_otpInputField")
    public WebElement inputOTPField;

    // Card detail
    @AndroidFindBy(id = "com.bsf.retail.uat:id/imageview")
    public WebElement selectCard;

    public ExistingUserRegistrationPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void selectRegisterToBsf() {
        registerToBsfButton.click();
    }
    public void enterUserName(String userName) {

        inputUserNameField.clear();
        inputUserNameField.sendKeys(userName);
    }
    public void enterPassword(String key, String password) {
        if(key.contains("password")) {
            inputPasswordField.clear();
            inputPasswordField.sendKeys(password);
        }
        else{
            inputConfirmPasswordField.clear();
            inputConfirmPasswordField.sendKeys(password);
        }
    }
    public void selectFirstCard() {
        selectCard.click();
    }
    public void clickOnDigitNumber(String number) {
        inputOTPField.click();
        WebElement ele = null;
        if (RunnerInfo.getDeviceName().contains("android"))
            ele = driver.findElement(By.xpath("//android.widget.Button[starts-with(@text, '"+number+"')]"));
        else
            ele = driver.findElement(By.xpath("//XCUIElementTypeButton[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + number.toLowerCase() + "']"));
        ele.isDisplayed();
        ele.click();
    }

    public void verifyText(String key, String value) {
        String actualValue  = "";
        if (key.equalsIgnoreCase("TITLE")) {
            actualValue = title.getText();
        }
        else if(key.equalsIgnoreCase("SUB_TITLE")) {
            actualValue = subTitle.getText();
                  }
        else if(key.equalsIgnoreCase("HEADER_TITLE")) {
            actualValue = headerTitle.getText();
        }
        else{
            actualValue = subHeaderTitle.getText();
        }
        Assert.assertEquals(actualValue.trim(), value.trim(), "Failed to verify value : " + value+" but found : " + actualValue);
    }


}
