package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.*;
import Utils.PropertiesOperations;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import java.util.concurrent.TimeUnit;

public class InternationalBeneficiaryAccountPage_Mobile {
    public AppiumDriver driver;
    GenericMethod genericMethod = new GenericMethod();
    @iOSXCUITFindBy(xpath = " //XCUIElementTypeStaticText[@name=\"Full name\"]//following-sibling::*//XCUIElementTypeTextField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormIntNameField")
    public WebElement enterFullName;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Swift code\"]/following-sibling::*//XCUIElementTypeTextField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormIntSwiftCodeField")
    public WebElement swiftCode;

    @iOSXCUITFindBy(className = "XCUIElementTypeSwitch")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/switchBankForm")
    public WebElement switchSwiftCode;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSearchField[@name=\"Search\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/search_src_text")
    public WebElement searchTextView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Account number or IBAN\"]//following-sibling::*//XCUIElementTypeTextField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormScreenAccountLabelField")
    public WebElement enterAccountNumber;
    @iOSXCUITFindBy(accessibility = "submitButtonID")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/bankFormScreen_submitButton")
    public WebElement bankContinueButton;

    public InternationalBeneficiaryAccountPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }

    public void VerifyInlineErrorMessage(String message, String field) {
        //wait.until(ExpectedConditions.visibilityOf(OtherPurposeLabel));
        String locator = "";
        if (RunnerInfo.getDeviceType().contains("android")) {
            locator = "(//*[contains(@text,'" + field + "')]//following-sibling::android.widget.LinearLayout//*[contains(@resource-id,'textinput_error')])[1]";
        } else {
            locator = "(//XCUIElementTypeStaticText[contains(@value,'"+field+"')]//following-sibling::*//XCUIElementTypeTextField//following-sibling::XCUIElementTypeStaticText)[1]";
        }
        WebElement element = driver.findElement(By.xpath(locator));
        System.out.println(element.getText());
        junit.framework.Assert.assertTrue(element.getText().contains(message));
    }

    public void VerifyGhostText(String message, String field) {
        //wait.until(ExpectedConditions.visibilityOf(OtherPurposeLabel));
        String locator = "";
        if (RunnerInfo.getDeviceType().contains("android")) {
            locator = "(//*[contains(@text,'" + field + "')]//following-sibling::android.widget.LinearLayout//android.widget.EditText)[1]";
        } else {
            locator = "//XCUIElementTypeStaticText[@name='" + field + "']//following-sibling::*//XCUIElementTypeTextField";
        }
        WebElement element = driver.findElement(By.xpath(locator));
        System.out.println(element.getText());
        junit.framework.Assert.assertEquals(message, element.getText());
    }

    public void enterSwiftCode(String filename, String value) {
        swiftCode.clear();
        swiftCode.sendKeys(PropertiesOperations.getPropertyValueByKey(filename, value).trim());
    }

    public void enterEnterFullName(String filename, String name) {
        enterFullName.clear();
        enterFullName.sendKeys(PropertiesOperations.getPropertyValueByKey(filename, name).trim());
    }

    public void switchSwiftCode(String value) {
        String elementValue;
        if (RunnerInfo.getDeviceType().contains("android")) elementValue = switchSwiftCode.getAttribute("checked");
        else elementValue = switchSwiftCode.getAttribute("value");
        boolean isOnOrOff = genericMethod.convertToBoolean(elementValue);
        System.out.println("BooL: "+isOnOrOff);
        if (value.toUpperCase().contains("ON") && !isOnOrOff) {
            switchSwiftCode.click();
        } else if (value.toUpperCase().contains("OFF") && isOnOrOff) {
            switchSwiftCode.click();
        }
    }

    public void enterValueInSearch(String filename, String key) {
        String value = PropertiesOperations.getPropertyValueByKey(filename, key).trim();
        if (RunnerInfo.getDeviceType().contains("android"))
            searchTextView.sendKeys(value);
        else {
            for (char item : value.toCharArray()) {
                searchTextView.sendKeys(String.valueOf(item));
            }
        }

    }

    public void enterAccountNumber(String filename, String address) {
        enterAccountNumber.clear();
        enterAccountNumber.sendKeys(PropertiesOperations.getPropertyValueByKey(filename, address).trim());
    }

    public void clickBankContinueButton() {
        bankContinueButton.click();
    }

    public void verifySwiftCodeLimit(int characerLimit) {
        Assert.assertTrue(swiftCode.getText().length()<=characerLimit);
    }
}
