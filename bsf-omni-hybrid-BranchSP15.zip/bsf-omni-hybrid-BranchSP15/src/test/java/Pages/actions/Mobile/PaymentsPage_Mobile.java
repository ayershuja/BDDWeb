package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.JsonHandler;
import Utils.WebElementHandler;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AuthenticatesByFinger;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.PerformsTouchID;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import java.time.Duration;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class PaymentsPage_Mobile {

    public AppiumDriver driver;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Payments\" AND name == \"Payments\" AND value == \"Payments\"")
    public WebElement paymentsScreen;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeNavigationBar/XCUIElementTypeStaticText)[last()]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text=\"Review\"]")
    public WebElement screenName;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Payments\" AND name == \"Payments\" AND value == \"Payments\"")
    public WebElement selectBeneficiaryScreen;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Select beneficiary\"")
    public WebElement transferToSomeoneButton;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"One time transfer \"])[1]")
    public WebElement optionText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSearchField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/rcj_searchScreen_searchBar")
    public WebElement searchField;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"contactListCell.nameLabelID\"]")
    @AndroidFindBy(xpath = "android.widget.TextView[1]")
    public List<WebElement> allAccounts;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"accountTableView.accountName\"])[1]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[2]//android.widget.TextView[1]")
    public WebElement selectAccountScreenAccountName;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"accountTableView.accountNumber\"])[1]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[2]//android.widget.TextView[2]")
    public WebElement selectAccountScreenAccountNumber;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmountDescription\"])[1]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[2]//android.widget.TextView[3]")
    public WebElement selectAccountScreenAccountAmountDescription;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\"])[1]")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[2]//android.widget.TextView[4]")
    public WebElement selectAccountScreenAccountCurrencyAndBalance;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTextField[@name=\"amountTextInputID.textInput.textField\"]")
    @AndroidFindBy(xpath = "//android.widget.EditText[@text='0.00']")
    public WebElement amountHelperText;

    @iOSXCUITFindBy(accessibility = "selectPurposeInputField.textInput.textField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/purposeSelectorInput")
    public WebElement purposeSelector;

    @iOSXCUITFindBy(accessibility = "enterPurposeInputField.textInput.textField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/purposeOtherInput")
    public WebElement otherPurposeHelperText;

    @iOSXCUITFindBy(accessibility = "enterPurposeInputField.errorLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement otherPurposeError;

    @iOSXCUITFindBy(accessibility = "selectPurposeInputField.errorLabel")
    public WebElement selectPurposeError;

    @iOSXCUITFindBy(accessibility = "amountTextInputID.errorLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/errorMessage")
    public WebElement amountInputError;

    @iOSXCUITFindBy(accessibility = "amountTextInputID.textInput.textField")
    @AndroidFindBy(xpath = "//android.widget.EditText[@text,'0.00']")
    public WebElement amountInput;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"completeImageID\"]/XCUIElementTypeImage")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/image")
    public WebElement transferCompleteImage;

    WebDriverWait wait;

    public PaymentsPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void verifyPaymentsScreen() {
        paymentsScreen.isDisplayed();
        Assert.assertTrue(paymentsScreen.isDisplayed());
    }


    public void clickPaymentTransferToSomeone() {
        transferToSomeoneButton.click();
    }

    public void verifySelectBeneficiaryScreen() {
        selectBeneficiaryScreen.isDisplayed();
        Assert.assertTrue(selectBeneficiaryScreen.isDisplayed());
    }

    public void selectBeneficiary(String beneficiaryName) {
        driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@name='contactListCell.nameLabelID' and @value='" + beneficiaryName + "'])[1]")).click();
    }

    public void verifyScreenOpen(String screenName) {
        this.screenName.isDisplayed();
        Assert.assertEquals(this.screenName.getText().toLowerCase().trim(), screenName.toLowerCase().trim());
    }

    public void verifyOptionValue(String optionValue) {
        WebElement elementValue = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='" + optionValue + "']"));
        wait.until(ExpectedConditions.visibilityOf(elementValue));
        Assert.assertEquals(elementValue.getText().toLowerCase().trim(), optionValue.toLowerCase().trim());
    }

    public void verifySearchField() {
        searchField.isEnabled();
        Assert.assertTrue(searchField.isDisplayed());
    }

    public void verifyAccountsInAlphabeticalOrder() {
        new GenericMethod().isSorted(new GenericMethod().getTextOfElements(driver, allAccounts), 1);
    }

    public void verifyBeneficiariesDetails(String verifyLabel) {
        int index = -1;

        if (RunnerInfo.getDeviceType().contains("android")) {
            switch (verifyLabel.toLowerCase()) {
                case "full name" -> index = 1;
                case "account number" -> index = 2;
                case "bank-country" -> index = 3;
            }
            String xpath = "//android.view.ViewGroup/android.widget.TextView[" + index + "]";
            int totalElements = driver.findElements(By.xpath("//android.view.ViewGroup")).size();
            int elementsFound = driver.findElements(By.xpath(xpath)).size();
            Assert.assertEquals(elementsFound, totalElements);
        } else {
            switch (verifyLabel.toLowerCase()) {
                case "full name" -> index = 3;
                case "account number" -> index = 1;
                case "bank-country" -> index = 2;
            }
            String xpath = "//XCUIElementTypeCell/XCUIElementTypeStaticText[" + index + "]";
            int totalElements = driver.findElements(By.xpath("//XCUIElementTypeCell")).size();
            int elementsFound = driver.findElements(By.xpath(xpath)).size();
            Assert.assertEquals(elementsFound, totalElements);
        }

//        switch (verifyLabel.toLowerCase()) {
//            case "full name" -> index = 3;
//            case "account number" -> index = 1;
//            case "bank-country" -> index = 2;
//        }
//        String xpath = "//XCUIElementTypeCell/XCUIElementTypeStaticText["+index+"]";
//        int totalElements = driver.findElements(By.xpath("//XCUIElementTypeCell")).size();
//        int elementsFound = driver.findElements(By.xpath(xpath)).size();
//        Assert.assertEquals(elementsFound,totalElements);
    }

    public void verifySelectAccountScreenDetails(String detail, String expectedValue) {
        switch (detail.toLowerCase()) {
            case "name" -> Assert.assertEquals(selectAccountScreenAccountName.getText(), expectedValue);
            case "account number" -> Assert.assertEquals(selectAccountScreenAccountNumber.getText(), expectedValue);
            case "label" -> Assert.assertEquals(selectAccountScreenAccountAmountDescription.getText(), expectedValue);
            case "current balance" ->
                    Assert.assertEquals(selectAccountScreenAccountCurrencyAndBalance.getText(), expectedValue);
            default -> throw new RuntimeException("Wrong Label");
        }
    }

    public void selectAccount(String selectAccountName, String currencyType) {
        driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\" and contains(@value,'" + currencyType + "')]/following-sibling::XCUIElementTypeStaticText[@value='" + selectAccountName + "'])[1]")).click();
    }

    public void verifyLabelValue(String labelValue, String type) {
        String elementValue;
//        System.out.println("If: "+Objects.equals(type, "contains"));
        if (RunnerInfo.getDeviceType().contains("android")) {
            // if(Objects.equals(type, "contains")) elementValue = driver.findElement(By.xpath("//android.widget.TextView[contains(@text='"+labelValue+"')]")).getText();
            // else
            elementValue = driver.findElement(By.xpath("//android.widget.TextView[@text='" + labelValue + "']")).getText();
            Assert.assertTrue(elementValue.contains(labelValue));
        } else {
            if (Objects.equals(type, "contains"))
                elementValue = driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@label,'" + labelValue + "')]")).getText();
            else
                elementValue = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='" + labelValue + "']|//XCUIElementTypeButton[@label='" + labelValue + "']")).getText();
            Assert.assertTrue(elementValue.contains(labelValue));
        }
//        if(Objects.equals(type, "contains")) elementValue = driver.findElement(By.xpath("//XCUIElementTypeStaticText[contains(@label,'"+labelValue+"')]")).getText();
//        else elementValue = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='"+labelValue+"']")).getText();
//        Assert.assertTrue(elementValue.contains(labelValue));
    }

    public void verifyLabelButtonValue(String labelValue, String type) {
        String elementValue;
//        System.out.println("If: "+Objects.equals(type, "contains"));
        if (Objects.equals(type, "contains"))
            elementValue = driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@label,'" + labelValue + "')]")).getText();
        else
            elementValue = driver.findElement(By.xpath("//XCUIElementTypeButton[@label='" + labelValue + "']")).getText();
        Assert.assertTrue(elementValue.contains(labelValue));
    }

    public void clickLabelButtonValue(String labelValue, String type) {
        if (Objects.equals(type, "contains"))
            driver.findElement(By.xpath("//XCUIElementTypeButton[contains(@label,'" + labelValue + "')]")).click();
        else driver.findElement(By.xpath("//XCUIElementTypeButton[@label='" + labelValue + "']")).click();
    }

    public void verifyHelperTextr(String helperText) {

        if (RunnerInfo.getDeviceType().contains("android")) {
            //   Assert.assertEquals(amountHelperText.getAttribute("value"),helperText);
            Assert.assertEquals(amountHelperText.getText(), helperText);
        } else {
            Assert.assertEquals(amountHelperText.getAttribute("value"), helperText);
        }

        //    Assert.assertEquals(amountHelperText.getAttribute("value"),helperText);
    }

    public void clickPuposeSelector(String optionValue) {
        purposeSelector.click();
        WebElement option = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@value='" + optionValue + "']"));
        option.isDisplayed();
        option.click();
    }

    public void verifyOtherPurposeHelperText(String helperText) {

        if (RunnerInfo.getDeviceType().contains("android")) {
            //   Assert.assertEquals(amountHelperText.getAttribute("value"),helperText);
            Assert.assertEquals(otherPurposeHelperText.getText(), helperText);
        } else {
            Assert.assertEquals(otherPurposeHelperText.getAttribute("value"), helperText);
        }
        //  Assert.assertEquals(otherPurposeHelperText.getAttribute("value"),helperText);
    }

    public void clickOnButton(String button) {
        driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@value='" + button + "' or @label='" + button + "'])[1]")).click();
    }

    public void verifyOtherPurposeErrorMessage(String errorMessage) {
        Assert.assertEquals(otherPurposeError.getText(), errorMessage);
    }

    public void verifySelectErrorMessage(String errorMessage) {
        Assert.assertEquals(selectPurposeError.getText(), errorMessage);
    }

    public void verifyAmountError(String amountError) {
        Assert.assertEquals(amountInputError.getText().trim(), amountError.trim());
    }

    public void verifyTransferAmount(String amount) {
        amountInput.clear();
        amountInput.sendKeys(amount);
    }

    public void verifyTransferCompleteSuccessIcon() {
        Assert.assertTrue(transferCompleteImage.isDisplayed());
    }
}
