package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.JsonHandler;
import Utils.WebElementHandler;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import java.time.Duration;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class DraftPage_Mobile {
    GenericMethod genericMethod = new GenericMethod();
    public AppiumDriver driver;
    WebElementHandler webElementHandler = new WebElementHandler();

    WebDriverWait wait;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"More\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='More']")
    public WebElement moreIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Drafts\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='DRAFT']")
    public WebElement draftIcon;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Messages']")
    public WebElement messageIcon;

    @iOSXCUITFindBy(accessibility = "uibutton.navbar.add.button.title")
    @AndroidFindBy(accessibility = "New Message")
    public WebElement newMessageIcon;

    @iOSXCUITFindBy(className = "XCUIElementTypePickerWheel")
    public WebElement picker;

    @iOSXCUITFindBy(iOSNsPredicate = "value == 'Select topic'")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/topic")

    public WebElement selectTopic;

    @AndroidFindBy(id = "android:id/text1")
    public WebElement clickOnSampleTopic;

    @iOSXCUITFindBy(accessibility = "composeMessage.subjectTextInput.textInput.textField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/subject")
    public WebElement subjectTextview;

    @iOSXCUITFindBy(accessibility = "composeMessage.bodyTextInput")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/body")
    public WebElement messageTextview;

    @iOSXCUITFindBy(accessibility = "attachmentBarButton")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/menu_messages_attach_file")
    public WebElement attachFileIcon;

    @AndroidFindBy(id = "com.google.android.documentsui:id/icon_thumb")
    public WebElement selectFile;

    @AndroidFindBy(xpath = "//android.widget.TextView[ends-with(@text,'.pdf')]")
    public WebElement selectPDFFile;

    @AndroidFindBy(accessibility = "Show roots")
    public WebElement showRoots;

    @iOSXCUITFindBy(accessibility = "composeMessage.sendBarButton")
    @AndroidFindBy(accessibility = "Send")
    public WebElement sendButton;

    @iOSXCUITFindBy(accessibility = "composeMessage.closeBarButton")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='New message']//..//android.widget.ImageButton")
    public WebElement cancelIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Messages\"]|//XCUIElementTypeButton[@name=\"Select beneficiary\"]|//XCUIElementTypeButton[@name=\"Payments\"]|//XCUIElementTypeButton[@name=\"Select beneficiary\"]|(//XCUIElementTypeButton[@name=\"More\"])[1]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc='Messages']/android.view.ViewGroup/android.widget.ImageButton")
    public WebElement navigateBackButton;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Messages\"]|//XCUIElementTypeButton[@name=\"Select beneficiary\"]|//XCUIElementTypeButton[@name=\"Payments\"]|//XCUIElementTypeButton[@name=\"Select beneficiary\"]|(//XCUIElementTypeButton[@name=\"More\"])[1]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[contains(@resource-id,'messagesJourney_navHostFragmentContainer')]//android.view.ViewGroup/android.widget.ImageButton")
    public WebElement navigateBackMessageButton;
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Downloads'])[last()]")
    public WebElement downloadIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCell//XCUIElementTypeStaticText[2]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/draftSubjectTextView")
    public List<WebElement> draftMessageSubject;

    @iOSXCUITFindBy(accessibility = "composeMessage.topicPicker.doneButton")
    public WebElement donePicker;

    @iOSXCUITFindBy(accessibility = "composeMessage.sendBarButton")
    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Send\"]")
    public WebElement sentIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable//XCUIElementTypeCell[1]//XCUIElementTypeStaticText")
    public List<WebElement> latestDraftMessageDetails;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Messages\"")
    @AndroidFindBy(accessibility = "Messages")
    public WebElement messageScreen;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeSegmentedControl//XCUIElementTypeButton")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/avatarTextView")
    public List<WebElement> iconList;

    @iOSXCUITFindBy(accessibility = "Inbox")
    @AndroidFindBy(accessibility = "Inbox")
    public WebElement iconInbox;

    @iOSXCUITFindBy(accessibility = "Sent")
    @AndroidFindBy(accessibility = "Sent")
    public WebElement iconSent;

    @iOSXCUITFindBy(accessibility = "Drafts")
    @AndroidFindBy(accessibility = "Drafts")
    public WebElement iconDraft;

    @iOSXCUITFindBy(accessibility = "deleteButton")
    @AndroidFindBy(accessibility = "Delete")
    public WebElement deleteIcon;

    @iOSXCUITFindBy(accessibility = "Discard")
    @AndroidFindBy(accessibility = "Discard")
    public WebElement discardButton;
    @iOSXCUITFindBy(accessibility = "Delete")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/deleteFrameLayout")
    public WebElement deleteButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable//XCUIElementTypeCell")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/avatarTextView")
    public List<WebElement> messageList;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable//XCUIElementTypeCell")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/avatarTextView")
    public List<WebElement> messageList2;

    @iOSXCUITFindBy(accessibility = "edgeCaseTitle")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/title")
    public WebElement edgeCaseIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"edgeCaseTitle\"]/../following-sibling::*/*")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/message")
    public WebElement edgeCaseSentence;

    @iOSXCUITFindBy(accessibility = "initials")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/messageConstraint")
    public WebElement messageContext;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeOther[@name=\"message.cardView\"])[2]")
    @AndroidFindBy(id = "androidx.cardview.widget.CardView")
    public WebElement conversationList;
    @iOSXCUITFindBy(accessibility = "Reply")
    @AndroidFindBy(accessibility = "Reply")
    public WebElement replyIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"input.errorLabel\"]|//XCUIElementTypeStaticText[@name=\"composeMessage.subjectTextInput.errorLabel\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement errorMessage;

    public DraftPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
    }

    public void initializer() {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void clickMoreIcon() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOf(moreIcon));
        moreIcon.click();
    }

    public void clickDraftIcon() {
        draftIcon.click();
    }

    public void clickMessageIcon() {
        messageIcon.click();
    }

    public void clickNewMessageIcon() {
        newMessageIcon.click();
    }

    public void selectTopicSpinner() throws InterruptedException {

        Thread.sleep(10);
        if (selectTopic.isDisplayed()) {
            selectTopic.click();
            Thread.sleep(10);
            if (RunnerInfo.getDeviceType().contains("android")) {
                WebElement value = driver.findElement(MobileBy.AndroidUIAutomator("new UiSelector().className(android.widget.Spinner).childSelector(new UiSelector().className(android.widget.EditText).index(0))"));
                String val = value.getText();
                clickOnSampleTopic.click();
            } else {
//                    HashMap<Object, Object> params = new HashMap<>();
//                    params.put("order", "next");
//                    params.put("offset", 0.15);
//                    params.put("element", picker);
//                    driver.executeScript("mobile: selectPickerWheelValue", params);
                new JsonHandler().writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "draftTopic", picker.getAttribute("value"));
                donePicker.click();
            }
        }
    }

    public void selectTopicSpinnerValue(String value) throws InterruptedException {

        Thread.sleep(10);
        if (RunnerInfo.getDeviceType().contains("android")) {
            String locator = "(//android.widget.CheckedTextView[@resource-id='android:id/text1'])[2]";
            WebElement element;
            try {
                element = driver.findElement(By.xpath(locator));
                element.click();
            } catch (Exception e) {
                selectTopic.click();
                element = driver.findElement(By.xpath(locator));
                element.click();
            }
//                if (!genericMethod.isElementPresent(driver.findElement(By.xpath(locator)))) {
//                    selectTopic.click();
//                }
//                element = driver.findElement(By.xpath(locator));
//
//                element.click();

        } else {
            genericMethod.setPicker(driver, picker, value, donePicker);
            new JsonHandler().writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "draftTopic", value);
        }
    }

    public void enterSubject(String subject) {

        subjectTextview.clear();
        subjectTextview.sendKeys(subject);
    }

    public void enterMessage(String message) {
        messageTextview.sendKeys(message);
    }

    public void clickCancelIcon() {
        cancelIcon.click();
    }

    public void clickOnAttachIcon() {
        attachFileIcon.click();
    }

    public void clickOnShowRootsIcon() {
        if (RunnerInfo.getDeviceType().contains("android")) showRoots.click();
    }

    public void clickOnSendIcon() throws InterruptedException {
        Thread.sleep(120);
        sendButton.isEnabled();
        sendButton.click();
    }

    public void clickIcon(String title) {

        WebElement ele = null;
        if (RunnerInfo.getDeviceType().contains("android"))
            ele = driver.findElement(By.xpath("//android.widget.TextView[@text='" + title + "']"));
        else
            ele = driver.findElement(By.xpath("//XCUIElementTypeButton[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + title.toUpperCase() + "']"));
        ele.isDisplayed();
        ele.click();
    }

    public void verifyIconIsDisplayed(String title) {

        WebElement ele = null;
        if (RunnerInfo.getDeviceType().contains("android"))
            ele = driver.findElement(By.xpath("//android.widget.TextView[@text='" + title + "']"));
        else
            ele = driver.findElement(By.xpath("//XCUIElementTypeButton[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + title.toUpperCase() + "']|//XCUIElementTypeStaticText[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + title.toUpperCase() + "']"));
        ele.isDisplayed();
    }

    public void clickOnButtonIcon(String title) {

        WebElement ele = null;
        if (RunnerInfo.getDeviceType().contains("android"))
            driver.findElement(By.xpath("//android.widget.Button[@text='" + title + "']")).click();
        else
            driver.findElement(By.xpath("//XCUIElementTypeButton[translate(@name,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + title.toUpperCase() + "']")).click();
//        ele.isDisplayed();
//        ele.click();
    }

    public void clickOnTheButtonIcon(String title) {

        WebElement ele;
        if (RunnerInfo.getDeviceType().contains("android"))
            driver.findElement(By.xpath("//android.widget.Button[@content-desc='" + title + "']")).click();
        else
            driver.findElement(By.xpath("//XCUIElementTypeButton[translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='" + title.toUpperCase() + "' or contains(translate(@label,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ'),'" + title.toUpperCase() + "')]")).click();
//        ele.isDisplayed();
//        ele.click();
    }

    public void clickOnIdIcon(String title) {
        driver.findElement(By.id("" + title + "")).click();
    }

    public void selectFile() {
        selectPDFFile.click();
    }

    public void clickOnNavigation() {
        navigateBackButton.click();
    }

    public void clickOnMessageNavigation() {
        navigateBackMessageButton.click();
    }

    public void clickOnDownload() {
        if (RunnerInfo.getDeviceType().contains("android")) {
            try {
                if (downloadIcon.isEnabled() && !downloadIcon.isSelected()) {
                    downloadIcon.click();
                }
            } catch (Exception e) {
                if (!downloadIcon.isSelected()) {
                    downloadIcon.click();
                }
            }
        }
    }

    public void verifyDraftMessageIsDisplay() {
        for (WebElement draftElement : draftMessageSubject) {
            draftElement.isDisplayed();
        }

    }

    public void clickOnSentIcon() {
        sentIcon.click();
    }

    public void verifyLatestDraftMessage(String subject, String message, String time) {
        List<String> elementValues = webElementHandler.getTextFromWebElements(latestDraftMessageDetails);
        Assert.assertTrue(elementValues.contains(subject));
        Assert.assertTrue(elementValues.contains(message));
        Assert.assertTrue(elementValues.contains(time));
        Assert.assertTrue(elementValues.contains(new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "draftTopic")));
        Assert.assertTrue(elementValues.contains("Draft"));
    }

    public void verifyLatestSentMessage(String subject, String time, String user) {
        List<String> elementValues = webElementHandler.getTextFromWebElements(latestDraftMessageDetails);
        Assert.assertTrue(elementValues.contains(subject));
        Assert.assertTrue(elementValues.contains(time));
        Assert.assertTrue(elementValues.contains(new JsonHandler().getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "draftTopic")));
        Assert.assertTrue(elementValues.contains(user.toLowerCase()));
    }

    public void verifyMessageScreen() {
        messageScreen.isDisplayed();
        Assert.assertTrue(messageScreen.isDisplayed());
    }

    public void verifySelectedIcon(String iconType) {
        List<String> elementValues = webElementHandler.getTextFromWebElements(iconList);
        System.out.println("Array:" + elementValues.toString());
        System.out.println("Icon Type:" + iconType);
        Assert.assertFalse(elementValues.contains(iconType));
        iconList.forEach(item -> {
            if (Objects.equals(item.getText().toLowerCase(), "1")) Assert.assertEquals(item.getAttribute("value"), "1");
        });
    }

    public void clickOnIconSent() {
        iconSent.click();
    }

    public void clickOnIconInbox() {
        iconInbox.click();
    }

    public void clickOnIconDraft() {
        iconDraft.click();
    }

    public void selectConversationFirstMessage() {
        messageContext.click();
    }

    public void verifyConversationFirstMessage() {
        wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(messageContext)));
        Assert.assertTrue(messageContext.isDisplayed(), "Failed to verify conversation is displayed");
    }

    public void verifyConversationIsDisplayed(String message) {
        boolean result = true;
        result = !message.toLowerCase().contains("no");
        Assert.assertEquals(genericMethod.isElementPresent(conversationList), result, "Failed to verify " + message + "conversation");
    }

    public void clickOnReplyIcon() {
        replyIcon.click();
    }

    public void deleteAllMessages(String messageType) {
        List<String> elementValues = webElementHandler.getTextFromWebElements(iconList);
        TouchAction action = null;
        if (elementValues.contains(messageType)) {
            iconList.get(elementValues.indexOf(messageType)).click();
        }
        if (RunnerInfo.getDeviceType().contains("android"))
            action = new TouchAction((AndroidDriver) driver);
        else action = new TouchAction((IOSDriver) driver);
        System.out.println("Element Size: " + messageList.size());

        if (messageList.size() < 1) return;
//        else if (messageList.size()<2) {
//            action.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(messageList.get(0)))).release().perform();
//        }
//        else {
//            action.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(messageList.get(0)))).release().perform();
//            for (int i = 1; i < messageList.size(); i++) {
//                messageList.get(i).click();
//            }
//        }
//        deleteIcon.click();
//        if(Objects.equals(messageType, "Drafts")) discardButton.click();
////            else if(Objects.equals(messageType, "Sent")) deleteButton.click();
//        else deleteButton.click();

//
//       for (WebElement element : messageList) {
        action.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(messageList.get(0)))).release().perform();
//            initializer();
//        }

        for (int val = 1; val < messageList2.size(); val++) {
            action.longPress(LongPressOptions.longPressOptions().withElement(ElementOption.element(messageList2.get(val)))).release().perform();
//            initializer();
        }
//       if(messageList.size()>=1) {
        deleteIcon.click();
        if (Objects.equals(messageType, "Drafts")) discardButton.click();
//            else if(Objects.equals(messageType, "Sent")) deleteButton.click();
        else deleteButton.click();
//       }
    }

    public void verifyEdgeCase(String edgeCaseIconValue, String edgeCaseSentenceValue) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.visibilityOf(edgeCaseIcon));
        Assert.assertEquals(edgeCaseIcon.getText(), edgeCaseIconValue);
        Assert.assertEquals(edgeCaseSentence.getText(), edgeCaseSentenceValue);
    }

    public void verifyCreateBeneficiaryErrorMessage(String errorMessageText) {
        Assert.assertEquals(errorMessage.getText().trim(), errorMessageText.trim(), "Failed to verify " + errorMessageText + " error message is not displayed");
    }

    public void verifySelectTopicIsDisplayed(String messageText) {
        Assert.assertEquals(selectTopic.getText().trim(), messageText.trim(), "Failed to verify " + messageText + " message is not displayed");
    }

    public void clickOnSelectTopic() throws InterruptedException {
        Thread.sleep(2000);
        Assert.assertTrue(selectTopic.isDisplayed(), "Failed to verify select topic is not displayed");
        selectTopic.click();
    }
}
