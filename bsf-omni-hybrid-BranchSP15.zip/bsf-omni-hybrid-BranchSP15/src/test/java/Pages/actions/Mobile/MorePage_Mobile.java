package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import java.util.concurrent.TimeUnit;

public class MorePage_Mobile {

    AppiumDriver driver;
    GenericMethod generic_method = new GenericMethod();

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"More\" AND name == \"More\" AND value == \"More\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='More']")
    public WebElement moreScreen;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Messages\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Messages']")
    public WebElement messageIcon;

    @AndroidFindBy(id = "android:id/button_once")
    public WebElement justOnce;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Settings')]")
    public WebElement settingsIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Settings\"")
    public WebElement settingsPageIcon;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Unlink device')]")
    public WebElement unlinkOption;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Are you sure you want to unlink this device?\" AND name == \"Are you sure you want to unlink this device?\" AND value == \"Are you sure you want to unlink this device?\"")
    public WebElement modalPopup;

    @iOSXCUITFindBy(accessibility = "Unlink this device")
    public WebElement unlinkButton;

    @iOSXCUITFindBy(accessibility = "Cancel")
    public WebElement cancelButton;


    public MorePage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void verifyMoreScreen() {
        moreScreen.isDisplayed();
        Assert.assertTrue(moreScreen.isDisplayed());
    }

    public void clickMessageIcon() {
        try {
            messageIcon.click();
        }catch (Exception e) {
          System.out.println("Message button already selected");
        }
//        if (RunnerInfo.getDeviceType().contains("android")) {
//            justOnce.click();
//        }
    }

    public void clickSettingsIcon() {
        settingsIcon.click();
    }

    public void verifySettingsScreen() {
        settingsPageIcon.isDisplayed();
        Assert.assertTrue(settingsPageIcon.isDisplayed());
    }

    public void clickOnUnlinkDeviceOption() {
        unlinkOption.click();
    }

    public void verifyModalPopUp() {
        Assert.assertTrue(modalPopup.isDisplayed());
    }

    public void clickUnlinkDevice() {
        unlinkButton.click();
    }

    public void clickCancelButton() {
        cancelButton.click();
    }
}
