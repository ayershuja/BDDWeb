package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

public class InternalTransferPage_Mobile {

    AppiumDriver driver;

    //   @AndroidFindBy(xpath = "//android.widget.EditText[@text,'0.00']")
    //   public WebElement enterAmountText;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Make a transfer\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text,'Make a transfer']")
    public WebElement TransfrAcrossMyAccPag;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"From\" AND name == \"paymentPartyViewButtonID\"")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/fromAccountTitle")
    public WebElement FromAcc;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"To\"]|//XCUIElementTypeStaticText[@name=\"From\"]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[@content-desc=\"To\"]|//android.widget.FrameLayout[@content-desc=\"From\"] ")
    public WebElement SelctAccPag;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"To\" AND name == \"paymentPartyViewButtonID\"")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/toAccountTitle")
    public WebElement ToAcc;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\" and contains(@value,'SAR') and not(@value='SAR 0.00')])[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='I am rich man']")
    public WebElement SelectAccFromTo;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@value=\"Staff Loan\"])[1]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Staff Loan'])[1]")
    public WebElement AccSameCurr;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"usman\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Savings account to cover kids education fees']")
    public WebElement AccountFromPage;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Review\"")
    @AndroidFindBy(xpath = "//android.view.ViewGroup/android.widget.TextView[@text,'Review']")
    public WebElement ReviewPage;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"amountSummaryNameID\"])[2]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/amount")
    public WebElement AmountToVerify;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"Payments\"])[1]")
    @AndroidFindBy(xpath = "//android.widget.ImageButton[@content-desc='Navigate up']")
    public WebElement navigateBackBtn;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Success\"")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/title")
    public WebElement VerifySuccess;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inlineErrorID\"])[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/fromAccountSelectionError")
    public WebElement FromAccError;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"inlineErrorID\"])[2]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/toAccountSelectionError")
    public WebElement ToAccError;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"SADAD\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/sadad_bill_list_toolbarLayout")
    public WebElement BillPayPage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Transfer money between accounts')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Transfer money between accounts']")
    public WebElement TransferMonBtwOwnAc;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[contains(@name,\"doneButton\")])[last()]|(//XCUIElementTypeButton[contains(@name,\"submitButton\")])[last()]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnContinue")
    public WebElement btnCont;

    @iOSXCUITFindBy(accessibility = "doneButtonID")
    public WebElement btnCompletion;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Bill pay')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Bill pay']")
    public WebElement billPay;

    @iOSXCUITFindBy(accessibility = "ic arrow drop down")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/currencySelectorButton")
    public WebElement CurrencySlctr;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"SADAD\"]|//XCUIElementTypeButton[@name=\"Back\"]")
    @AndroidFindBy(accessibility = "Navigate up")
    public WebElement BacknavigatorBtn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnConfirmReview")
    public WebElement ConfirmSendBtn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/amountReviewValue")
    public WebElement trasferSAR;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/descriptionTitle")
    public WebElement detailLbl;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/includeTransferFeeLabel")
    public WebElement inclTrnsfrFee;


    public InternalTransferPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void clickTransferMonBtwnOwnAcc() {
//        WebElement ele = null;
//        if (driver.getClass().toString().toLowerCase().contains("android")) ele = driver.findElement(By.xpath("//android.widget.TextView[@text='Transfer money between accounts']"));

        TransferMonBtwOwnAc.isDisplayed();
        TransferMonBtwOwnAc.click();
    }

    public void verifyTransferAccrsMyAccPage() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransfrAcrossMyAccPag.isDisplayed());
            System.out.println("Transfer Across my page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void clickFrom() {
        FromAcc.isDisplayed();
        FromAcc.click();
    }

    public void verifySlctAccPage(String optionVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(SelctAccPag.isDisplayed());
            System.out.println("Select Account page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
     //   Assert.assertEquals(SelctAccPag.getText(), optionVal);
    }

    public void clickTo() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ToAcc.isDisplayed());
            System.out.println("Account To verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        ToAcc.click();
    }

    public void selectAcc(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SelectAccFromTo.isEnabled());
            System.out.println("Select Account From page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        SelectAccFromTo.click();
    }

    public void clickButtnContinue(String optVal) {

        btnCont.click();
        //       driver.findElement(By.id("com.bsf.retail.dev:id/bottomButton")).click();
    }

    public void clickButtnCompletion(String optVal) {
        if (RunnerInfo.getDeviceType().contains("android")) btnCont.click();
        else btnCompletion.click();
        //       driver.findElement(By.id("com.bsf.retail.dev:id/bottomButton")).click();
    }

    public void verifyReviewPage() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(ReviewPage.isDisplayed());
            System.out.println("Review page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyEnteredAmount() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(AmountToVerify.isDisplayed());
            System.out.println("Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void clickNavigateBack() {
        System.out.println("Tap Back Button");
        navigateBackBtn.click();
    }

    public void verifySuccess() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(VerifySuccess.isDisplayed());
            System.out.println("Success verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyAccErrorMsg(String optVal) {
        Assert.assertEquals(FromAccError.getText(), optVal);
    }

    public void verifyToAccErrMsg(String optVal) {
        Assert.assertEquals(ToAccError.getText(), optVal);
    }

    public void clickBillPay() {
//        WebElement ele = null;
//        if (RunnerInfo.getDeviceType().contains("android")) ele = driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"Pay, Bill pay, SADAD\"]/android.widget.TextView[1]"));

        billPay.isDisplayed();
        billPay.click();
    }

    public void verifyBillPay() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(BillPayPage.isDisplayed());
            System.out.println("Bill Pay page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyAccClickable() {

        Assert.assertFalse(AccountFromPage.isEnabled());

    }

    public void verifyAccFromClickable() {

        Assert.assertFalse(SelectAccFromTo.isEnabled());
    }

    public void verifyDefaultAmount(String optVal) {
        String elementValue;
//        System.out.println("If: "+Objects.equals(type, "contains"));

        if (RunnerInfo.getDeviceType().contains("android"))
            elementValue = driver.findElement(By.xpath("//android.widget.EditText[@text='" + optVal + "']")).getText();
        else
            elementValue = driver.findElement(By.xpath("//XCUIElementTypeTextField[@value='" + optVal + "']")).getText();
        Assert.assertTrue(elementValue.contains(optVal));

    }

    public void verifySourceCurreny(String optVal) {
        String elementValue;

        if (RunnerInfo.getDeviceType().contains("android"))
            elementValue = driver.findElement(By.xpath("//android.widget.TextView[@text='" + optVal + "']")).getText();
        else
            elementValue = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@value='" + optVal + "']")).getText();
        Assert.assertTrue(elementValue.contains(optVal));

    }

    public void clickCurrencySlctr() {

        CurrencySlctr.click();
    }

    public void clickCurrency(String optVal) {

        if (RunnerInfo.getDeviceType().contains("android"))
            driver.findElement(By.xpath("//android.widget.TextView[@text='" + optVal + "']")).click();
        else driver.findElement(By.xpath("//XCUIElementTypeButton[@name='" + optVal + "']")).click();
    }

    public void clickAccSameCurr() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(AccSameCurr.isDisplayed());
            System.out.println("Select Account From page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        AccSameCurr.click();

    }

    public void clickBackNavigator() {
        System.out.println("Tap Back Button");
        BacknavigatorBtn.click();
    }

    public void verifyContBtn(String optVal) {

        Assert.assertEquals(btnCont.getText(), optVal);
    }

    public void verifyConfirmSendBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ConfirmSendBtn.isDisplayed());
            System.out.println("Select Account page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ConfirmSendBtn.isEnabled());
        Assert.assertEquals(ConfirmSendBtn.getText(), optVal);

    }

    public void clickConfirmSendBtn(String optVal) {

        Assert.assertTrue(ConfirmSendBtn.isEnabled());
        Assert.assertEquals(ConfirmSendBtn.getText(), optVal);

        ConfirmSendBtn.click();
    }

    public void verifyTransferAmount(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(trasferSAR.isDisplayed());
            System.out.println("Select Account page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(trasferSAR.isEnabled());
        Assert.assertEquals(trasferSAR.getText(), optVal);

    }

    public void verifyDetailLabel(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(detailLbl.isDisplayed());
            System.out.println("Select Account page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(detailLbl.isEnabled());
        Assert.assertEquals(detailLbl.getText(), optVal);
    }

    public void verifyInclTransferFee(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(inclTrnsfrFee.isDisplayed());
            System.out.println("Select Account page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(inclTrnsfrFee.isEnabled());
        Assert.assertEquals(inclTrnsfrFee.getText(), optVal);
    }

    public void verifyLabelOnRevScreen(String optVal) {

        WebElement lblOnRevScreen = driver.findElement(By.xpath("//android.widget.TextView[@text='"+optVal+"']"));

        Assert.assertTrue(lblOnRevScreen.isEnabled());
        Assert.assertEquals(lblOnRevScreen.getText(), optVal);
    }

//    public void enterAmount() {
//
//        enterAmountText.isDisplayed();
//        enterAmountText.click();
//        enterAmountText.sendKeys("10");
//    }
}
