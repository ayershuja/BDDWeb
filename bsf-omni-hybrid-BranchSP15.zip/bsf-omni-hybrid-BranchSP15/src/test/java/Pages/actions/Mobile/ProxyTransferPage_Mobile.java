package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.JsonHandler;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class ProxyTransferPage_Mobile {

    AppiumDriver driver;
    JsonHandler jsonHandler = new JsonHandler();

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Payments\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Payments']")
    public WebElement MyPaymentsPage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Transfer money between accounts')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Transfer money between accounts']")
    public WebElement TransferMonBtwOwnAcc;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Transfer money to someone')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Transfer money to someone']")
    public WebElement TransferMonSomOneAcc;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Bill pay')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Bill pay']")
    public WebElement billPay;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'MOI payments')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='MOI payments']")
    public WebElement moiPay;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[contains(@label,'Request to pay')]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Request to pay']")
    public WebElement reqPay;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Select beneficiary\"]")
    @AndroidFindBy(accessibility = "Select beneficiary")
    public WebElement MyBeneficiaryPage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"Aseel Gammoh\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Aseel Gammoh']")
    public WebElement firstAccount;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"SA9710000010100000014402\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='SA23 6010 0002 7950 0265 6001']")
    public WebElement AccountNo;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label=\"The National Commercial Bank\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Bank Al Jazira']")
    public WebElement BankCountry;


    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Select account\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text ='From']")
    public WebElement fromPage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\" and contains(@value,'SAR') and not(@value='SAR 0.00')]/..")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/amountText\" and contains(@text,'SAR') and not(@text='SAR 0.00')]/..")
    public List<WebElement> AccountsSAR;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\" and contains(@value,'SAR')]/..")
    @AndroidFindBy(xpath = "//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/amountText\" and contains(@text,'SAR')]/..")
    public List<WebElement> AccountsSAR2;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Transfer details\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Transfer details']")
    public WebElement TransferDetPage;

    @iOSXCUITFindBy(accessibility = "selectPurposeInputField.textInput.textField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/purposeSelectorInput")
    public WebElement purposeSelector;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Others\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Others']")
    public WebElement purposeOPtion;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Continue\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnContinue")
    public WebElement btnContinue;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"paymentPartySummaryNameID\"])[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/fromAccountName")
    public WebElement fromAccountName;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"paymentPartyAccountNumberID\"])[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/fromAccountNumber")
    public WebElement fromAccountNumber;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"paymentPartySummaryNameID\"])[2]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/toAccountName")
    public WebElement toAccountName;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"paymentPartyAccountNumberID\"])[2]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/toAccountNumber")
    public WebElement toAccountNumber;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/title")
    public WebElement OneTimeTrnsfr;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etIBAN")
    public WebElement IBANTxt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etFirstNameIBAN")
    public WebElement FullNameTxt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etPhoneNumber")
    public WebElement PhoneNoTxt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etSelectBankForPhone")
    public WebElement BankDropDown;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement ErrPhoneNo;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etEmail")
    public WebElement EmailAdd;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etSelectBankForEmail")
    public WebElement BankDrpDwn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etIQAMA")
    public WebElement EnterIqama;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/etSelectBankForIQAMA")
    public WebElement SlctBank;

    @AndroidFindBy(id = "android:id/message")
    public WebElement SrvcNtAvlblPopUp;


    public ProxyTransferPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void verifyPaymentPage() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(MyPaymentsPage.isDisplayed());
            System.out.println("My Payments page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyTrnsfrMonBtwOwnAcc() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransferMonBtwOwnAcc.isDisplayed());
            System.out.println("Transfer between own accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyTrnsfrMonSomeOneAcc() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransferMonSomOneAcc.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyBillPay() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(billPay.isDisplayed());
            System.out.println("Bill Pay verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyMOIPay() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(moiPay.isDisplayed());
            System.out.println("MOI Pay verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void reqToPay() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(reqPay.isDisplayed());
            System.out.println("Request to Pay verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void clickTrnsfrMonSomOnEAcc() {
//        WebElement ele = null;
//        if (driver.getClass().toString().toLowerCase().contains("android")) ele = driver.findElement(By.xpath("//android.widget.TextView[@text='Transfer money to someone']"));

        TransferMonSomOneAcc.isDisplayed();
        TransferMonSomOneAcc.click();
    }

    public void verifyBeneficiaryPage() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(MyBeneficiaryPage.isDisplayed());
            System.out.println("Beneficiary page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void selectFirstAcc() {
        firstAccount.isDisplayed();
//        if (driver.getClass().toString().toLowerCase().contains("android")) {
//            saveAccountDetails(firstAccount,"content-desc");
//        }else {
//            saveAccountDetails(firstAccount,"label");
//        }
        firstAccount.click();
    }

    public void verifyAccDetailsPage() {

    }

    public void verifyFromPage() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(fromPage.isDisplayed());
            System.out.println("From page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void clickAccfromList() {
        try {
            Thread.sleep(6000);
 //           Assert.assertTrue(AccountsSAR.isDisplayed());
            System.out.println("Transfer Detail page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

//        AccountsSAR.click();
    }

    public void clickAccfromList(String accountType) {
        if (accountType.equalsIgnoreCase("from")) setAccount(accountType, AccountsSAR);
        else if (accountType.equalsIgnoreCase("to")) setAccount(accountType, AccountsSAR2);
        else throw new RuntimeException("Wrong Account Type");
    }

    public void setAccount(String accountType, List<WebElement> listOfElements) {
        int highestCurrencyIndex = -1, lowestCurrencyIndex = -1;
        double currentCurrencyElementValue, highestCurrencyElementValue = -1, lowestCurrencyElementValue = 10000000;
        for (WebElement element : listOfElements) {
            String val = element.findElement(By.xpath("//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\"] | //android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/amountText\"]")).getText();
            String val2 = StringUtils.join(val.split(" ")[1].split(","), "");
//            System.out.println("Value: "+val);
            System.out.println("Value: " + val2);
//            System.out.println("Value: "+val.split(" ")[0]);
//            System.out.println("Value: "+val.split(" ")[1]);
            currentCurrencyElementValue = Double.parseDouble(val2);
            if (accountType.equalsIgnoreCase("from") && currentCurrencyElementValue > highestCurrencyElementValue) {
                System.out.println("Current>Highest");
                System.out.println(currentCurrencyElementValue > highestCurrencyElementValue);
                highestCurrencyIndex = listOfElements.indexOf(element);
                highestCurrencyElementValue = currentCurrencyElementValue;
            } else if (accountType.equalsIgnoreCase("to") && currentCurrencyElementValue < lowestCurrencyElementValue) {
                System.out.println("Current<Lowest");
                System.out.println(+currentCurrencyElementValue < lowestCurrencyElementValue);
                lowestCurrencyIndex = listOfElements.indexOf(element);
                lowestCurrencyElementValue = currentCurrencyElementValue;
            }
        }
        if (accountType.equalsIgnoreCase("from")) {
            saveAccountToDetails(listOfElements.get(highestCurrencyIndex), accountType);
            listOfElements.get(highestCurrencyIndex).click();
        } else if (accountType.equalsIgnoreCase("to")) {
            saveAccountToDetails(listOfElements.get(lowestCurrencyIndex), accountType);
            listOfElements.get(lowestCurrencyIndex).click();
        } else throw new RuntimeException("Wrong Account Type");
    }

    public void clickAccfromList(String accountType, String currency) {
        if (accountType.equalsIgnoreCase("from")) {
            List<WebElement> elements = driver.findElements(By.xpath("//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\" and contains(@value,'" + currency.toUpperCase() + "') and not(@value='" + currency.toUpperCase() + " 0.00')]/.. | //android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/amountText\" and contains(@text,'" + currency.toUpperCase() + "') and not(@text='" + currency.toUpperCase() + " 0.00')]/.."));
            setAccount(accountType, elements);
        } else if (accountType.equalsIgnoreCase("to")) {
            List<WebElement> elements = driver.findElements(By.xpath("//XCUIElementTypeStaticText[@name=\"accountTableView.accountAmount\" and contains(@value,'" + currency.toUpperCase() + "')]/.. | //android.widget.TextView[@resource-id='com.bsf.retail.uat:id/amountText' and contains(@text,'" + currency.toUpperCase() + "')]/.."));
            setAccount(accountType, elements);
        } else throw new RuntimeException("Wrong Account Type");
    }


    public void saveAccountToDetails(WebElement element, String accountType) {
        String toAccountName = element.findElement(By.xpath("//*[@name=\"accountTableView.accountName\" or @resource-id = 'com.bsf.retail.uat:id/accountName']")).getText();
        String toAccountNumber = element.findElement(By.xpath("//*[@name=\"accountTableView.accountNumber\" or @resource-id = 'com.bsf.retail.uat:id/accountNumber']")).getText();
        if (accountType.equalsIgnoreCase("to")) {
            jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "TransferAccountDetails", "ToAccountName", toAccountName);
            jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "TransferAccountDetails", "ToAccountNumber", toAccountNumber);
        } else if (accountType.equalsIgnoreCase("from")) {
            jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "TransferAccountDetails", "FromAccountName", toAccountName);
            jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() +"TransferAccountDetails", "FromAccountNumber", toAccountNumber);
        } else throw new RuntimeException("Wrong Account Type");
    }

    public void verifyTransferDetPage() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransferDetPage.isDisplayed());
            System.out.println("Transfer Detail page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void selectPurpose(String option) {

        purposeSelector.click();

        WebElement Option = driver.findElement(By.xpath("//android.widget.TextView[@text='"+option+"']"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(Option.isDisplayed());
            System.out.println("Others option verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(Option.getText(),option);

        Option.click();
    }

    public void clickButton(String optionVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(btnContinue.isDisplayed());
            System.out.println("Continue button verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(btnContinue.getText(), optionVal);
        btnContinue.click();

        //    driver.findElement(By.id("com.bsf.retail.dev:id/btnContinue")).click();
    }

    public void verifyAccName(String optVal) {

        Assert.assertEquals(firstAccount.getText(), optVal);
    }

    public void verifyAccNo(String optVal) {

        Assert.assertEquals(AccountNo.getText(), optVal);
    }

    public void verifyBankCountry(String optVal) {

        Assert.assertEquals(BankCountry.getText(), optVal);
    }

    public void verifyToAndFromAccountNameAndAccountNumber() {
        Assert.assertEquals(toAccountName.getText(), "To " + jsonHandler.getJsonValue(RunnerInfo.getDeviceType() +"TransferAccountDetails", "ToAccountName"));
        Assert.assertEquals(toAccountNumber.getText(), jsonHandler.getJsonValue(RunnerInfo.getDeviceType() +"TransferAccountDetails", "ToAccountNumber"));
        Assert.assertEquals(fromAccountName.getText(), "From " + jsonHandler.getJsonValue(RunnerInfo.getDeviceType() +"TransferAccountDetails", "FromAccountName"));
        Assert.assertEquals(fromAccountNumber.getText(), jsonHandler.getJsonValue(RunnerInfo.getDeviceType() +"TransferAccountDetails", "FromAccountNumber"));
    }

    public void clickOneTimeTrnsfr(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(OneTimeTrnsfr.isDisplayed());
            System.out.println("My Payments page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(OneTimeTrnsfr.isEnabled());
        Assert.assertEquals(OneTimeTrnsfr.getText(), optVal);
        OneTimeTrnsfr.click();
    }

    public void verifyChips(String optVal) {
        WebElement Chips = driver.findElement(By.xpath("//android.widget.TextView[@text='"+optVal+"']"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(Chips.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(Chips.isEnabled());
        Assert.assertEquals(Chips.getText(),optVal);
    }

    public void clickChip(String optVal) {
        WebElement Chips = driver.findElement(By.xpath("//android.widget.TextView[@text='"+optVal+"']"));

        Assert.assertTrue(Chips.isEnabled());
        Assert.assertEquals(Chips.getText(),optVal);
        Chips.click();
    }

    public void verifyFullNameTxt(String optVal) {
        WebElement EditTxt = driver.findElement(By.xpath("//android.widget.EditText[@text='"+optVal+"']"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(EditTxt.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(EditTxt.isEnabled());
        Assert.assertEquals(EditTxt.getText(),optVal);
    }

    public void verifyIBANTxt() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(IBANTxt.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(IBANTxt.isEnabled());
        Assert.assertEquals(IBANTxt.getText(),"XX XXXX XXXX XXXX XXXX XXXX");
    }

    public void enterFullName(String optVal) {
        Assert.assertTrue(FullNameTxt.isEnabled());
        FullNameTxt.sendKeys(optVal);
    }

    public void enterIBAN(String optVal) {

        Assert.assertTrue(IBANTxt.isEnabled());
        IBANTxt.sendKeys(optVal);
    }

    public void enterPhoneNo(String optVal) {
        Assert.assertTrue(PhoneNoTxt.isEnabled());
        PhoneNoTxt.sendKeys(optVal);
    }

    public void clickBankDropdown() {
        Assert.assertTrue(BankDropDown.isEnabled());
        BankDropDown.click();

    }

    public void verifyPhoneErr(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(ErrPhoneNo.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ErrPhoneNo.isEnabled());
        Assert.assertEquals(ErrPhoneNo.getText(),optVal);
    }

    public void enterEmail(String optVal) {

        Assert.assertTrue(EmailAdd.isEnabled());
        EmailAdd.sendKeys(optVal);
    }

    public void clickBankDrpDwn() {

        Assert.assertTrue(BankDrpDwn.isEnabled());
        BankDrpDwn.click();
    }

    public void enterIqama(String optVal) {
        Assert.assertTrue(EnterIqama.isEnabled());
        EnterIqama.sendKeys(optVal);
    }

    public void SelectBank() {
        Assert.assertTrue(SlctBank.isEnabled());
        SlctBank.click();
    }

    public void verifyServiceNotAvlblePopUp(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SrvcNtAvlblPopUp.isDisplayed());
            System.out.println("bill Amount verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SrvcNtAvlblPopUp.isEnabled());
        Assert.assertEquals(SrvcNtAvlblPopUp.getText(),optVal);

    }
}
