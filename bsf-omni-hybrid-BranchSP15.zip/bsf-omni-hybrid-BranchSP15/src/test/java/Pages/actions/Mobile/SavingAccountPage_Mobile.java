package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import java.time.Duration;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.Reporter;

import java.util.concurrent.TimeUnit;

public class SavingAccountPage_Mobile {

    AppiumDriver driver;

    @AndroidFindBy(accessibility = "My Products")
    public WebElement MyProductsPage;
    @AndroidFindBy(xpath = "//android.widget.Button[@text='Transfer']")
    public WebElement transferIcon;
    @AndroidFindBy(xpath = "//android.widget.Button[@text='Statement']")
    public WebElement statementsIcon;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Details\"")
    @AndroidFindBy(xpath = "//android.widget.Button[@text='Details']")
    public WebElement detailsIcon;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTable//XCUIElementTypeOther//XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(xpath = "(//android.widget.FrameLayout//following-sibling::android.widget.TextView)[1]")
    public WebElement savingAccountName;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTable//XCUIElementTypeOther//XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(xpath = "(//android.widget.FrameLayout//following-sibling::android.widget.TextView)[1]")
    public WebElement currentAccountName;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTable//XCUIElementTypeOther//XCUIElementTypeStaticText)[2]")
    @AndroidFindBy(xpath = "(//android.widget.FrameLayout//following-sibling::android.widget.TextView)[2]")
    public WebElement savingAccountNumber;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTable//XCUIElementTypeOther//XCUIElementTypeStaticText)[2]")
    @AndroidFindBy(xpath = "(//android.widget.FrameLayout//following-sibling::android.widget.TextView)[2]")
    public WebElement currentAccountNumber;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTable//XCUIElementTypeOther//XCUIElementTypeStaticText)[3]")
    @AndroidFindBy(xpath = "(//android.widget.FrameLayout//following-sibling::android.widget.TextView)[3]")
    public WebElement savingAccountCurrencyValue;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTable//XCUIElementTypeOther//XCUIElementTypeStaticText)[3]")
    @AndroidFindBy(xpath = "(//android.widget.FrameLayout//following-sibling::android.widget.TextView)[3]")
    public WebElement currentAccountCurrencyValue;
    GenericMethod genericMethod = new GenericMethod();
    public SavingAccountPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public String getElementValue(WebElement element) {
        return element.getText();
    }

    public void verifySavingAccountName(String name) {
        System.out.println("Verifying Name");
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }
        savingAccountName.isDisplayed();
        Assert.assertTrue(savingAccountName.getText().contains(name));
//		Assert.assertEquals(savingAccountName.getText(),name);
    }
    public void verifyCurrentAccountName(String name) {
        System.out.println("Verifying Name");
        try {
            System.out.println("waiting for 7 seconds");
            Thread.sleep(10000);
        } catch (Exception e) {

        }
//        if(genericMethod.isElementPresent(currentAccountName)){
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        Assert.assertTrue(currentAccountName.getText().contains(name), "Failed to verify actual account name : " + currentAccountName.getText() + " and expected account name : " + name);
//        }
//        else{
//            Assert.fail("Element is not displayed");
//        }
        //		Assert.assertEquals(savingAccountName.getText(),name);
    }

    public void verifySavingAccountNumber(String number) {
        System.out.println("Verifying Number");

        if(genericMethod.isElementPresent(savingAccountNumber)){
        Assert.assertEquals(savingAccountNumber.getText().replaceAll(" ", ""), number.replaceAll(" ", ""));
    }
        else{
        Assert.fail("Element is not displayed");
    }
    }
    public void verifyCurrentAccountNumber(String number) {
        System.out.println("Verifying Number");
//        if(genericMethod.isElementPresent(currentAccountNumber)){
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Assert.assertEquals(currentAccountNumber.getText().replaceAll(" ", ""), number.replaceAll(" ", ""));
//    }
//        else{
//        Assert.fail("Element is not displayed");
//    }
    }

    public void verifySavingAccountCurrencyValue(String currencyValue) {
        System.out.println("Verifying Currency");
        savingAccountCurrencyValue.isDisplayed();
        System.out.println("Actual savingAccountCurrencyValue" +savingAccountCurrencyValue.getText());
        System.out.println("Expected savingAccountCurrencyValue" +currencyValue);
        Assert.assertTrue(currencyValue.contains(savingAccountCurrencyValue.getText()));
//		Assert.assertEquals(savingAccountCurrencyValue.getText().replaceAll(" ", ""),currencyValue.replaceAll(" ", ""));
    }
    public void verifyCurrentAccountCurrencyValue(String currencyValue) {
        System.out.println("Verifying Currency");
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        currentAccountCurrencyValue.isDisplayed();
        Assert.assertTrue(currencyValue.contains(currentAccountCurrencyValue.getText()));
    }


    public void selectDetailsIcon() {
        System.out.println("Clicking  Details Icon");
        try {
            Thread.sleep(3000);
        } catch (Exception e) {

        }
        detailsIcon.click();
    }

    public void verifyDetailsIcon() {
        System.out.println("Verify  Details Icon");
        detailsIcon.isDisplayed();
    }

}
