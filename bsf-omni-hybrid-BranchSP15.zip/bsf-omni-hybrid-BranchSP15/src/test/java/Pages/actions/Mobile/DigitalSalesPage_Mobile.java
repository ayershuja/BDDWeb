package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import java.util.concurrent.TimeUnit;

public class DigitalSalesPage_Mobile {

    LoginPage_Mobile loginPage_mobile = new LoginPage_Mobile();
    AppiumDriver driver;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Open an account\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/openAccountActionButton")
    public WebElement OpenAcc;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Next\"]|//XCUIElementTypeStaticText[@name=\"Get started\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnNext")
    public WebElement NextBtn;

    @iOSXCUITFindBy(accessibility = "walkthrough.step3.checkbox")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/cbTermsAndConditions")
    public WebElement ChkBox;

    @iOSXCUITFindBy(accessibility = "step-navigation.navigation.progress-text")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/lblTitle")
    public WebElement RegTitle;

    @iOSXCUITFindBy(accessibility = "step-navigation.navigation.title")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/lblProgress")
    public WebElement LabelTxt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/tvIdentityTitle")
    public WebElement LblTxt;

    @iOSXCUITFindBy(accessibility = "forgot.credential.nationalid.input.titleLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/tvNationalIdTitle")
    public WebElement NatIDTxt;

    @iOSXCUITFindBy(accessibility = "forgot.credential.nationalid.input.errorLabel")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement IdErr;

    @iOSXCUITFindBy(accessibility = "forgot.credential.nationalid.input.textInput.textField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/etNationalId")
    public WebElement EnterIqama;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Back\"]|//XCUIElementTypeStaticText[@name=\"Skip\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnSkip")
    public WebElement BackBtn;

    @iOSXCUITFindBy(accessibility = "walkthrough.title")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Why BSF?']")
    public WebElement FirstWalkThru;

    @iOSXCUITFindBy(accessibility = "walkthrough.title")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Let’s get started']")
    public WebElement TermsCond;

    @iOSXCUITFindBy(accessibility = "walkthrough.title")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Get ready!']")
    public WebElement SecondWalkThru;

    @iOSXCUITFindBy(accessibility = "walkthrough.image")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/imgWalkthrough")
    public WebElement ImgView;

    @iOSXCUITFindBy(accessibility = "walkthrough.description")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Before proceeding, keep in mind the following requirements.']")
    public WebElement SubText;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Registered in the National Address and downloaded the Nafath app\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Registered in the National Address and downloaded the Nafath app']")
    public WebElement FirstPoint;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Get more information on the Saudi Post National Address and Nafath app.\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Get more information on the Saudi Post website and Nafath app']")
    public WebElement FirstPointSubTxt;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"A linked mobile number with your identity document\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='A linked mobile number with your identity document']")
    public WebElement ScndPoint;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"You are the sole beneficiary of the account\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='You are the sole beneficiary of the account']")
    public WebElement FifthPoint;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"You must be at least 18 years old\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='You must be at least 18 years old']")
    public WebElement ThirdPoint;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"You or one of your relatives are not politically exposed\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='You or one of your relatives are not politically exposed']")
    public WebElement ForthPoint;

    @iOSXCUITFindBy(accessibility = "Skip")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/btnSkip")
    public WebElement SkipBtn;

    @iOSXCUITFindBy(accessibility = "walkthrough.description")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Your journey starts with us. Welcome to BSF.']")
    public WebElement SubTxt;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Let the impossible become possible\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Let the impossible become possible']")
    public WebElement FrstPoint;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Discover BSF financing\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Discover BSF financing']")
    public WebElement FrstPointFrstSubTxt;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Quicker and easier \"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Quicker and easier']")
    public WebElement SecondPointTxt;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Manage your funds easily\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Manage your funds easily']")
    public WebElement SecondPointSubTxt;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"On-demand advisory\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='On-demand advisory']")
    public WebElement ThirdPointTxt;

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"An advisor at the click of button\"")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='An advisor at the click of button']")
    public WebElement ThirdPointSubTxt;

    @iOSXCUITFindBy(accessibility = "walkthrough.description")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='You are just minutes away from opening your account']")
    public WebElement SubHding;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"I confirm that I have read and agreed to the Terms, conditions, and privacy policy\")]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/txtTermsAndConditions")
    public WebElement TnCText;


    public DigitalSalesPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void clickOpenAcc(String optVal) {

        loginPage_mobile.verifySelectYourScreen();
        loginPage_mobile.selectEnglishLanguage();
        loginPage_mobile.selectContinueLanguage();
        loginPage_mobile.verifyWelcomeScreen();

        try {
            Thread.sleep(6000);
            Assert.assertTrue(OpenAcc.isDisplayed());
            System.out.println("Open new Acc button verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        OpenAcc.isEnabled();
        Assert.assertEquals(OpenAcc.getText(), optVal);
        OpenAcc.click();

    }

    public void clickNextBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(NextBtn.isDisplayed());
            System.out.println("Next Button display verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        NextBtn.isEnabled();
        Assert.assertEquals(NextBtn.getText(), optVal);
        NextBtn.click();

    }

    public void tapCheckBox() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ChkBox.isEnabled());
            System.out.println("Terms & Conditions checkbox enable verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        ChkBox.click();
    }

    public void clickGetStrtdBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(NextBtn.isDisplayed());
            System.out.println("Get Started display verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        NextBtn.isEnabled();
        Assert.assertEquals(NextBtn.getText(), optVal);
        NextBtn.click();
    }

    public void verifyRegst(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(RegTitle.isDisplayed());
            System.out.println("Registration page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(RegTitle.getText(), optVal);
    }

    public void verifyLabel(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(LabelTxt.isDisplayed());
            System.out.println("Label Txt verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(LabelTxt.getText(), optVal);
    }

    public void verifyLbl(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(LblTxt.isDisplayed());
            System.out.println("Label Txt verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(LblTxt.getText(), optVal);
    }

    public void verifyTxt(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(NatIDTxt.isDisplayed());
            System.out.println("Label Txt verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(NatIDTxt.getText(), optVal);
    }

    public void verifyErr(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(IdErr.isDisplayed());
            System.out.println("Label Txt verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(IdErr.getText().trim(), optVal);
    }

    public void enterIqama() {

        EnterIqama.clear();
        EnterIqama.sendKeys("345678912");
    }

    public void enterIqamaNonNum() {
        EnterIqama.clear();
        EnterIqama.sendKeys("abcdef");
    }

    public void clickBack(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(BackBtn.isDisplayed());
            System.out.println("Back Button display verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        BackBtn.isEnabled();
        Assert.assertEquals(BackBtn.getText(), optVal);
        BackBtn.click();
    }

    public void verifyFirstWalkthroughScreen() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FirstWalkThru.isDisplayed());
            System.out.println("First walk Through Screen displayed verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyTermsScreen() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(TermsCond.isDisplayed());
            System.out.println("Terms and Conditons screen displayed verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifySecondWalkthroughScreen() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SecondWalkThru.isDisplayed());
            System.out.println("Second Walk Through screen displayed verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyImg() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ImgView.isDisplayed());
            System.out.println("Image present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void verifyHeading(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SecondWalkThru.isDisplayed());
            System.out.println("Second Walk Thru present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(SecondWalkThru.getText(), optVal);
    }

    public void verifySubText(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SubText.isDisplayed());
            System.out.println("Sub Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(SubText.getText(), optVal);
    }

    public void verifyFirstPoint(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FirstPoint.isDisplayed());
            System.out.println("First Point present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(FirstPoint.getText(), optVal);
    }

    public void verifyFirstPointSubText(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FirstPointSubTxt.isDisplayed());
            System.out.println("First Point Sub Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(FirstPointSubTxt.getText(), optVal);
    }

    public void verifyScndPoint(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ScndPoint.isDisplayed());
            System.out.println("First Point Sub Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(ScndPoint.getText(), optVal);
    }

    public void verifyThrdPoint(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ThirdPoint.isDisplayed());
            System.out.println("Third Point Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(ThirdPoint.getText(), optVal);

    }

    public void verifyFifthPoint(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FifthPoint.isDisplayed());
            System.out.println("Fifth Point Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(FifthPoint.getText(), optVal);
    }

    public void verifyForthPoint(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ForthPoint.isDisplayed());
            System.out.println("Forth Point Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(ForthPoint.getText(), optVal);
    }

    public void verifyBackBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(BackBtn.isDisplayed());
            System.out.println("Back Btn present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(BackBtn.getText(), optVal);
    }

    public void verifyNextBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(NextBtn.isDisplayed());
            System.out.println("Next Btn present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(NextBtn.getText(), optVal);
    }

    public void clickSkipBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SkipBtn.isDisplayed());
            System.out.println("Open new Acc button verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        SkipBtn.isEnabled();
        Assert.assertEquals(SkipBtn.getText(), optVal);
        SkipBtn.click();
    }

    public void verifyHeadingFrstWalkThrough(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FirstWalkThru.isDisplayed());
            System.out.println("Heading displayed verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(FirstWalkThru.getText(), optVal);
    }

    public void verifySubTextFirstWlkThru(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SubTxt.isDisplayed());
            System.out.println("Sub Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(SubTxt.getText(), optVal);
    }

    public void verifyFirstPointFrstWlkThru(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FrstPoint.isDisplayed());
            System.out.println("First point Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(FrstPoint.getText(), optVal);
    }

    public void verifyFrstPointSubTxt(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FrstPointFrstSubTxt.isDisplayed());
            System.out.println("Sub Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(FrstPointFrstSubTxt.getText(), optVal);
    }

    public void verifySecondPoint(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(SecondPointTxt.isDisplayed());
            System.out.println("Second Point Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(SecondPointTxt.getText(), optVal);
    }

    public void verifyScndPointSubTxt(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(SecondPointSubTxt.isDisplayed());
            System.out.println("Second Point Sub Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(SecondPointSubTxt.getText(), optVal);
    }

    public void verifyThirdPoint(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ThirdPointTxt.isDisplayed());
            System.out.println("Third Point Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(ThirdPointTxt.getText(), optVal);
    }

    public void verifyThirdPointSubTxt(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(ThirdPointSubTxt.isDisplayed());
            System.out.println("Third Point Sub Text present verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(ThirdPointSubTxt.getText(), optVal);
    }

    public void verifyGetStartBtn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(NextBtn.isDisplayed());
            System.out.println("Get Started display verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        NextBtn.isEnabled();
        Assert.assertEquals(NextBtn.getText(), optVal);
    }

    public void verifyHdingTC(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(TermsCond.isDisplayed());
            System.out.println("Terms and Conditons screen displayed verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(TermsCond.getText(), optVal);
    }

    public void verifySubHding(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SubHding.isDisplayed());
            System.out.println("Sub Heading displayed verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(SubHding.getText(), optVal);
    }

    public void verifyTandCtext(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TnCText.isDisplayed());
            System.out.println("Sub Heading displayed verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertEquals(TnCText.getText(), optVal);
    }

    public void verifyNonNumTxtField() {

        if (EnterIqama.getText().isEmpty()) {
            System.out.println("Iqama text bar only accepts numeric values");
        } else {
            System.out.println("Iqama text bar accepts numeric values");
        }

        Assert.assertTrue(EnterIqama.getText().isEmpty());

    }

    public void verifyTxTgreterThnTen() {

        EnterIqama.clear();
        EnterIqama.sendKeys("345678912014");

        Assert.assertEquals(EnterIqama.getText().length(), 10);
    }

    public void verifyTxtArea() {

        Assert.assertEquals(EnterIqama.getText().length(), 10);
    }
}
