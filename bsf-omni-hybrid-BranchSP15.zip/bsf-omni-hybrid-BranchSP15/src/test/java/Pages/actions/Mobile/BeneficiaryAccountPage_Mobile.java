package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.PropertiesOperations;
import Utils.*;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class BeneficiaryAccountPage_Mobile {
    GenericMethod genericMethod = new GenericMethod();
    public AppiumDriver driver;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@label='Beneficiaries']")
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Beneficiaries']")
    public WebElement beneficiaryButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeNavigationBar//XCUIElementTypeStaticText[@name=\"Beneficiaries\"]")
    @AndroidFindBy(xpath = "//android.widget.FrameLayout[contains(@content-desc,'Beneficiaries')]")
    public WebElement beneficiaryScreen;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name='No Beneficiary Yet')]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryPreview_nameView")
    public List<WebElement> beneficiaryNameList;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryList_endOfListMessageView")
    public WebElement endOfListBeneficiaryMessage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@value='No Beneficiary Yet']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'No Beneficiary Yet')]")
    public WebElement noBeneficiaryYetTextView;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@value,'Would you like to add your first beneficiary']")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Would you like to add your first beneficiary.')]")
    public WebElement addFirstBeneficiaryTextView;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='contactListCell.nameLabelID']")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryPreview_nameView")
    public List<WebElement> beneficiaryAccountName;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id,'beneficiaryPreview_nameView')]//..//android.widget.ImageView")
    public List<WebElement> beneficiaryIconList;
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryPreview_statusView")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='contactListCell.accountNumberLabelID']//following-sibling::XCUIElementTypeStaticText[contains(@label,'Inactive')]")
    public List<WebElement> beneficiaryAccountStatus;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='contactListCell.accountNumberLabelID']")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryPreview_accountNumberView")
    public List<WebElement> beneficiaryAccountNumber;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='contactListCell.accountNumberLabelID']//following-sibling::XCUIElementTypeStaticText[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryPreview_bankView")
    public List<WebElement> beneficiaryAccountBankDetail;

    @iOSXCUITFindBy(accessibility = "Search")
    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc='Search']")
    public WebElement searchIcon;

    @iOSXCUITFindBy(accessibility = "Loading failed")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Oops, Loading Failed')]")
    public WebElement alertMessage;

    @iOSXCUITFindBy(accessibility = "An unknown error occurred. Please try again")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Something went wrong. Please try again')]")
    public WebElement errorMessage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Please try again\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Try again')]")
    public WebElement tryAgainButton;

    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Add a beneficiary')]")
    public WebElement createBeneficiaryScreen;
    @AndroidFindBy(accessibility = "Add Contact")

    @iOSXCUITFindBy(accessibility = "contactList.addContact")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/menu_add_beneficiary")
    public WebElement newBeneficiaryIcon;

    @iOSXCUITFindBy(accessibility = "arrow")
    @AndroidFindBy(xpath = "//android.widget.LinearLayout[contains(@resource-id,'beneficiaryFormScreenTypeSelect')]//android.widget.Spinner")
    public WebElement selectType;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypePickerWheel")
    public WebElement elementPicker;

    @iOSXCUITFindBy(accessibility = "Done")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@text,'Local')]")
    public WebElement selectLocal;

    @iOSXCUITFindBy(className = "XCUIElementTypeSwitch")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryLocalSwitch")
    public WebElement beneficiaryLocalToggle;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[2]")
    @AndroidFindBy(xpath = "(//android.widget.EditText[contains(@resource-id,'beneficiaryFormScreenAccountField')]|//android.widget.EditText[contains(@resource-id,'beneficiaryFormScreenAccountIbanLabelField')])[1]")
    public WebElement createBeneficiaryAccountNumberTextView;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[3]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormScreenNameField")
    public WebElement createBeneficiaryAccountNameTextView;

    @iOSXCUITFindBy(accessibility = "Please enter a valid IBAN or Account number")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement createBeneficiaryErrorMessage;

    @iOSXCUITFindBy(accessibility = "Please enter a valid IBAN")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement createBeneficiaryErrorMessage2;

    @iOSXCUITFindBy(accessibility = "Please provide a valid full name")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textinput_error")
    public WebElement createBeneficiaryErrorMessage3;
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[translate(@value,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='CONTINUE']")
    @AndroidFindBy(xpath = "//android.widget.Button[translate(@text,'abcdefghijklmnopqrstuvwxyz','ABCDEFGHIJKLMNOPQRSTUVWXYZ')='CONTINUE']")
    public WebElement continueButton;

    @iOSXCUITFindBy(accessibility = "confirmButtonID")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormScreen_submitButton")
    public WebElement confirmButton;

    @iOSXCUITFindBy(accessibility = "ic delete")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/menu_delete")
    public WebElement deleteIcon;
    @iOSXCUITFindBy(accessibility = "Delete")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'DELETE')]")
    public WebElement deleteButton;
    @iOSXCUITFindBy(accessibility = "Cancel")
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'CANCEL')]")
    public WebElement cancelButton;
    @AndroidFindBy(xpath = "//android.widget.Button[contains(@text,'CLOSE')]")
    public WebElement closeButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name='Beneficiaries']|//XCUIElementTypeButton[@name='close']|//XCUIElementTypeButton[@name=\"Payments\"]")
    @AndroidFindBy(accessibility = "Navigate up")
    public WebElement navigationUP;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Are you sure you want to permanently delete this conversation?']|//XCUIElementTypeStaticText[@name='Do you want to delete this beneficiary?']|//XCUIElementTypeStaticText[@name='No beneficiary yet']")
    @AndroidFindBy(id = "android:id/message")
    public WebElement beneficiaryMessage;
    @AndroidFindBy(id = "com.bsf.retail.uat:id/activateButton")
    public WebElement activateButton;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"Done\"]")
    @AndroidFindBy(xpath = "//android.widget.Button[@text='DONE']")
    public WebElement doneButton;

    @iOSXCUITFindBy(accessibility = "Done")
    public WebElement donePicker;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@label='Add a beneficiary']|//XCUIElementTypeStaticText[@label='Review beneficiary']")
    @AndroidFindBy(xpath = "//android.view.ViewGroup[contains(@resource-id,'beneficiaryFormScreen_toolbar')]//android.widget.TextView")
    public WebElement beneficiaryToolbar;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Beneficiary Test\"])[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryDetailsScreen_title")
    public WebElement beneficiaryDetailsTitle;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormScreenTypeField")
    public WebElement beneficiaryType;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[2]")
    public WebElement accountNumber;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Beneficiary type\"]/..//following-sibling::*//XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryDetailsScreen_identifierValue")
    public WebElement beneficiaryDetailType;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[3]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormScreenBankField")
    public WebElement beneficiaryBank;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Bank\"]/..//following-sibling::*//XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryDetailsScreen_identifierValue")
    public WebElement beneficiaryDetailBank;
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeTextField)[4]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormScreenFullNameField")
    public WebElement beneficiaryFullName;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"Full name\"]/..//following-sibling::*//XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryDetailsScreen_identifierValue")
    public WebElement beneficiaryDetailFullName;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@name=\"IBAN\"]/..//following-sibling::*//XCUIElementTypeStaticText)[1]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryDetailsScreen_identifierValue")
    public WebElement beneficiaryDetailAccountNumber;
    @iOSXCUITFindBy(accessibility = "ivr.complete.titleLabel")
    public WebElement sorryScreen;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Service unavailable\"]")
    public WebElement serviceUnavailble;

    @iOSXCUITFindBy(accessibility = "forgot.credential.ivr.placeholder")
    public WebElement inProgress;

    @iOSXCUITFindBy(accessibility = "ivr.complete.doneButton")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/authenticatorIvrActionButton")
    public WebElement startButton;


    // International Beneficiary Element
    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"arrow\"])[2]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/etSelectCountry")
    public WebElement countryOfResidence;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeButton[@name=\"arrow\"]")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/etSelectCountry")
    public WebElement countryOfResidence2;

    @iOSXCUITFindBy(xpath = " //XCUIElementTypeStaticText[@name=\"Address\"]//following-sibling::*//XCUIElementTypeTextField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/beneficiaryFormScreenAddressLabelField")
    public WebElement enterAddress;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable//XCUIElementTypeStaticText")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/countryName")
    public WebElement selectCountry;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeButton[@name=\"arrow\"])[2]")
    @AndroidFindBy(xpath = "//android.widget.EditText[contains(@resource-id,'etSelectBank')]|//android.widget.EditText[contains(@resource-id,'etSelectCountry')]")
    public WebElement bankDropDown;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeCell//XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "//android.widget.TextView[contains(@resource-id,'countryName')][1]")
    public WebElement selectBank;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/authenticatorIvrCancelButton")
    public WebElement cancelBtn;
    WebDriverWait wait;

    public BeneficiaryAccountPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }

    public void clickOnBeneficiaryButton() {
        Assert.assertTrue(beneficiaryButton.isDisplayed());
        beneficiaryButton.click();
    }

    public void clickOnSearchButton() throws InterruptedException {
        try {
            Thread.sleep(30000);
            wait.until(ExpectedConditions.visibilityOf(searchIcon));
            searchIcon.click();
        } catch (Exception e) {
            System.out.println("Exception Thrown");
            Thread.sleep(1000);
            searchIcon.click();
        }
    }

    public void verifyTextIsDisplayed(String text) throws InterruptedException {
        if (RunnerInfo.getDeviceType().contains("android")) {
            String locator = "//android.widget.TextView[starts-with(@text,'" + text.trim() + "')]";
            Assert.assertTrue(driver.findElement(By.xpath(locator)).isDisplayed());
        }
        else {
            String locator = "//XCUIElementTypeSearchField[starts-with(@value,'" + text.trim() + "')]";
            Assert.assertTrue(driver.findElement(By.xpath(locator)).isDisplayed());
        }
    }

    public void VerifyInlineErrorMessage(String message, String field) {
        //wait.until(ExpectedConditions.visibilityOf(OtherPurposeLabel));
        String actualValue = driver.findElement(By.xpath("//*[@text='" + field + "']//..//*[contains(@resource-id,'textinput_error')]")).getText();
        System.out.println(actualValue);
        junit.framework.Assert.assertEquals(message, actualValue);
    }


    public void verifyBeneficiaryExist() {
        if (genericMethod.isElementPresent(noBeneficiaryYetTextView)) {
            Assert.assertTrue(noBeneficiaryYetTextView.isDisplayed());
            Assert.assertTrue(addFirstBeneficiaryTextView.isDisplayed());
        }
    }

    public void verifyBeneficiaryScreen() {
        Assert.assertTrue(beneficiaryScreen.isDisplayed(), "Beneficiary screen is not displayed");
    }

    public void verifyBeneficiaryNameList() {
        for (WebElement name : beneficiaryNameList) {
            Assert.assertTrue(name.isDisplayed(), "Beneficiary name list is not displayed");
        }
    }

    public void verifyEndOfListBeneficiaryMessage(String message) {
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        HashMap<String, String> scrollObject = new HashMap<String, String>();
//        scrollObject.put("direction", "down");
//        js.executeScript("mobile: scroll", scrollObject);


//        while (true) {
//            if (genericMethod.isElementPresent(endOfListBeneficiaryMessage)) {
//                System.out.println("Beneficiary account end list message : " + endOfListBeneficiaryMessage.getText());
//                Assert.assertEquals(endOfListBeneficiaryMessage.isDisplayed(), message, "Beneficiary end of list message : " + endOfListBeneficiaryMessage.getText() + "is not displayed");
//
//
//            } else {
        genericMethod.mobileScrollTillEndOfPage(driver, endOfListBeneficiaryMessage);

//            }
//        }
    }

    public void verifyAccountFirstName(String filename, String accountName) {
        ArrayList<String> listAccountName = new ArrayList<>();
        for (WebElement element : beneficiaryAccountName) {
            Assert.assertTrue(element.isEnabled());

            listAccountName.add(element.getText().trim());
        }
        Assert.assertTrue(listAccountName.contains(PropertiesOperations.getPropertyValueByKey(filename, accountName).trim()), "Failed to verify " + accountName + " exist in beneficiary");
    }
    public void verifyAccountFirstNameExist() {
        if (genericMethod.isElementPresent(beneficiaryAccountName.get(0))) {
            Assert.assertTrue(beneficiaryAccountName.get(0).isDisplayed());
        }
    }

    public void verifyAccountNameList() {
        for (WebElement element : beneficiaryAccountName) {
            Assert.assertTrue(element.isEnabled(), "Failed to verify th account name is displayed");
        }
    }

    public void verifyAccountIconList() {
        for (WebElement element : beneficiaryIconList) {
            Assert.assertTrue(element.isEnabled(), "Failed to verify th account icon is displayed");
        }
    }
    public void verifyAccountIconListExist() {
        Assert.assertTrue(beneficiaryIconList.get(0).isDisplayed());
    }

    public void verifyAccountNumberList() {
        System.out.println("Size: "+beneficiaryAccountNumber.size());
        for (WebElement element : beneficiaryAccountNumber) {
            Assert.assertTrue(element.isEnabled(), "Failed to verify th account number is displayed");
        }
    }
    public void verifyAccountStatusList() {
        for (WebElement element : beneficiaryAccountStatus) {
            Assert.assertTrue(element.isEnabled(), "Failed to verify th account status is displayed");
        }
    }

    public void clickOnAccountFirstName() {

        Assert.assertTrue(beneficiaryAccountName.get(0).isDisplayed());
        beneficiaryAccountName.get(0).click();
    }

    public void verifyAccountFirstNumber(String filename, String accountNumber) {
        ArrayList<String> listAccountNumber = new ArrayList<>();
        for (WebElement element : beneficiaryAccountNumber) {
            Assert.assertTrue(element.isEnabled());
            listAccountNumber.add(element.getText().trim());
        }
        Assert.assertTrue(listAccountNumber.contains(PropertiesOperations.getPropertyValueByKey(filename, accountNumber).trim()), "Failed to verify expected account name " + PropertiesOperations.getPropertyValueByKey(filename, accountNumber).trim() + " but actual account name list " + listAccountNumber + "exist in beneficiary");
    }
    public void verifyAccountNameListExist() {
        if (genericMethod.isElementPresent(beneficiaryAccountNumber.get(0))) {
            Assert.assertTrue(beneficiaryAccountNumber.get(0).isDisplayed());
        }
    }

    public void verifyAccountFirstBankDetail(String filename, String accountBankDetail) {
        ArrayList<String> listAccountBankDetail = new ArrayList<>();
        for (WebElement element : beneficiaryAccountBankDetail) {
            Assert.assertTrue(element.isEnabled());
            listAccountBankDetail.add(element.getText().trim());
        }
        Assert.assertTrue(listAccountBankDetail.contains(PropertiesOperations.getPropertyValueByKey(filename, accountBankDetail).trim()), "Failed to verify " + accountBankDetail + " exist in beneficiary");
    }
    public void verifyAccountBankDetailListExist() {
        if (genericMethod.isElementPresent(beneficiaryAccountBankDetail.get(0))) {
            Assert.assertTrue(beneficiaryAccountBankDetail.get(0).isDisplayed());
        }
    }

    public void verifyAccountStatus(String filename, String accountStatus) {
        for (WebElement element : beneficiaryAccountStatus) {
            Assert.assertTrue(element.isEnabled());
            Assert.assertEquals(element.getText().trim(), PropertiesOperations.getPropertyValueByKey(filename, accountStatus).trim(), "Failed to verify " + accountStatus + " status in beneficiary");

        }
    }
    public void verifyAccountStatusExist() {
        if (genericMethod.isElementPresent(beneficiaryAccountStatus.get(0))) {
            Assert.assertTrue(beneficiaryAccountStatus.get(0).isDisplayed());
        }
    }

    public void verifyAlertIsDisplayedOrNot() {
        if (genericMethod.isElementPresent(alertMessage)) {
            Assert.assertTrue(alertMessage.isDisplayed());
            Assert.assertTrue(errorMessage.isDisplayed());
            Assert.assertTrue(tryAgainButton.isDisplayed());
            tryAgainButton.click();

        }
    }

    public void clickOnNewBeneficiaryIcon() {
        Assert.assertTrue(newBeneficiaryIcon.isDisplayed());
        newBeneficiaryIcon.click();
    }

    public void selectLocalType() throws InterruptedException {
        Thread.sleep(1000);
        if (genericMethod.isElementPresent(selectType)) {
            selectType.click();
            Thread.sleep(1000);
            selectLocal.click();
        }

    }

    public void selectBeneficiaryType(String beneficiaryType) throws InterruptedException {
        Thread.sleep(1000);
        if (genericMethod.isElementPresent(selectType)) {
            selectType.click();
            Thread.sleep(1000);
            if (RunnerInfo.getDeviceType().contains("android"))
                driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'" + beneficiaryType + "')]")).click();
            else {
                genericMethod.setPicker(driver, elementPicker, beneficiaryType, donePicker);
            }
        }


    }

    public void onToggle() {
        beneficiaryLocalToggle.click();
    }

    public void enterCreateBeneficiaryAccountNumber(String filename, String accountNumber) {
        if (RunnerInfo.getDeviceType().contains("android")) {
            Assert.assertTrue(createBeneficiaryAccountNumberTextView.isDisplayed());
            createBeneficiaryAccountNumberTextView.sendKeys(PropertiesOperations.getPropertyValueByKey(filename, accountNumber).trim());

        }
        else {
            Assert.assertTrue(createBeneficiaryAccountNumberTextView.isDisplayed());
            createBeneficiaryAccountNumberTextView.clear();
            createBeneficiaryAccountNumberTextView.sendKeys("SA" + PropertiesOperations.getPropertyValueByKey(filename, accountNumber).trim());
        }
        }

    public void enterCreateBeneficiaryAccountName(String filename, String accountName) {
        Assert.assertTrue(createBeneficiaryAccountNameTextView.isDisplayed());
        createBeneficiaryAccountNameTextView.sendKeys(PropertiesOperations.getPropertyValueByKey(filename, accountName).trim());
    }

    public void verifyCreateBeneficiaryErrorMessage() {
        Assert.assertTrue(createBeneficiaryErrorMessage.isDisplayed(), "Failed to verify create Beneficiary error message is not displayed");
    }

    public void verifyCreateBeneficiaryErrorMessages() {
        Assert.assertTrue(createBeneficiaryErrorMessage2.isDisplayed() || createBeneficiaryErrorMessage3.isDisplayed(), "Failed to verify create Beneficiary error message is not displayed");
    }

    public void verifyCreateBeneficiaryNameErrorMessages() {
        Assert.assertTrue(createBeneficiaryErrorMessage3.isDisplayed(), "Failed to verify create Beneficiary error message is not displayed");
    }

    public void clickOnContinueButton() {
        Assert.assertTrue(continueButton.isDisplayed());
        continueButton.click();
    }

    public void clickOnConfirmButton() {
        Assert.assertTrue(confirmButton.isDisplayed());
        confirmButton.click();
    }

    public void deleteBeneficiaryIfExist(String filename, String beneficiaryAccountNameValue) {
        for (WebElement element : beneficiaryAccountName) {
            String fileValue = PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue).toLowerCase().trim();
            String elementValue = element.getText().toLowerCase().trim();
            System.out.println("Element: " + elementValue);
            System.out.println("File Value: " + fileValue);
            if (elementValue.toCharArray()[0] == fileValue.toCharArray()[0]) {
                System.out.println("Same Character Found: " + elementValue.toCharArray()[0]);
                if (elementValue.equals(fileValue)) {
                    System.out.println("Same Value Found: " + elementValue);
                    if (RunnerInfo.getDeviceType().contains("android")) element.click();
                    else {
                        element.click();
                        driver.findElement(By.xpath("//XCUIElementTypeStaticText[@label='" + PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue) + "']")).click();
                    }
                    deleteIcon.click();
                    deleteButton.click();
                    if (RunnerInfo.getDeviceType().contains("android")) navigationUP.click();
                    break;
                }
            } else if (elementValue.toCharArray()[0] > fileValue.toCharArray()[0]) {
                return;
            }
        }
    }

    public void checkAndCreateBeneficiary(String filename, String beneficiaryAccountNameValue,String beneficiaryAccountNumberValue,LoginPage_Mobile loginPage_mobile) {
        for (WebElement element : beneficiaryAccountName) {
            String fileValue = PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue).toLowerCase().trim();
            String accountNumberValue = PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNumberValue).trim();
            String elementValue = element.getText().toLowerCase().trim();
            System.out.println("Element: " + elementValue);
            System.out.println("File Value: " + fileValue);
            if (elementValue.toCharArray()[0] == fileValue.toCharArray()[0]) {
                System.out.println("Same Character Found: " + elementValue.toCharArray()[0]);
                if (elementValue.equals(fileValue)) {
                    System.out.println("Same Value Found: " + elementValue);
                    return;
                }
            } else if (elementValue.toCharArray()[0] > fileValue.toCharArray()[0]) {
                System.out.println("No Value Found, Creating New Bene");
                try {
                    this.clickOnNewBeneficiaryIcon();
                    Thread.sleep(3000);
                    this.verifyBeneficiaryToolbar("Add a beneficiary");
                    Thread.sleep(1000);
                    this.enterCreateBeneficiaryAccountNumber(filename, beneficiaryAccountNumberValue);
                    Thread.sleep(1000);
                    this.enterCreateBeneficiaryAccountName(filename, beneficiaryAccountNameValue);
                    Thread.sleep(1000);
                    this.clickOnContinueButton();
                    Thread.sleep(3000);
                    this.clickOnConfirmButton();
                    Thread.sleep(3000);
                    this.clickStartButton();
                    Thread.sleep(3000);
                    this.verifyAlert("Service unavailable");
                    Thread.sleep(3000);
                    this.clickOnDoneButton();
                    loginPage_mobile.logBackInToBeneficiary();
                    System.out.println("New Bene Created");
                }catch (Exception e) {throw new RuntimeException(e);}
                return;
            }
        }
    }

    public void selectBeneficiary(String filename, String beneficiaryAccountNameValue) {
        for (WebElement element : beneficiaryAccountName) {
            String fileValue = PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue).toLowerCase().trim();
            String elementValue = element.getText().toLowerCase().trim();
            System.out.println("Element: " + elementValue);
            System.out.println("File Value: " + fileValue);
            if (elementValue.toCharArray()[0] == fileValue.toCharArray()[0]) {
                System.out.println("Same Character Found: " + elementValue.toCharArray()[0]);
                if (elementValue.equals(fileValue)) {
                    System.out.println("Same Value Found: " + elementValue);
                    if (RunnerInfo.getDeviceType().contains("android")) {
                        genericMethod.mobileScrollTillEndOfPage(driver, element);
                        element.click();
                    }
                    else {
                        System.out.println("iOS");
                        System.out.println("Element Found");
                        element.click();
                        System.out.println("Element Clicked");
                        try{
                            element = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='contactListCell.nameLabelID' and @value='"+PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue)+"']"));
                            while (element.isDisplayed()){
                                element.click();
                            }
                        }catch (Exception e){
                            System.out.println("Element no longer found or displayed");
                        }
                    }
                    break;
                }
            } else if (elementValue.toCharArray()[0] > fileValue.toCharArray()[0]) {
                return;
            }
        }
    }

    public void verifyBeneficiary(String filename, String beneficiaryAccountNameValue) {
        boolean exist = false;
        for (WebElement element : beneficiaryAccountName) {
            if (element.getText().toLowerCase().toCharArray()[0] > PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue).toLowerCase().toCharArray()[0]) {
                return;
            }
            Assert.assertTrue(element.isEnabled());
            if (element.getText().toLowerCase().trim().equals(PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue).toLowerCase().trim())) {
                exist = true;
            }
        }
        if (!exist)
            Assert.fail("Beneficiary name: " + PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue) + " not exist");
    }

    public void verifyBeneficiaryNotExist(String filename, String beneficiaryAccountNameValue) {
        boolean exist = false;
        for (WebElement element : beneficiaryAccountName) {
            String elementValue = element.getText().trim().toLowerCase();
            String fileValue = PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue).trim().toLowerCase();
            System.out.println("Element: " + elementValue);
            System.out.println("File Value: " + fileValue);
            Assert.assertTrue(element.isEnabled());
            if (elementValue.equals(fileValue)) {
                exist = true;
            }
            if (elementValue.toCharArray()[0] > fileValue.toCharArray()[0]) {
                return;
            }
        }
        if (exist)
            Assert.fail("Beneficiary name: " + PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue) + " exists");
    }

    public void clickOnDeleteIcon() {
        Assert.assertTrue(deleteIcon.isDisplayed());
        deleteIcon.click();
    }

    public void clickOnDeleteButton() {
        Assert.assertTrue(deleteButton.isDisplayed());
        deleteButton.click();
    }

    public void clickOnCancelButton() {
        Assert.assertTrue(cancelButton.isDisplayed());
        cancelButton.click();
    }

    public void clickOnDoneButton() {

        if (RunnerInfo.getDeviceType().contains("android")) {
            try {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
                wait.until(ExpectedConditions.visibilityOf(cancelBtn));
                cancelBtn.click();
            } catch (Exception e) {
                System.out.println("Exception Thrown cancel not found");

            }

        }
        else
        {
            Assert.assertTrue(doneButton.isDisplayed());
            doneButton.click();
        }


    }

    public void clickOnCloseButton() {
        Assert.assertTrue(closeButton.isDisplayed());
        closeButton.click();
    }

    public void clickOnNavigationButton() {
        Assert.assertTrue(navigationUP.isDisplayed());
        navigationUP.click();
        try {
            Thread.sleep(5000);
        } catch (Exception e) {

        }
    }

    public void verifyMessage(String message) {
        Assert.assertTrue(beneficiaryMessage.isDisplayed());
        Assert.assertEquals(beneficiaryMessage.getText().trim(), message.trim(), "Failed to verify " + message);
    }

    public void verifyMessageExist(String message) {
        if (genericMethod.isElementPresent(beneficiaryMessage)) {
            Assert.assertEquals(beneficiaryMessage.getText().trim(), message.trim(), "Failed to verify " + message);
        }
    }

    public void clickBeneficiaryStatus(String filename, String beneficiaryAccountNameValue) {
        WebElement element = null;
        String name = PropertiesOperations.getPropertyValueByKey(filename, beneficiaryAccountNameValue);
        if (RunnerInfo.getDeviceType().contains("android")) {
            element = driver.findElement(By.xpath("//android.widget.TextView[contains(@text,'" + name + "')]//following-sibling::android.widget.TextView[contains(@resource-id,'beneficiaryPreview_statusView')]"));
            element.click();

        } else {
            element = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@value=" + name + "]"));
            element.click();
        }
    }

    public void verifyBeneficiaryToolbar(String text) {
        Assert.assertTrue(beneficiaryToolbar.isDisplayed());
        Assert.assertEquals(beneficiaryToolbar.getText().trim(), text, "Failed to verify " + text + " is displayed");
    }

    public void verifyBeneficiaryDetailTitle(String filename, String accountName) {

        Assert.assertTrue(beneficiaryDetailsTitle.isDisplayed());
        Assert.assertEquals(beneficiaryDetailsTitle.getText().trim().toLowerCase(), PropertiesOperations.getPropertyValueByKey(filename, accountName).toLowerCase(), "Failed to verify " + accountName + " is displayed");
    }

    public void verifyBeneficiaryReviewAccountNumber(String filename, String accountNumber) {
        if (RunnerInfo.getDeviceType().contains("android")) {
            Assert.assertTrue(createBeneficiaryAccountNumberTextView.isDisplayed());
            String number = "SA" + PropertiesOperations.getPropertyValueByKey(filename, accountNumber).trim();
            Assert.assertEquals(createBeneficiaryAccountNumberTextView.getText().trim(), number, "Failed to verify " + number + " account beneficiary detail");
        } else {
            Assert.assertTrue(this.accountNumber.isDisplayed());
            String number = "SA" + PropertiesOperations.getPropertyValueByKey(filename, accountNumber).trim();
            Assert.assertEquals(this.accountNumber.getText().trim(), number, "Failed to verify " + number + " account beneficiary detail");

        }
    }

    public void verifyBeneficiaryDetailAccountNumber(String filename, String accountNumber) {
        Assert.assertTrue(beneficiaryDetailAccountNumber.isDisplayed());
        String number = "SA" + PropertiesOperations.getPropertyValueByKey(filename, accountNumber).trim();
        Assert.assertEquals(beneficiaryDetailAccountNumber.getText().trim(), number, "Failed to verify " + number + " account beneficiary detail");
    }

    public void verifyBeneficiaryReviewAccountName(String filename, String accountName) {
        Assert.assertTrue(beneficiaryFullName.isDisplayed());
        String value = PropertiesOperations.getPropertyValueByKey(filename, accountName).trim();
        Assert.assertEquals(beneficiaryFullName.getText().trim(), value, "Failed to verify " + value + " account beneficiary detail");
    }

    public void verifyBeneficiaryDetailAccountName(String filename, String accountName) {
        Assert.assertTrue(beneficiaryDetailFullName.isDisplayed());
        String value = PropertiesOperations.getPropertyValueByKey(filename, accountName).trim();
        Assert.assertEquals(beneficiaryDetailFullName.getText().trim(), value, "Failed to verify " + value + " account beneficiary detail");
    }

    public void verifyBeneficiaryReviewAccountBankName(String filename, String accountBankName) {
        Assert.assertTrue(beneficiaryBank.isDisplayed());
        String value = PropertiesOperations.getPropertyValueByKey(filename, accountBankName).trim();
        Assert.assertEquals(beneficiaryBank.getText().trim(), value, "Failed to verify " + value + " account beneficiary detail");
    }

    public void verifyBeneficiaryDetailAccountBankName(String filename, String accountBankName) {
        Assert.assertTrue(beneficiaryDetailBank.isDisplayed());
        String value = PropertiesOperations.getPropertyValueByKey(filename, accountBankName).trim();
        Assert.assertEquals(beneficiaryDetailBank.getText().trim(), value, "Failed to verify " + value + " account beneficiary detail");
    }

    public void verifyBeneficiaryReviewType(String filename, String accountType) {
        Assert.assertTrue(beneficiaryType.isDisplayed());
        String value = PropertiesOperations.getPropertyValueByKey(filename, accountType).trim();
        Assert.assertEquals(beneficiaryType.getText().trim(), value, "Failed to verify " + value + " account beneficiary detail");
    }

    public void verifyBeneficiaryDetailType(String filename, String accountType) {
        Assert.assertTrue(beneficiaryDetailType.isDisplayed());
        String value = PropertiesOperations.getPropertyValueByKey(filename, accountType).trim();
        Assert.assertEquals(beneficiaryDetailType.getText().trim(), value, "Failed to verify " + value + " account beneficiary detail");
    }

    public void verifyBeneficiaryReviewScreen(String filename, String value) {
        switch (value.toLowerCase()) {
            case "AccountType" -> {
                verifyBeneficiaryReviewType(filename, value);
            }
            case "AccountNumber" -> {
                verifyBeneficiaryReviewAccountNumber(filename, value);
            }
            case "BankDetail" -> {
                verifyBeneficiaryReviewAccountBankName(filename, value);
            }
            case "AccountName" -> {
                verifyBeneficiaryReviewAccountName(filename, value);
            }
        }
    }

    public void verifyBeneficiaryDetailScreen(String filename, String value) {
        switch (value.toLowerCase()) {
            case "AccountType" -> {
                verifyBeneficiaryDetailType(filename, value);
            }
            case "AccountNumber" -> {
                verifyBeneficiaryDetailAccountNumber(filename, value);
            }
            case "BankDetail" -> {
                verifyBeneficiaryDetailAccountBankName(filename, value);
            }
            case "AccountName" -> {
                verifyBeneficiaryDetailAccountName(filename, value);
            }
        }
    }

    public void verifySorryScreen(String heading) {
        if (!RunnerInfo.getDeviceType().contains("android")) {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
            wait.until(ExpectedConditions.invisibilityOf(inProgress));
            wait.until(ExpectedConditions.visibilityOf(sorryScreen));
            Assert.assertEquals(sorryScreen.getText().trim().toLowerCase(), heading.toLowerCase());
        } else {
            //android code
        }
    }

    public void verifyAlert(String heading) {
        if (!RunnerInfo.getDeviceType().contains("android")) {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
            wait.until(ExpectedConditions.invisibilityOf(inProgress));
            wait.until(ExpectedConditions.visibilityOf(serviceUnavailble));
            Assert.assertEquals(serviceUnavailble.getText().trim().toLowerCase(), heading.toLowerCase());
        } else {
            //android code
        }
    }

    public void clickStartButton() {

        if (!RunnerInfo.getDeviceType().contains("android")) {
            startButton.click();
        }

        if (RunnerInfo.getDeviceType().contains("android")) {
            try {
                WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(100));
                wait.until(ExpectedConditions.visibilityOf(startButton));
                startButton.click();
            } catch (Exception e) {
                System.out.println("Exception Thrown startButton not found");

            }

        }
    }

    public void clickCountryDropDown() {
        countryOfResidence.click();
    }

    public void selectCountry() {
        selectCountry.click();
    }

    public void verifyCountryFlag(String filename, String flag) {
        if (RunnerInfo.getDeviceType().contains("android")) {
            String locator = "//android.widget.TextView[contains(translate('\" + PropertiesOperations.getPropertyValueByKey(filename, flag).trim() + \"', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), translate('\" + PropertiesOperations.getPropertyValueByKey(filename, flag).trim() + \"', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'))]";
            Assert.assertTrue(driver.findElement(By.xpath(locator)).isDisplayed());
        }
    }

    public void enterAddress(String filename, String address) {
        enterAddress.clear();
        enterAddress.sendKeys(PropertiesOperations.getPropertyValueByKey(filename, address).trim());
    }

    public void clickBankDropDown() {
        bankDropDown.click();
    }

    public void selectFirstBank() {
        selectBank.click();
    }
    public void verifyFirstBank() {
        System.out.println("Verify Bank is displayed");
        Assert.assertTrue(genericMethod.isElementPresent(selectBank), "Failed to verify bank list is displayed");
        System.out.println("Verified Bank is displayed");

    }

    public void logBackIn() {
    }

    public void initializer() {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    public void clickCountryDropDowns() {
        countryOfResidence2.click();
    }
}
