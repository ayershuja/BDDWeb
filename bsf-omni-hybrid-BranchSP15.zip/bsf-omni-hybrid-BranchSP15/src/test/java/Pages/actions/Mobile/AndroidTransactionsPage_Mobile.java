package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.JsonHandler;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.openqa.selenium.JavascriptExecutor;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;
import java.util.Calendar;





import java.util.concurrent.TimeUnit;

public class AndroidTransactionsPage_Mobile {

    GenericMethod genericMethod = new GenericMethod();
    public AppiumDriver driver;
    JsonHandler jsonHandler = new JsonHandler();

    @iOSXCUITFindBy(accessibility = "AccountGroupHeaderViewTitle_Current accounts")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsTransactionsJourney_listView_sectionHeader")
    public WebElement CrrntAcc;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[contains(@name,\"Current Account\")])[2]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Sight Deposit\"]")
    public WebElement TransScreen;

    @iOSXCUITFindBy(accessibility = "No transactions yet")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/textViewErrorTitle")
    public WebElement TransMsg;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@label=\"Sight Deposit\"])[2]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text=\"Sight Deposit\"])[2]")
    public WebElement AccFromList;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@label=\"Sight Deposit\"])[1]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Sight Deposit'])[4]")
    public WebElement FirstAccFromList;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeTable[@label='search.results']//XCUIElementTypeStaticText[@value=\"Transfer between my Accounts / Other BSF Accounts\"]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text=\"Transfer between my Accounts / Other BSF Accounts\"])[2]")
    public WebElement FirstTransact;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name=\"Outgoing Transfer / Within BSF\"]")
    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Outgoing Transfer / Within BSF\"]")
    public WebElement TransactDesc;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Incoming Transfer\"]")
    public WebElement IncmngTransactDescp;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[contains(@name,\"TransactionCellAmountLabel\") and contains(@value,'SAR') and not(contains(@value,'-SAR')) and not(@value='SAR 0.00')]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/backbaseRetail_transactionView_amount\" and contains(@text,'SAR +') and not(@text='SAR 0.00')]/..)[1]")
    public WebElement IncomingTrans;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/menu_search")
    @iOSXCUITFindBy(accessibility = "TransactionsViewControllerSearchBarButtonItem")
    public WebElement SearchBtn;

    @iOSXCUITFindBy(accessibility = "TransactionsViewControllerSearchTextField")
    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionsScreen_searchBar")
    public WebElement SearchBar;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_commonFilterScreen_reset")
    @iOSXCUITFindBy(accessibility = "filterResetBarButtonItem")
    public WebElement ResetBtn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionAmountFilterScreen_minAmountTitle")
    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Minimum amount\"")
    public WebElement MinAmnt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionAmountFilterScreen_maxAmountTitle")
    @iOSXCUITFindBy(iOSNsPredicate = "label == \"Maximum amount\"")
    public WebElement MaxAmntLbl;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionAmountFilterScreen_bottomButton")
    @iOSXCUITFindBy(accessibility = "filterViewApplyChangesButton")
    public WebElement ApplyBtn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionBookingDateFilterScreen_fromDateTitle")
    @iOSXCUITFindBy(accessibility = "From")
    public WebElement FromDateField;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionBookingDateFilterScreen_toDateTitle")
    @iOSXCUITFindBy(accessibility = "To")
    public WebElement ToDateField;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionBookingDateFilterScreen_fromDate")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='From']//following-sibling::*//XCUIElementTypeTextField")
    public WebElement FrmDateFild;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionBookingDateFilterScreen_toDate")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='To']//following-sibling::*//XCUIElementTypeTextField")
    public WebElement ToDateFild;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/mtrl_picker_title_text")
    public WebElement DatePicker;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/cancel_button")
    public WebElement CancelBtn;


    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Fri, Sep 1\"]")
    public WebElement FromDate;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/confirm_button")
    public WebElement OkBtn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionBookingDateFilterScreen_bottomButton")
    @iOSXCUITFindBy(accessibility = "filterViewApplyChangesButton")
    public WebElement ApplyBtn_DateScrn;

    @AndroidFindBy(xpath = "//android.widget.TextView[@content-desc=\"Wed, Sep 6\"]")
    public WebElement ToDate;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionCreditDebitFilterScreen_debit_title")
    @iOSXCUITFindBy(accessibility = "Debited transactions")
    public WebElement DebitTrans;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionCreditDebitFilterScreen_debit_subtitle")
    @iOSXCUITFindBy(accessibility = "Only show outgoing transactions")
    public WebElement SubDebitTrans;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionCreditDebitFilterScreen_credit_title")
    @iOSXCUITFindBy(accessibility = "Credited transactions")
    public WebElement CreditTrans;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionCreditDebitFilterScreen_credit_subtitle")
    @iOSXCUITFindBy(accessibility = "Only show incoming transactions")
    public WebElement SubCreditTrans;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountsAndTransactionsJourney_transactionCreditDebitFilterScreen_bottomButton")
    @iOSXCUITFindBy(accessibility = "filterViewApplyChangesButton")
    public WebElement BtnApply;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/textViewEmptyTitle")
    @iOSXCUITFindBy(accessibility = "We could not find any search results ")
    public WebElement EmptyDataLbl;

    @iOSXCUITFindBy(accessibility = "filterCancelBarButtonItem")
    @AndroidFindBy(accessibility = "Close Credit Debit Filter")
    public WebElement CrossIcon;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/icon")
    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"TransactionDetailsViewControllerIconView\"]/XCUIElementTypeOther/XCUIElementTypeImage")
    public WebElement TransId;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"TransactionDetailsViewControllerAmountLabel\"]/XCUIElementTypeStaticText")
    @AndroidFindBy(accessibility = "SAR -3.21")
    public WebElement TransAmnt;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeOther[@name=\"TransactionDetailsViewControllerDateLabel\"]/XCUIElementTypeStaticText")
    @AndroidFindBy(accessibility = "Wednesday, May 31, 2023")
    public WebElement TransDate;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/transactionsJourney_transactionsScreen_headerButton_2_text")
    public WebElement StatmntIcn;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_listScreen_toolbar\"]/android.widget.ImageButton")
    public WebElement BackIcn;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_listScreen_filterMenuButton")
    public WebElement FilterBtn;

    @AndroidFindBy(xpath = "(//android.widget.ImageView[@resource-id=\"com.bsf.retail.uat:id/icon\"])[1]")
    public WebElement ImgIcon;

    @AndroidFindBy(accessibility = "Visa AFKL Signature Conv.")
    public WebElement AccName;

    @AndroidFindBy(accessibility = "•••• •••• •••• 0919")
    public WebElement AccNo;

    @AndroidFindBy(accessibility = "SAR 309729.23")
    public WebElement AccAmnt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_listScreen_recyclerView")
    public WebElement StatmntList;

    @AndroidFindBy(xpath = "(//android.widget.TextView[@text = \"null\"])[1]")
    public WebElement FirstAccStatmnt;

    @AndroidFindBy(xpath = "//android.widget.TextView[@text = \"Nov 19, 2022\"]")
    public WebElement StatmntView;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/pdfImageView")
    public WebElement WholeStatmnt;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/sharePDF")
    public WebElement ShareStatmnt;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@content-desc=\"Credit cards, Visa AFKL Signature Conv., Account ending in ••••••••••••, SAR 309729.23\"]/android.widget.TextView[1]")
    public WebElement CreditCard;

    @AndroidFindBy(accessibility = "Visa AFKL Signature Conv.")
    public WebElement TransactScrnCredit;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_reset")
    public WebElement filterReset;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id = \"com.bsf.retail.uat:id/accountStatementJourney_filterScreen_toolbar\"]/android.widget.ImageButton")
    public WebElement filterCross;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_dateRangeTitle")
    public WebElement DateRang;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_types_title")
    public WebElement StatType;

    @AndroidFindBy(accessibility = "PDF_FULL")
    public WebElement PdfType;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_applyFiltersButton")
    public WebElement ApplyFilterBtn;

    @AndroidFindBy(accessibility = "Navigate up")
    public WebElement CrossIcn;

    @AndroidFindBy(accessibility = "Remove PDF_FULL")
    public WebElement FilterStampCross;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypePickerWheel[3]")
    public WebElement yearPicker;

    @iOSXCUITFindBy(accessibility = "Done")
    public WebElement donePicker;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Statements\"]")
    public WebElement StatementIcon;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"Filter\"]")
    public WebElement FilterIcon;

    @AndroidFindBy(className = "android.widget.ImageButton")
    public WebElement CloseIcon;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_listScreen_toolbar\"]/android.widget.TextView")
    public WebElement AccStatement;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_listScreen_toolbar\"]/android.widget.ImageButton")
    public WebElement BackIcon;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_filterScreen_toolbar\"]/android.widget.TextView")
    public WebElement FilterScreen;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_dateRangeTitle")
    public WebElement DateStatement;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_reset")
    public WebElement ResetFlter;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_types_title")
    public WebElement Type;

//    @AndroidFindBy(id = "com.bsf.retail.uat:id/accountStatementJourney_filterScreen_applyFiltersButton")
//    public WebElement ApplyFilterBtn;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_listScreen_filterChips\"]/android.widget.Button[1]")
    public WebElement FilterChip1;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_listScreen_filterChips\"]/android.widget.Button[2]")
    public WebElement FilterChip2;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/month_navigation_fragment_toggle")
    public WebElement CalendarYearIcon;

    @AndroidFindBy(xpath = "//android.widget.Button[@content-desc=\"null, OK\"]")
    public WebElement CalendarOkBtn;

    @AndroidFindBy(xpath = "//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_listScreen_filterChips\"]/android.widget.Button")
    public WebElement DateRange;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/message")
    public WebElement NoResultVerbiage;

    @AndroidFindBy(id = "com.bsf.retail.uat:id/title")
    public WebElement NoResultVerbiageHeader;

//    @AndroidFindBy(xpath = "//android.widget.Button[@text=\"com.bsf.retail.dev:id/backbaseRetail_transactionView_amount\" and contains(@text,'SAR +') and not(@text='SAR 0.00')]/..")
//    public WebElement SearchFilter;

 //   GenericMethod genericMethod = new GenericMethod();


    public AndroidTransactionsPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void verifyCurrentAcc(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(CrrntAcc.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(CrrntAcc.isEnabled());
        Assert.assertEquals(CrrntAcc.getText(),optVal);
    }

    public void verifyTransactionScreen() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransScreen.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(TransScreen.isEnabled());
    }

    public void verifyNoTransactionsMsg(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransMsg.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(TransMsg.isEnabled());
        Assert.assertEquals(TransMsg.getText(),optVal);
    }

    public void selectAcc() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(AccFromList.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(AccFromList.isEnabled());
        AccFromList.click();
    }

    public void selectFirstAcc(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(FirstAccFromList.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FirstAccFromList.isEnabled());
        FirstAccFromList.click();
    }

    public void selectFirstTransact() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(FirstTransact.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FirstTransact.isEnabled());
        FirstTransact.click();
    }

    public void verifyTransDesc() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransactDesc.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(TransactDesc.isEnabled());
    }

    public void clickIncomingTrans() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(IncomingTrans.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(IncomingTrans.isEnabled());
        IncomingTrans.click();
    }

    public void clickSearchBtn() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SearchBtn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SearchBtn.isEnabled());
        SearchBtn.click();
    }

    public void enterTransDet() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(SearchBar.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SearchBar.isEnabled());
        SearchBar.click();
        SearchBar.sendKeys("tran");
    }

    public void verifyTransactViaSearch() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(FirstTransact.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FirstTransact.isEnabled());
    }

    public void verifyFilterVal(String optVal) {

        WebElement SearchFilter = driver.findElement(By.xpath("//android.widget.Button[@text='"+optVal+"']|//XCUIElementTypeStaticText[contains(@value,'"+optVal+"')]"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SearchFilter.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SearchFilter.isEnabled());
        Assert.assertTrue(SearchFilter.getText().contains(optVal),"Value: "+SearchFilter.getText()+" does  not contain text: "+optVal);

    }

    public void clickFilterOpt(String optVal) {
        WebElement FilterOpt = driver.findElement(By.xpath("//android.widget.Button[@text='"+optVal+"']|//XCUIElementTypeStaticText[contains(@value,'"+optVal+"') and contains(@value,'filter')]"));
        Assert.assertTrue(FilterOpt.isEnabled());
        FilterOpt.click();

    }

    public void verifyAmountRngScreen(String optVal) {

        WebElement AmtRange = driver.findElement(By.xpath("//android.widget.TextView[@text='"+optVal+"']|//XCUIElementTypeStaticText[@name='"+optVal+"']"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(AmtRange.isDisplayed());
            System.out.println("Filter  Screen  verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(AmtRange.isEnabled());
        Assert.assertEquals(AmtRange.getText(),optVal);
    }

    public void verifyRstBtn(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(ResetBtn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ResetBtn.isEnabled());
        Assert.assertEquals(ResetBtn.getText(),optVal);
    }

    public void verifyLblAmntRnge(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(MinAmnt.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(MinAmnt.isEnabled());
        Assert.assertEquals(MinAmnt.getText(),optVal);
    }

    public void verifyMaxAmntLbl(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(MaxAmntLbl.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(MaxAmntLbl.isEnabled());
        Assert.assertEquals(MaxAmntLbl.getText(),optVal);
    }

    public void verifyApplyBtn(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(ApplyBtn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ApplyBtn.isEnabled());
        Assert.assertEquals(ApplyBtn.getText(),optVal);
    }

    public void enterMinAmountInField(String optVal) {

        WebElement AmtRange1 = driver.findElement(By.xpath("(//android.widget.EditText[@text='0'])[1]|//XCUIElementTypeTextField[@name=\"minTextField\"]"));
        try {
            Thread.sleep(6000);
            Assert.assertTrue(AmtRange1.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(AmtRange1.isEnabled());
        Assert.assertEquals(AmtRange1.getText(),"0");

        AmtRange1.sendKeys(optVal);
    }

    public void enterMaxAmountInField(String optVal) {

        WebElement AmtRange = driver.findElement(By.xpath("(//android.widget.EditText[@text='0'])[2]|//XCUIElementTypeTextField[@name=\"maxTextField\"]"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(AmtRange.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(AmtRange.isEnabled());
        Assert.assertEquals(AmtRange.getText(),"0");

        AmtRange.sendKeys(optVal);
    }

    public void clickApplyBtn(String optVal) {
        this.verifyApplyBtn(optVal);
        ApplyBtn.click();
    }

    public void verifyDateFieldLbl(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FromDateField.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FromDateField.isEnabled());
        Assert.assertEquals(FromDateField.getText(),optVal);
    }

    public void verifyDateLblTo(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ToDateField.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ToDateField.isEnabled());
        Assert.assertEquals(ToDateField.getText(),optVal);
    }

    public void clickToDate(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(ToDateFild.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ToDateFild.isEnabled());
        Assert.assertEquals(ToDateFild.getText(),optVal);
        ToDateFild.click();

    }

    public void clickFromDate(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FrmDateFild.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FrmDateFild.isEnabled());
        Assert.assertEquals(FrmDateFild.getText(),optVal);
        FrmDateFild.click();
    }

    public void verifyDatePicker(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(DatePicker.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(DatePicker.isEnabled());
        Assert.assertEquals(DatePicker.getText(),optVal);
    }

    public void clickCancel(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(CancelBtn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(CancelBtn.isEnabled());
        Assert.assertEquals(CancelBtn.getText(),optVal);
        CancelBtn.click();
    }

    public void selectDateFrom() throws InterruptedException {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android")){
        try {
            Thread.sleep(6000);
            Assert.assertTrue(FromDate.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FromDate.isEnabled());
        FromDate.click();}
        else
            genericMethod.setPicker(driver,yearPicker,"2022",donePicker,"previous");

    }

    public void clickOk(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(OkBtn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(OkBtn.isEnabled());
        Assert.assertEquals(OkBtn.getText(),optVal);
        OkBtn.click();
    }

    public void selectDateTo() throws InterruptedException {
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android")) {
            try {
                Thread.sleep(6000);
                Assert.assertTrue(ToDate.isDisplayed());
                System.out.println("Transfer Money between someone accounts verification");
                Thread.sleep(5000);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            Assert.assertTrue(ToDate.isEnabled());
            ToDate.click();
        }
        else  genericMethod.setPicker(driver,yearPicker,"2023",donePicker,"next");
    }

    public void verifyApplyBtnOnDateScreen(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(ApplyBtn_DateScrn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ApplyBtn_DateScrn.isEnabled());
        Assert.assertEquals(ApplyBtn_DateScrn.getText(),optVal);
    }

    public void clickApply(String optVal) {
        this.verifyApplyBtnOnDateScreen(optVal);
        ApplyBtn_DateScrn.click();
    }

    public void verifyDebitLbl(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(DebitTrans.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(DebitTrans.isEnabled());
        Assert.assertEquals(DebitTrans.getText(),optVal);
    }

    public void veriySubDebitTrans(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SubDebitTrans.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SubDebitTrans.isEnabled());
        Assert.assertEquals(SubDebitTrans.getText(),optVal);
    }

    public void verifyCredTrans(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(CreditTrans.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(CreditTrans.isEnabled());
        Assert.assertEquals(CreditTrans.getText(),optVal);
    }

    public void verifySubCred(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SubCreditTrans.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SubCreditTrans.isEnabled());
        Assert.assertEquals(SubCreditTrans.getText(),optVal);
    }

    public void clickCredTrans(String optVal) {
        this.verifyCredTrans(optVal);
        CreditTrans.click();
    }

    public void verifyApplyBtnOnInOutScreen(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(BtnApply.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(BtnApply.isEnabled());
        Assert.assertEquals(BtnApply.getText(),optVal);
    }

    public void clickBtnApplyInOut(String optVal) {
        this.verifyApplyBtnOnInOutScreen(optVal);
        BtnApply.click();
    }

    public void clickDebtTrans(String optVal) {
        this.verifyDebitLbl(optVal);
        DebitTrans.click();
    }

    public void enterInvalidTransDet() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(SearchBar.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(SearchBar.isEnabled());
        SearchBar.click();
        SearchBar.sendKeys("transact");
    }

    public void verifyNoDataVis(String optVal) {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(EmptyDataLbl.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(EmptyDataLbl.isEnabled());
        Assert.assertTrue(EmptyDataLbl.getText().contains(optVal),"Value: "+EmptyDataLbl.getText()+" does  not contain text: "+optVal);
    }

    public void clickCrossIcon() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(CrossIcon.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(CrossIcon.isEnabled());
        CrossIcon.click();

    }

    public void clickResetBtn(String optVal) {
        this.verifyRstBtn(optVal);
        ResetBtn.click();
    }

    public void verifyResettedVal(String optVal) {

        WebElement ResetVal1 = driver.findElement(By.xpath("(//android.widget.EditText[@text='"+optVal+"'])[1]|//XCUIElementTypeTextField[@name=\"minTextField\"]"));
        WebElement ResetVal2 = driver.findElement(By.xpath("(//android.widget.EditText[@text='"+optVal+"'])[2]|//XCUIElementTypeTextField[@name=\"maxTextField\"]"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ResetVal1.isDisplayed());
            Assert.assertTrue(ResetVal2.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ResetVal1.isEnabled());
        Assert.assertEquals(ResetVal1.getText(),optVal);
        Assert.assertTrue(ResetVal2.isEnabled());
        Assert.assertEquals(ResetVal2.getText(),optVal);

    }

    public void verifyTransIcon() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransId.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(TransId.isEnabled());
    }

    public void verifyTransAmount() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransAmnt.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(TransAmnt.isEnabled());
    }

    public void verifyTransDate() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransDate.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(TransDate.isEnabled());
    }

    public void verifyType(String optVal) {
        WebElement TransType=null;
        if(RunnerInfo.getDeviceType().equalsIgnoreCase("android"))  TransType = driver.findElement(By.xpath("//android.widget.TextView[@text='"+optVal+"']"));
        else{
            try{
                TransType = driver.findElement(By.xpath("//XCUIElementTypeOther[contains(@name,'TransactionDetails')]//XCUIElementTypeStaticText[@value='"+optVal+"']"));
            }catch (Exception e){
                TransType = driver.findElement(By.xpath("//XCUIElementTypeStaticText[@value='"+optVal+"' and contains(@name,'TransactionDetails')]"));
            }
        }

        try {
            Thread.sleep(6000);
            Assert.assertTrue(TransType.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(TransType.isEnabled());
        Assert.assertEquals(TransType.getText(),optVal);
    }

    public void clickStatementIcn(String optVal) {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(StatmntIcn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(StatmntIcn.isEnabled());
        Assert.assertEquals(StatmntIcn.getText(),optVal);

        StatmntIcn.click();
    }

    public void verifyBackIcn() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(BackIcn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(BackIcn.isEnabled());
    }

    public void verifyFilterBtn() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(FilterBtn.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(FilterBtn.isEnabled());
    }

    public void verifyImgIcon() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(ImgIcon.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(ImgIcon.isEnabled());
    }

    public void verifyAccName(String optVal) {

        Assert.assertTrue(AccName.isEnabled());
        Assert.assertTrue(AccName.isDisplayed());
        Assert.assertEquals(AccName.getText(),optVal);

    }

    public void verifyAccNo(String optVal) {

        Assert.assertTrue(AccNo.isEnabled());
        Assert.assertTrue(AccNo.isDisplayed());
        Assert.assertEquals(AccNo.getText(),optVal);
    }

    public void verifyAccAmount(String optVal) {

        Assert.assertTrue(AccAmnt.isEnabled());
        Assert.assertTrue(AccAmnt.isDisplayed());
        Assert.assertEquals(AccAmnt.getText(),optVal);
    }

    public void verifyList() {

        Assert.assertTrue(StatmntList.isEnabled());
        Assert.assertTrue(StatmntList.isDisplayed());
    }

    public void clickAccStatmntType() {

        Assert.assertTrue(FirstAccStatmnt.isEnabled());
        Assert.assertTrue(FirstAccStatmnt.isDisplayed());
        Assert.assertEquals(FirstAccStatmnt.getText(),"null");

        FirstAccStatmnt.click();

    }

    public void verifyStatmntView() {

        Assert.assertTrue(StatmntView.isEnabled());
        Assert.assertTrue(StatmntView.isDisplayed());
        Assert.assertEquals(StatmntView.getText(),"Nov 19, 2022");
    }

    public void verifyWholeStatmnt() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(WholeStatmnt.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Assert.assertTrue(WholeStatmnt.isEnabled());
     //   Assert.assertTrue(WholeStatmnt.isDisplayed());
    }

    public void verifyShareStatmnt() {

        Assert.assertTrue(ShareStatmnt.isEnabled());
        Assert.assertTrue(ShareStatmnt.isDisplayed());
    }

    public void selectCreditCard() {

        Assert.assertTrue(CreditCard.isEnabled());
        Assert.assertTrue(CreditCard.isDisplayed());

        CreditCard.click();
    }

    public void scrollToCreditCrd() {

      //  genericMethod.mobileScrollTillEndOfPage(driver, CrrntAcc);

        driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"Visa AFKL Signature Conv.\").instance(0))"));
    }

    public void verifyTransactionScreenCreditCrd() {

        Assert.assertTrue(TransactScrnCredit.isEnabled());
        Assert.assertTrue(TransactScrnCredit.isDisplayed());
    }

    public void clickBackIcon() {

        BackIcn.click();
    }

    public void clickFilterIcn() {

        FilterBtn.click();
    }


    public void verifyResetBtn(String optVal) {

        Assert.assertTrue(filterReset.isEnabled());
        Assert.assertTrue(filterReset.isDisplayed());
        Assert.assertEquals(filterReset.getText(),optVal);
    }

    public void verifyCrossIcon() {

        Assert.assertTrue(filterCross.isEnabled());
        Assert.assertTrue(filterCross.isDisplayed());
    }

    public void verifyDateRng(String optVal) {

        Assert.assertTrue(DateRang.isEnabled());
        Assert.assertTrue(DateRang.isDisplayed());
        Assert.assertEquals(DateRang.getText(),optVal);
    }

    public void verifyFromField(String optVal) {

        WebElement DateFieldLbl = driver.findElement(By.id("com.bsf.retail.uat:id/accountStatementJourney_filterScreen_date"+optVal+"Label"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(DateFieldLbl.isDisplayed());
            System.out.println("Date Field Lbl verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(DateFieldLbl.isEnabled());
        Assert.assertEquals(DateFieldLbl.getText(),optVal);
    }

    public void verifyDateField(String optVal1, String optVal2) {

        WebElement DateField = driver.findElement(By.id("com.bsf.retail.uat:id/accountStatementJourney_filterScreen_date"+optVal2+"Field"));

        try {
            Thread.sleep(6000);
            Assert.assertTrue(DateField.isDisplayed());
            System.out.println("Date Field Lbl verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(DateField.isEnabled());
        Assert.assertEquals(DateField.getText(),optVal1);
    }

    public void verifyStatmntType(String optVal) {

        Assert.assertTrue(StatType.isDisplayed());
        Assert.assertTrue(StatType.isEnabled());
        Assert.assertEquals(StatType.getText(),optVal);
    }

    public void clickPDFSwitch() {

        Assert.assertTrue(PdfType.isDisplayed());
        Assert.assertTrue(PdfType.isEnabled());

        PdfType.click();
    }

    public void verifyApplyFilterBtn(String optVal) {

        Assert.assertTrue(ApplyFilterBtn.isDisplayed());
        Assert.assertTrue(ApplyFilterBtn.isEnabled());
        Assert.assertEquals(ApplyFilterBtn.getText(),optVal);
    }

    public void clickApplyFilterBtn(String optVal) {

        Assert.assertEquals(ApplyFilterBtn.getText(),optVal);
        ApplyFilterBtn.click();
    }

    public void clickShareIcon() {

        ShareStatmnt.click();
    }

    public void verifyCrossIcnOnStatmntView() {

        Assert.assertTrue(CrossIcn.isDisplayed());
        Assert.assertTrue(CrossIcn.isEnabled());
    }

    public void clickCrossIconOnStatView() {

        CrossIcn.click();
    }

    public void clickFilterResetBtn(String optVal) {

        Assert.assertEquals(filterReset.getText(),optVal);
        filterReset.click();
    }

    public void clickCrossFilterStamp() {

        Assert.assertTrue(FilterStampCross.isDisplayed());
        Assert.assertTrue(FilterStampCross.isEnabled());
        FilterStampCross.click();
    }


    public void clickStatementIcon(String optVal) {
        StatementIcon.click();
    }

    public void ClickFilterIcon() {
        FilterIcon.click();
    }

    public void ClickClosecon(String optVal) {
        Assert.assertEquals(FilterScreen.getText(),optVal);
        CloseIcon.click();
    }

    public void VerifyFilterCloseIconFunctionality()
    {
        int totalStatments = driver.findElements(By.xpath("//android.view.ViewGroup[@resource-id=\"com.bsf.retail.uat:id/accountStatementItem\"]")).size();
        Assert.assertEquals(totalStatments, 8);
    }

    public void VerifyAccountStatementScreen(String optVal)
    {

        Assert.assertEquals(AccStatement.getText(),optVal);
    }

    public void ClickBackArrow()
    {

        BackIcon.click();
    }

    public void VerifyDateStatement(String optVal)
    {
        Assert.assertEquals(DateStatement.getText(),optVal);
    }

    public void VerifyFlterContent(String filterContent)
    {
        String value = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "AccountStatement", filterContent);

        String[] filter_contents = value.split(",");

        Assert.assertEquals(FilterScreen.getText(),filter_contents[0]);
        Assert.assertEquals(ResetFlter.getText(),filter_contents[1]);
        Assert.assertEquals(Type.getText(),filter_contents[2]);
        CloseIcon.isDisplayed();

        for (int i = 3; i <filter_contents.length; i++)
        {
            System.out.println(">>>>>>>>>>>filter content " + i + ": " + filter_contents[i]);
            WebElement Contents = driver.findElement(By.id("com.bsf.retail.uat:id/accountStatementJourney_filterScreen_date"+filter_contents[i]+"Label"));
            Assert.assertEquals(Contents.getText(),filter_contents[i]);
        }

        for (int i = 3; i <filter_contents.length; i++)
        {
            System.out.println(">>>>>>>>>>>filter content " + i + ": " + filter_contents[i]);
            WebElement Contents = driver.findElement(By.id("com.bsf.retail.uat:id/accountStatementJourney_filterScreen_date"+filter_contents[i]+"Field"));
            Assert.assertEquals(Contents.getText(),"Set a date");
        }

    }

    public void VerifyStatementTypes(String statementtypes)
    {
        String value = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "AccountStatement", statementtypes);
        String[] StatementTypes = value.split(",");
        int totalStatmentsTypes = driver.findElements(By.xpath("//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_filterScreen_statements_name\"]")).size();
        for (int i = 1; i<= totalStatmentsTypes; i++)
        {
            WebElement statementttypes =  driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/accountStatementJourney_filterScreen_statements_name\"])["+i+"]"));
            System.out.println(">>>>>>>>>>>Expected Result " + i + ": " + StatementTypes[i-1]);
            System.out.println(">>>>>>>>>>>Actual Result " + i + ": " + statementttypes.getText());
            Assert.assertEquals(statementttypes.getText(),StatementTypes[i-1]);
        }
    }

    public void VerifyStatementTypesToggle(String statementtypes)
    {
        String value = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "AccountStatement", statementtypes);
        String[] StatementTypes = value.split(",");

        for (int i = 0; i <StatementTypes.length; i++)
        {
            System.out.println(">>>>>>>>>>>Statement Types " + i + ": " + StatementTypes[i]);
            WebElement toggle_button = driver.findElement(By.xpath("//android.widget.Switch[@content-desc=\""+StatementTypes[i]+"\"]"));
            Assert.assertTrue(toggle_button.isDisplayed());

        }
    }

    public void VerifyToggleON(String statementtypes)
    {
        String value = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "AccountStatement", statementtypes);
        String[] StatementTypes = value.split(",");

        for (int i = 0; i <StatementTypes.length; i++)
        {
            System.out.println(">>>>>>>>>>>Statement Types " + i + ": " + StatementTypes[i]);
            WebElement toggle_button = driver.findElement(By.xpath("//android.widget.Switch[@content-desc=\""+StatementTypes[i]+"\"]"));
            Assert.assertTrue(toggle_button.isEnabled());
            toggle_button.click();
        }

        for (int i = 0; i <StatementTypes.length; i++)
        {
            WebElement toggle_button = driver.findElement(By.xpath("//android.widget.Switch[@content-desc=\""+StatementTypes[i]+"\"]"));
            String toggle_on = toggle_button.getAttribute("checked");
            System.out.println(">>>>>>>>>>>Toggle position " + i + ": " + toggle_on);
            Assert.assertEquals(toggle_on,"true");

        }
    }

    public void VerifyToggleOFF(String statementtypes)
    {
        String value = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "AccountStatement", statementtypes);
        String[] StatementTypes = value.split(",");

        for (int i = 0; i <StatementTypes.length; i++)
        {
            System.out.println(">>>>>>>>>>>Statement Types " + i + ": " + StatementTypes[i]);
            WebElement toggle_button = driver.findElement(By.xpath("//android.widget.Switch[@content-desc=\""+StatementTypes[i]+"\"]"));
            Assert.assertTrue(toggle_button.isEnabled());
            toggle_button.click();
        }

        for (int i = 0; i <StatementTypes.length; i++)
        {
            WebElement toggle_button = driver.findElement(By.xpath("//android.widget.Switch[@content-desc=\""+StatementTypes[i]+"\"]"));
            String toggle_off = toggle_button.getAttribute("checked");
            System.out.println(">>>>>>>>>>>Toggle position " + i + ": " + toggle_off);
            Assert.assertEquals(toggle_off,"false");

        }
    }

    public void ToggleButtonON(String statementtypes)
    {
        WebElement toggle_button = driver.findElement(By.xpath("//android.widget.Switch[@content-desc=\""+statementtypes+"\"]"));
        toggle_button.click();
    }

    public void ClickApplyBtn()
    {

        ApplyFilterBtn.click();
    }

    public void VerifyStatementTypeFilterChip(String text1,String text2)
    {
        Assert.assertEquals(FilterChip1.getText(),text1);
        Assert.assertEquals(FilterChip2.getText(),text2);
    }

    public void VerifyStatementTypeFilter(String text1,String text2)
    {
        int totalFilteredStatements = driver.findElements(By.xpath("//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/textViewCategory\"]")).size();
        for (int i = 1; i<= totalFilteredStatements; i++)
        {
            WebElement FilteredStatements =  driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/textViewCategory\"])["+i+"]"));
            System.out.println(">>>>>>>>>>>Actual Result " + i + ": " + FilteredStatements.getText());
            String ExpectedResult = text1+text2;
            System.out.println(">>>>>>>>>>>Expected Result " + i + ": " + ExpectedResult);
//            Assert.assertTrue(FilteredStatements.getText().contains(ExpectedResult));

        }
    }

    public void SelectDate(String text1,String text2)
    {
        WebElement SetDateField = driver.findElement(By.id("com.bsf.retail.uat:id/accountStatementJourney_filterScreen_date"+text2+"Field"));
        SetDateField.click();
        CalendarYearIcon.click();
//        genericMethod.scrollUp(driver);
        String year = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text1, "Year");
        System.out.println(">>>>>>>>>>>Year from json file " +year);
        String date = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text1, "Date");
        System.out.println(">>>>>>>>>>>Date from json file " +date);

        String month = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text1, "Month");
        System.out.println(">>>>>>>>>>>Month from json file " +month);
        int month1 = Integer.parseInt(month);

        Calendar calendar = Calendar.getInstance();
        int currentMonth = calendar.get(Calendar.MONTH) + 1; // Adding 1 because months are zero-based (0 - 11)
        System.out.println("Current Month (Calendar): " + currentMonth);

        WebElement Year = driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Navigate to current year " + year + "\"]"));
        Year.click();

        int month2 = currentMonth-month1;
        for (int i = 1; i<= month2; i++)
        {
            WebElement previousicon = driver.findElement(By.id("com.bsf.retail.uat:id/month_navigation_previous"));
            previousicon.click();
            System.out.println(">>>>>>>>>>>Clicking " +i);

        }

        WebElement Date = driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"" + date + "\"]"));
        Date.click();
        CalendarOkBtn.click();


    }

    public void VerifyDateRange(String text1,String text2)
    {

        String ActualDateRange = DateRange.getText();
        System.out.println(">>>>>>>>>>>Actual Date Range on the page " +ActualDateRange);

        String year = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text1, "Year");
        System.out.println(">>>>>>>>>>>Year from json file " +year);
        String date = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text1, "Date");
        System.out.println(">>>>>>>>>>>Date from json file " +date);
        String[] date1 = date.split(",");
        String FromDate = date1[1]+", "+year;

        String to_year = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text2, "Year");
        System.out.println(">>>>>>>>>>>Year from json file " +year);
        String to_date = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text2, "Date");
        System.out.println(">>>>>>>>>>>Date from json file " +date);
        String[] to_date1 = to_date.split(",");
        String ToDate = to_date1[1]+", "+to_year;

        String ExpectedDateRange = FromDate+" - "+ToDate;
        System.out.println(">>>>>>>>>>>Expected Date Range " +ExpectedDateRange);

        Assert.assertEquals(ActualDateRange.replace(" ", ""),ExpectedDateRange.replace(" ", ""));

    }

    public void VerifyNoResultVerbiage()
    {
        String text ="Sorry, we couldn’t find what you’re looking for. Please try again.";
//        Assert.assertEquals(NoResultVerbiage.getText().replaceAll("[\n\\s]", ""),text.replaceAll("[\n\\s]", ""));
        Assert.assertEquals(NoResultVerbiageHeader.getText(),"No results found");

    }
    public void ValidateToFromFiled(String text1,String text2)
    {
        WebElement SetDateField = driver.findElement(By.id("com.bsf.retail.uat:id/accountStatementJourney_filterScreen_date"+text1+"Field"));
        SetDateField.click();

        String month = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text2, "Month");
        System.out.println(">>>>>>>>>>>Month from json file " +month);
        int month1 = Integer.parseInt(month);

        Calendar calendar = Calendar.getInstance();
        int currentMonth = calendar.get(Calendar.MONTH) + 1; // Adding 1 because months are zero-based (0 - 11)
        System.out.println("Current Month (Calendar): " + currentMonth);

        int month2 = currentMonth-month1;
        for (int i = 1; i<= month2; i++)
        {
            WebElement previousicon = driver.findElement(By.id("com.bsf.retail.uat:id/month_navigation_previous"));
            previousicon.click();
            System.out.println(">>>>>>>>>>>Clicking " +i);

        }

        String date1 = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text2, "Date1");
        WebElement Date1 = driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"" + date1 + "\"]"));
        Assert.assertFalse(Date1.isEnabled());

        String date = new JsonHandler().getFromKeyPairValue(RunnerInfo.getDeviceName() + "AccountStatement",text2, "Date");
        WebElement Date = driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"" + date + "\"]"));
        Assert.assertTrue(Date.isEnabled());
    }

    public void VerifyToFromFiled(String text1)
    {
        WebElement SetDateField = driver.findElement(By.id("com.bsf.retail.uat:id/accountStatementJourney_filterScreen_date"+text1+"Field"));
        SetDateField.click();

        // Get today's date
        LocalDate today = LocalDate.now();
        String pattern = "E, MMM d";
        Locale locale = Locale.ENGLISH;
        String formattedDate = today.format(DateTimeFormatter.ofPattern(pattern, locale));
        System.out.println("Today's date in custom format: " + formattedDate);

        // Get tomorrow's date
        LocalDate nextDay = today.plusDays(1);
        String formattedNextDay = nextDay.format(DateTimeFormatter.ofPattern(pattern, locale));
        System.out.println("Next day in custom format: " + formattedNextDay);

        WebElement Date1 = driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Today " + formattedDate + "\"]"));
        Assert.assertTrue(Date1.isEnabled());

        WebElement Date = driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"" + formattedNextDay + "\"]"));
        Assert.assertFalse(Date.isEnabled());
    }


    public void verifyIcmngTransactDescScreen() {

        try {
            Thread.sleep(6000);
            Assert.assertTrue(IncmngTransactDescp.isDisplayed());
            System.out.println("Transfer Money between someone accounts verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        Assert.assertTrue(IncmngTransactDescp.isEnabled());
    }

    public void VerifyTransactionType(String type)
    {
        genericMethod.scrollUp(driver);
        int alltransactions = driver.findElements(By.xpath("//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/backbaseRetail_transactionView_subtitle\"]")).size();
        for (int i = 1; i<= alltransactions; i++)
        {
            WebElement transaction =  driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/backbaseRetail_transactionView_subtitle\"])["+i+"]"));
            String[] Actual_result = (transaction.getText()).split("/");
            System.out.println(">>>>>>>>>>>Transaction types from app " +Actual_result[0]);
            String Expected_result = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "AccountStatement", type);
            System.out.println(">>>>>>>>>>>Transaction types from json file " +Expected_result);
            String Expected_result1 = Expected_result.replaceAll("\\s", "");
            String Actual_result1 = Actual_result[0].replaceAll("\\s", "");

            Assert.assertTrue(Expected_result1.contains(Actual_result1), "Failed to verify expected result: " + Expected_result1 + ", actual result: " + Actual_result1);

        }
    }

    public void VerifyTransactionAmount(String amount)
    {
        genericMethod.scrollUp(driver);
        int alltransactions = driver.findElements(By.xpath("//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/backbaseRetail_transactionView_amount\"]")).size();
        for (int i = 1; i<= alltransactions; i++)
        {
            WebElement transaction =  driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/backbaseRetail_transactionView_amount\"])["+i+"]"));
            String[] Actual_result = (transaction.getText()).split(" ");
            System.out.println(">>>>>>>>>>>Transaction amount from app " +Actual_result[0]);
            String Expected_result = new JsonHandler().getJsonValue(RunnerInfo.getDeviceName() + "AccountStatement", amount);
            System.out.println(">>>>>>>>>>>Transaction amount from json file " +Expected_result);
            String Expected_result1 = Expected_result.replaceAll("\\s", "");
            String Actual_result1 = Actual_result[0].replaceAll("\\s", "");

            Assert.assertTrue(Expected_result1.contains(Actual_result1), "Failed to verify expected result: " + Expected_result1 + ", actual result: " + Actual_result1);

        }
    }

    public void VerifyTransactionDescending() throws ParseException
    {
        genericMethod.scrollUp(driver);
        ArrayList<String> dateStrings = new ArrayList<String>();
        int alltransactions = driver.findElements(By.xpath("//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/accountsTransactionsJourney_listView_sectionHeader\"]")).size();
        for (int i = 1; i<= alltransactions; i++)
        {
            WebElement date =  driver.findElement(By.xpath("(//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/accountsTransactionsJourney_listView_sectionHeader\"])["+i+"]"));
            System.out.println(">>>>>>>>>>>Date from app " +date.getText());
            dateStrings .add(date.getText());
        }
        System.out.println(">>>>>>>>>>>Date from arraylist " +dateStrings );
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");

        ArrayList<Date> dates = new ArrayList<>();
        for (String dateString : dateStrings) {
            dates.add(dateFormat.parse(dateString));
        }
        // Check if the dates are in descending order
        boolean isDescending = true;
        for (int i = 0; i < dates.size() - 1; i++) {
            if (dates.get(i).compareTo(dates.get(i + 1)) < 0) {
                isDescending = false;
                break; // Exit the loop as soon as an out-of-order date is found
            }
        }
        if (isDescending) {
            System.out.println("Dates are in descending order.");
            boolean flag = true;
            Assert.assertTrue(flag);


        } else {
            System.out.println("Dates are not in descending order.");
            boolean flag = false;
            Assert.assertTrue(flag);
        }
    }

}
