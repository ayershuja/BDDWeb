package Pages.actions.Mobile;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.*;
import Utils.JsonHandler;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.Reporter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class MyProductsPage_Mobile {

    AppiumDriver driver;
    public String firstSavingsAccountFieldName, firstSavingsAccountFieldNumber, firstSavingsAccountFieldCurrencyValue;
    JsonHandler jsonHandler = new JsonHandler();
    GenericMethod genericMethod = new GenericMethod();

    @iOSXCUITFindBy(iOSNsPredicate = "label == \"My Products\"")
    @AndroidFindBy(accessibility = "My Products")
    public WebElement MyProductsPage;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[starts-with(@label,'Saving')]/..//following-sibling::*//XCUIElementTypeButton")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Saving accounts']//following-sibling::android.view.ViewGroup)[1]")
    public WebElement firstSavingsAccount;
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Saving accounts']//following-sibling::android.view.ViewGroup)[1]//android.widget.TextView")
    public List<WebElement> firstSavingsAccountDetails;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@label='Current accounts']/..//following-sibling::*//XCUIElementTypeButton)[1]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[ends-with(@text,'Current accounts')]//following-sibling::android.view.ViewGroup)[1]")
    public WebElement firstCurrentAccount;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@label='Saving accounts']/..//following-sibling::*)[2]")
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text='Saving accounts']//following-sibling::android.view.ViewGroup)[2]")
    public WebElement secondSavingsAccount;

    @iOSXCUITFindBy(accessibility = "My Products")
    @AndroidFindBy(accessibility = "Navigate up")
    public WebElement backButton;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='Current accounts']/..//following-sibling::*/XCUIElementTypeButton")
    })
    @AndroidFindBy(xpath = "//android.widget.TextView[@text='Current accounts']//following-sibling::*")
    public List<WebElement> allMyCurrentsAccounts;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='Saving accounts']/..//following-sibling::*/XCUIElementTypeButton")
    })
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@text='Saving accounts']//following-sibling::*")
    })
    public List<WebElement> allMySavingsAccounts;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='My Cards']/..//following-sibling::*/XCUIElementTypeButton")
    })
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@text='My Cards']//following-sibling::*")
    })
    public List<WebElement> allMyCardsAccounts;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='Loans']/..//following-sibling::*/XCUIElementTypeButton")
    })
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@text='Loans']//following-sibling::*")
    })
    public List<WebElement> allMyLoansAccounts;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='My Term Deposits']/..//following-sibling::*/XCUIElementTypeButton")
    })
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@text='My Term Deposits']//following-sibling::*")
    })
    public List<WebElement> allMyTermDeposits;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='My Investment Accounts']/..//following-sibling::*/XCUIElementTypeButton")
    })
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@text='My Investment Accounts']//following-sibling::*")
    })
    public List<WebElement> allMyInvestmentAccounts;

    @iOSXCUITFindBy(xpath = "//XCUIElementTypeStaticText[@name='Account currency']/..//following-sibling::XCUIElementTypeStaticText|//XCUIElementTypeStaticText[@name='Account currency']//following-sibling::XCUIElementTypeStaticText")
    @AndroidFindBy(xpath = "(//android.widget.LinearLayout//android.widget.TextView)[3]")
    public WebElement currencyTypeVerify;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "XCUIElementTypeStaticText[ends-with(@label, '.0')")
    })
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[ends-with(@text, '.00')]")
    })
    public List<WebElement> currencyType;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText)[4]")
    @AndroidFindBy(xpath = "(//android.widget.LinearLayout//android.widget.TextView)[3]")
    public WebElement currentBalance;

    @iOSXCUITFindAll({
            @iOSXCUITBy(xpath = "//XCUIElementTypeStaticText[@label='Current accounts']/..//following-sibling::*/XCUIElementTypeButton|//XCUIElementTypeStaticText[@label='Saving accounts']/..//following-sibling::*/XCUIElementTypeButton")
    })
    @AndroidFindAll({
            @AndroidBy(xpath = "//android.widget.TextView[@resource-id=\"com.bsf.retail.uat:id/accountsAndTransactionsJourney_accountsScreen_title\"]")
    })
    public List<WebElement> allAccounts;

    @iOSXCUITFindBy(xpath = "(//XCUIElementTypeStaticText[@value='Credit cards']/..//following-sibling::*//XCUIElementTypeButton)[1]")
    @AndroidFindBy(xpath = "//android.widget.TextView[starts-with(@text,'Credit cards')]//..//following-sibling::android.view.ViewGroup")
    public WebElement creditCard;


    public MyProductsPage_Mobile() {
        this.driver = (AppiumDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void selectBackButton() {
        backButton.click();
    }

    public void verifyMyProductsScreen() {
        try {
            Thread.sleep(6000);
            Assert.assertTrue(MyProductsPage.isDisplayed());
            System.out.println("Products page verification");
            Thread.sleep(5000);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void selectFirstSavingsAccount() {
        if (RunnerInfo.getDeviceType().contains("android")) genericMethod.mobileScrollTillEndOfPage(driver, firstSavingsAccount);
        saveAccountDetails();
        firstSavingsAccount.click();
    }

    public void selectSecondSavingsAccount() {
        if (RunnerInfo.getDeviceType().contains("android")) genericMethod.mobileScrollTillEndOfPage(driver, secondSavingsAccount);
        saveAccountDetails();
        secondSavingsAccount.click();
    }

    public void saveAccountDetails() {
        ArrayList<String> contentDescription = new ArrayList<>();
        if (RunnerInfo.getDeviceType().contains("android")) {
            System.out.println("Android");
            genericMethod.mobileScrollTillEndOfPage(driver, firstSavingsAccount);
            for(WebElement element : firstSavingsAccountDetails){
                contentDescription.add(element.getText());
            }
//            contentDescription = firstSavingsAccount.getAttribute("content-desc").split(", ");
        } else {
            contentDescription.addAll(List.of(firstSavingsAccount.getAttribute("label").split(", ")));
        }
        System.out.println("Saving Account Details:" + contentDescription.toString());
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName", contentDescription.get(0));
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountNumber", contentDescription.get(1));
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency", contentDescription.get(2));
    }

    public void saveAccountDetails(WebElement element, String attribute) {
        String[] contentDescription = element.getAttribute(attribute).split(", ");
        System.out.println("Saving Account Details:" + Arrays.toString(contentDescription));
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName", contentDescription[1]);
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountNumber", contentDescription[2]);
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency", contentDescription[3]);
    }

    public void saveCurrentAccountDetails(WebElement element, String attribute) {
        String[] contentDescription = element.getAttribute(attribute).split(", ");
        System.out.println("Current Account Details:" + Arrays.toString(contentDescription));
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountName", contentDescription[1]);
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountNumber", contentDescription[2]);
        jsonHandler.writeJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountCurrency", contentDescription[3]);
    }

    public void verifyAllAccountTypesUnderHeading(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile, String headingName) {
        switch (headingName.toLowerCase()) {
            case "current accounts" -> {
                if (RunnerInfo.getDeviceType().contains("android"))
                    myCurrentAccountsVerification(savingAccountPageMobile, accountDetailsPage_mobile);
                else myCurrentAccountsVerificationIOS(savingAccountPageMobile, accountDetailsPage_mobile);
            }
            case "savings accounts" -> {
                if (RunnerInfo.getDeviceType().contains("android")) {
                    mySavingsAccountsVerification(savingAccountPageMobile, accountDetailsPage_mobile);
                }
                else mySavingsAccountsVerificationIOS(savingAccountPageMobile, accountDetailsPage_mobile);
            }
            case "my cards" -> myCardsVerification(savingAccountPageMobile, accountDetailsPage_mobile);
            case "my loans" -> myLoansVerification(savingAccountPageMobile, accountDetailsPage_mobile);
            case "my term deposits" -> myTermDepositsVerification(savingAccountPageMobile, accountDetailsPage_mobile);
            case "my investment accounts" ->
                    myInvestmentsVerification(savingAccountPageMobile, accountDetailsPage_mobile);
            default -> throw new RuntimeException("Wrong Header Passed: " + headingName);
        }
    }

    public void currentAccountVerification(WebElement element, SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        element.click();
        savingAccountPageMobile.verifyCurrentAccountName(jsonHandler.getJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountName"));
        savingAccountPageMobile.verifyCurrentAccountNumber(jsonHandler.getJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountNumber"));
        savingAccountPageMobile.verifyCurrentAccountCurrencyValue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountCurrency"));
        savingAccountPageMobile.selectDetailsIcon();
        accountDetailsPage_mobile.verifyAccountDetailsScreen();
        verifyAccountType(accountDetailsPage_mobile, "Current Account");
        accountDetailsPage_mobile.selectBackButton();
        savingAccountPageMobile = new SavingAccountPage_Mobile();
        savingAccountPageMobile.verifyCurrentAccountName(jsonHandler.getJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountName"));
        savingAccountPageMobile.verifyCurrentAccountNumber(jsonHandler.getJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountNumber"));
        savingAccountPageMobile.verifyCurrentAccountCurrencyValue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType()+"CurrentAccountDetails", "accountCurrency"));
        selectBackButton();
        verifyMyProductsScreen();
    }

    public void myCurrentAccountsVerificationIOS(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        int numberOfAccounts = allMyCurrentsAccounts.size();
        WebElement element = null;
        System.out.println("Number of Accounts Found: " + numberOfAccounts);

        for (int i = 1; i <= numberOfAccounts; i++) {
            element = driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@label='Current accounts']/..//following-sibling::*/XCUIElementTypeButton)[" + i + "]"));
            saveCurrentAccountDetails(element, "label");
            currentAccountVerification(element, savingAccountPageMobile, accountDetailsPage_mobile);
            System.out.println("Verification Completed: " + i);
        }
    }

    public void myCurrentAccountsVerification(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        int numberOfAccounts = 0;
        WebElement element = null;
        for (var item : allMyCurrentsAccounts) {
            System.out.println("Item: " + item.getAttribute("class"));
            if (!Objects.equals(item.getAttribute("class"), "android.widget.TextView")) numberOfAccounts++;
            else break;
        }
        System.out.println("Number of Accounts Found: " + numberOfAccounts);

        for (int i = 1; i <= numberOfAccounts; i++) {
            if (RunnerInfo.getDeviceType().contains("android")) {
                element = driver.findElement(By.xpath("(//android.widget.TextView[@text='Current accounts']//following-sibling::android.view.ViewGroup)[" + i + "]"));
            }
            saveCurrentAccountDetails(element, "content-desc");
            currentAccountVerification(element, savingAccountPageMobile, accountDetailsPage_mobile);
        }
    }

    public void myCardsVerification(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        throw new RuntimeException("Function not complete");
    }

    public void savingAccountVerification(WebElement element, SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        element.click();
        savingAccountPageMobile.verifySavingAccountName(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName"));
        savingAccountPageMobile.verifySavingAccountNumber(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountNumber"));
        savingAccountPageMobile.verifySavingAccountCurrencyValue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency"));
        savingAccountPageMobile.selectDetailsIcon();
        accountDetailsPage_mobile.verifyAccountDetailsScreen();
        verifyAccountType(accountDetailsPage_mobile, "Savings Account");
        accountDetailsPage_mobile.selectBackButton();
        savingAccountPageMobile.verifySavingAccountName(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName"));
        savingAccountPageMobile.verifySavingAccountNumber(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountNumber"));
        savingAccountPageMobile.verifySavingAccountCurrencyValue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency"));
        selectBackButton();
        verifyMyProductsScreen();
    }

    public void mySavingsAccountsVerification(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        int numberOfAccounts = 0;
        WebElement element = null;
        for (var item : allMySavingsAccounts) {
            System.out.println("Item: " + item.getAttribute("class"));
            if (!Objects.equals(item.getAttribute("class"), "android.widget.TextView")) numberOfAccounts++;
            else break;
        }
        System.out.println("Number of Accounts Found: " + numberOfAccounts);

        for (int i = 1; i <= numberOfAccounts; i++) {
            if (RunnerInfo.getDeviceType().contains("android")) {
                element = driver.findElement(By.xpath("(//android.widget.TextView[@text='Saving accounts']//following-sibling::android.view.ViewGroup)[" + i + "]"));
            }
            saveAccountDetails(element, "content-desc");
            savingAccountVerification(element, savingAccountPageMobile, accountDetailsPage_mobile);
        }
    }

    public void mySavingsAccountsVerificationIOS(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        int numberOfAccounts = allMySavingsAccounts.size();
        WebElement element = null;
        System.out.println("Number of Accounts Found: " + numberOfAccounts);

        for (int i = 1; i <= numberOfAccounts; i++) {
            element = driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@label='Saving accounts']/..//following-sibling::*/XCUIElementTypeButton)[" + i + "]"));
            saveAccountDetails(element, "label");
            savingAccountVerification(element, savingAccountPageMobile, accountDetailsPage_mobile);
            System.out.println("Verification Completed: " + i);
        }
    }

    public void myLoansVerification(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        throw new RuntimeException("Function not complete");
    }

    public void myTermDepositsVerification(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        throw new RuntimeException("Function not complete");
    }

    public void myInvestmentsVerification(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        throw new RuntimeException("Function not complete");
    }

    public void verifyCurrencyForAllAccounts(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        WebElement element = null;
        int allaccounts = (allAccounts.size()-1);
        for (int i = 1; i <= allaccounts; i++) {
            System.out.println("loop sizeee "+ (allAccounts.size()));
            System.out.println("loop sizeee less 1 "+ allaccounts);
            if (RunnerInfo.getDeviceType().contains("android")) {
                element = driver.findElement(By.xpath("(//androidx.recyclerview.widget.RecyclerView//android.view.ViewGroup)[" + i + "]"));
                saveAccountDetails(element, "content-desc");
            } else {
                element = driver.findElement(By.xpath("(//XCUIElementTypeStaticText[@label='Current accounts']/..//following-sibling::*/XCUIElementTypeButton|//XCUIElementTypeStaticText[@label='Saving accounts']/..//following-sibling::*/XCUIElementTypeButton)[" + i + "]"));
                saveAccountDetails(element, "label");
            }
            element.click();
            savingAccountPageMobile.selectDetailsIcon();
            accountDetailsPage_mobile.verifyAccountDetailsScreen();
            if (RunnerInfo.getDeviceType().contains("android")) {
                try {
                    if(!currencyTypeVerify.getText().contains("credit limit")) {
                        Assert.assertTrue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency").contains(currencyTypeVerify.getText()), "Failed to verify expected account current : " + jsonHandler.getJsonValue("savingAccountDetails", "accountCurrency") + " actual account currency : " + currencyTypeVerify.getText());
                    }
                }
                catch (Exception e){
                    System.out.println(e);
                }
            } else {
                Assert.assertTrue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency").contains(currencyTypeVerify.getAttribute("label")));
            }
            accountDetailsPage_mobile.selectBackButton();
            savingAccountPageMobile = new SavingAccountPage_Mobile();
            savingAccountPageMobile.verifySavingAccountName(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName"));
            savingAccountPageMobile.verifySavingAccountNumber(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountNumber"));
            savingAccountPageMobile.verifySavingAccountCurrencyValue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency"));
            selectBackButton();
            verifyMyProductsScreen();
        }
    }

    public void verifyAllAccountBalance(SavingAccountPage_Mobile savingAccountPageMobile, AccountDetailsPage_Mobile accountDetailsPage_mobile) {
        WebElement element = null;
        for (int i = 1; i <= currencyType.size(); i++) {
            if (RunnerInfo.getDeviceType().contains("android")) {
                element = driver.findElement(By.xpath("(//android.widget.TextView[ends-with(@text, '.00')])[" + i + "]"));
            } else {
                element = driver.findElement(By.xpath("(XCUIElementTypeStaticText[ends-with(@label, '.0')]))[" + i + "]"));
            }
            saveAccountDetails();
            element.click();
            savingAccountPageMobile.selectDetailsIcon();
            accountDetailsPage_mobile.verifyAccountDetailsScreen();
            String origBalance = jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency").trim().replace("SAR", "");
            String detailsPageBalance = currentBalance.getText().trim().replace("SAR", "");
            System.out.println("origBalance" +origBalance);
            System.out.println("detailsPageBalance" +detailsPageBalance);
            Assert.assertEquals(detailsPageBalance, origBalance);
            accountDetailsPage_mobile.selectBackButton();
            savingAccountPageMobile = new SavingAccountPage_Mobile();
            savingAccountPageMobile.verifySavingAccountName(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountName"));
            savingAccountPageMobile.verifySavingAccountNumber(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountNumber"));
            savingAccountPageMobile.verifySavingAccountCurrencyValue(jsonHandler.getJsonValue(RunnerInfo.getDeviceType() + "SavingAccountDetails", "accountCurrency"));
            accountDetailsPage_mobile.selectBackButton();
            verifyMyProductsScreen();
        }
    }

    public void verifyAccountType(AccountDetailsPage_Mobile accountDetailsPage_mobile, String type) {
        Assert.assertEquals(accountDetailsPage_mobile.accountType.getText(), type);
    }

    public void selectFirstCurrentAccount() {
        firstCurrentAccount.isDisplayed();
        if (RunnerInfo.getDeviceType().contains("android")) {
            saveAccountDetails(firstCurrentAccount, "content-desc");
        } else {
            saveAccountDetails(firstCurrentAccount, "label");
        }
        firstCurrentAccount.click();
    }

    public void clickOnCreditCard() {
//		String cardName = PropertiesOperations.getPropertyValueByKey(RunnerInfo.getDeviceType() + "CreditCardDetail","Credit_Card_Name").trim();
//		while (genericMethod.isElementPresent(creditCard)){
//
//			genericMethod.scroll(driver);
//        WebElement element = driver.findElement(By.xpath("(//android.widget.TextView[contains(@resource-id,'accountsAndTransactions')])[1]"));
//        WebElement lastElement = driver.findElement(By.xpath("(//android.widget.TextView[contains(@resource-id,'accountsAndTransactions')])[last()]"));
        genericMethod.mobileScrollTillEndOfPage(driver, creditCard);
        creditCard.click();
    }
}
//		}
