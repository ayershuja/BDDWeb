package Pages.actions.Browser;
import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.PropertiesOperations;
import com.adobe.s3fs.com.amazonaws.services.dynamodbv2.xspec.B;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class DigitalSales_Browser {
    private final SoftAssert softAssert;
    GenericMethod genericMethod = new GenericMethod();
        WebDriver driver;
        WebDriverWait wait;
        @FindBy(xpath = "//img[@alt='Introduction modal image']")
        WebElement img_label;

        @FindBy(xpath = "//p[@class='bb-text-primary']")
        WebElement paragraph;

        @FindBy(xpath = "//input[@id='bb_input_0' and @aria-checked='false']")
        WebElement checkbox_unchecked;
        @FindBy(xpath = "//span[@class='bb-input-checkbox__content']")
        WebElement checkbox;

        @FindBy(xpath = "//button[@class='bb-load-button btn-primary btn-sm btn']")
        WebElement btn_clicked;

        @FindBy(xpath = "//input[@id='ds-idn-journey-ang--ssn']")
        WebElement txtbox_NationalID;

        @FindBy(xpath = "//button[@type='button']/span")
        WebElement continueButton;

        @FindBy(xpath = "//div[@class='bb-logo bb-logo--emblem']")
        WebElement logoImg;




    public DigitalSales_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceName());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        this.softAssert = new SoftAssert();

    }

    public void GetTheImageVerified() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(img_label));
        img_label.isDisplayed();
    }
    public void GetTheTextVerified(String text) throws Exception {
        WebElement ele = driver.findElement(By.xpath("//*[normalize-space()='"+text+"']"));
        wait.until(ExpectedConditions.visibilityOf(ele));
        ele.isDisplayed();
    }
    public void GetTextVerified(String text) throws Exception {
        WebElement ele = driver.findElement(By.xpath("//*[contains(text(),'"+text+"']"));
        wait.until(ExpectedConditions.visibilityOf(ele));
        ele.isDisplayed();
    }
    public void TextBoxDisplayed() throws Exception {
//        WebElement ele = driver.findElement(By.xpath("//input[@id='ds-idn-journey-ang--ssn']"));
        wait.until(ExpectedConditions.visibilityOf(txtbox_NationalID));
        txtbox_NationalID.isDisplayed();
    }
    public void WriteText(String txt) throws Exception {
//        WebElement ele = driver.findElement(By.xpath("//input[@id='ds-idn-journey-ang--ssn']"));
        wait.until(ExpectedConditions.visibilityOf(txtbox_NationalID));
        txtbox_NationalID.isDisplayed();
        txtbox_NationalID.sendKeys(PropertiesOperations.getPropertyValueByKey(txt));

    }
    public void ContinueButtonDisplayed() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(continueButton));
        continueButton.isDisplayed();
    }
    public void ContinueButtonClicked() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(continueButton));
        continueButton.click();
    }
    public void LogoOnFooter() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(logoImg));
        logoImg.isDisplayed();
    }
    public void CheckBoxValue() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(checkbox_unchecked));
        checkbox_unchecked.isDisplayed();
    }
    public void CheckBoxClick() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(checkbox));
        checkbox.click();
    }
    public void GetStartedBtn(String txt) throws Exception {
        wait.until(ExpectedConditions.visibilityOf(checkbox));
        checkbox.isEnabled();
    }
    public void GetStartedClicked() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(btn_clicked));
        btn_clicked.click();
    }
    public void SeeTheText(String text) throws Exception {
        WebElement ele = driver.findElement(By.xpath("//strong[contains(text(),'"+text+"')]"));
        wait.until(ExpectedConditions.visibilityOf(ele));
        ele.isDisplayed();
    }
    public void GetTheParagraphVerified() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(paragraph));
        paragraph.isDisplayed();
    }
    public void GetTheStepperBtnVerified(String txt) throws Exception {
        WebElement ele = driver.findElement(By.xpath("//div[@class='circle active'])['"+txt+"']"));
        wait.until(ExpectedConditions.visibilityOf(ele));
        ele.isDisplayed();
    }
    public void GetTheBtnVerified(String txt) throws Exception {
        WebElement ele = driver.findElement(By.xpath("//button[contains(text(),'"+txt+"')]"));
        wait.until(ExpectedConditions.visibilityOf(ele));
        ele.isDisplayed();
    }
    public void ClickBtn(String txt) throws Exception {
        WebElement ele = driver.findElement(By.xpath("//button[contains(text(),'"+txt+"')]"));
        wait.until(ExpectedConditions.visibilityOf(ele));
        ele.click();
    }

}
