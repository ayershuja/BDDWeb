package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.testng.AssertJUnit.assertEquals;

public class CaptureTransferDetails_Browser {

    WebDriver driver;
    Driver newDriver = new Driver();


    WebDriverWait wait;

    public CaptureTransferDetails_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }


    @FindBy(xpath = "//*[@data-role='card-title']//*[@class='bb-ellipsis bb-ellipsis--single-line']")
    WebElement SelectedField;

    @FindBy(xpath = "//*[@label='Full Name']//input")
    WebElement FullNamefield;

    @FindBy(xpath = "//*[@label='IBAN']//input")
    WebElement IBANfield;

    public void verifyAccountSelected(String AccountName) {
        String actualAccountName = SelectedField.getAttribute("outerText");
        Assert.assertEquals(AccountName, actualAccountName);
    }

    public void EnterValueInSpecficField(String value, String field) {
        var val = driver.findElement(By.xpath("//*[@data-role='label' and contains(text(),'" + field + "')]/..//input"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.sendKeys(value);
    }

    public void EnterValueInAmountField(String value, String field) {
        var val = driver.findElement(By.xpath("//*[@class='bb-label' and contains(text(),'" + field + "')]/..//input"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.sendKeys(value);
    }

    public void verifyInputType(String Type) {
        String ActualInputType = FullNamefield.getAttribute("type");
        Assert.assertEquals(Type, ActualInputType);
    }

    public void verifyInputTypeIBAN(String Type) {
        String ActualInputType = IBANfield.getAttribute("type");
        Assert.assertEquals(Type, ActualInputType);
    }

    public void VerifyInlineError(String message, String field) {
        //wait.until(ExpectedConditions.visibilityOf(OtherPurposeLabel));
        WebElement actualValue1 = driver.findElement(By.xpath("//*[@label='" + field + "']//label/../..//*[@class='bb-input-validation-message ng-star-inserted']/span"));
        var actualField = driver.findElement(By.xpath("//*[@label='" + field + "']//label")).getText();
        System.out.println(actualField);
        Assert.assertEquals(field, actualField);
        String actualmessage = actualValue1.getAttribute("innerText");
        Assert.assertEquals(message, actualmessage);
    }

    public void VerifyInlineError(String message) {
        WebElement actualValue1 = driver.findElement(By.xpath("//*[@class='bb-label' and contains(text(),'Amount')]/..//*[@class='bb-input-validation-message ng-star-inserted']/span"));
        String actualmessage = actualValue1.getAttribute("innerText");
        Assert.assertEquals(message, actualmessage);
    }

    public void TabKeyPress() {
        Actions actions = new Actions(driver);
        actions.sendKeys(Keys.TAB).perform();
    }
}