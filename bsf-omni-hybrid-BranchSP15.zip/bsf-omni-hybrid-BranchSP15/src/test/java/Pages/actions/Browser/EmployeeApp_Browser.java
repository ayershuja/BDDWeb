package Pages.actions.Browser;


import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.PropertiesOperations;
import com.adobe.s3fs.com.amazonaws.services.dynamodbv2.xspec.B;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class EmployeeApp_Browser {
    GenericMethod genericMethod = new GenericMethod();
    WebDriver driver;
    WebDriverWait wait;
    @FindBy(xpath = "//label[contains(text(),'Username or full name')]")
    WebElement lbl_username;
    @FindBy(xpath = "//span[@class='integer']")
    WebElement count_users;

    @FindBy(xpath = "//table[@class='table table-fixed table-hover']")
    WebElement user_table;

    @FindBy(xpath = "//tr[@tabindex='0']/td[contains(text(),'Amal')]")
    WebElement users_displayed;

    @FindBy(xpath = "//input[@id='bb_input_0']")
    WebElement input_user;
    @FindBy(xpath = "//button[@class='btn-md btn btn-primary']")
    WebElement btn_finduser;
    @FindBy(xpath = "//div/p[contains(text(),' No users found ')]")
    WebElement errorMsg;
    @FindBy(xpath = "//tr[@tabindex='0']/td[contains(text(),'Amal')]")
    WebElement selectUser;

    @FindBy(xpath = "//button[@aria-label='Close current mode']")
    WebElement ctaBtn;

    @FindBy(xpath = "//button[@class='dropdown-toggle btn-primary btn-md btn']")
    WebElement actionBtn;
    @FindBy(xpath = "//button[@type='submit']")
    WebElement saveBtn;
    @FindBy(xpath = "//span[@data-role='admin-user-details-success-notification']")
    WebElement notification;

    @FindBy(xpath = "//button[normalize-space()='Restore device']")
    WebElement Restoredevice;
    @FindBy(xpath = "//div[contains(text(),'Galaxy S22')]")
    WebElement deviceName;
    @FindBy(xpath = "//div[contains(text(),'Galaxy S22')]/.. //span[contains(text(),\"samsung 'SM-S908E' \")]")
    WebElement deviceType;

    @FindBy(xpath = "//span[@class='bb-stack__item bb-text-bold']")
    WebElement fullnameBtn;
    @FindBy(xpath = "//button[@data-role='admin-user-details-mobile-number-manage']")
    WebElement manageCTA;
    @FindBy(xpath = "//button[@data-role='admin-user-details-full-name-manage']")
    WebElement manageCTAfullname;

    @FindBy(xpath = "//span[normalize-space()='Username']")
    WebElement usernameDetails;
    @FindBy(xpath = "//h3[normalize-space()='Edit full name']")
    WebElement editFullName;

    @FindBy(xpath = "//label[normalize-space()='Family name(s)']/../input")
    WebElement familyName;
    @FindBy(xpath = "//label[normalize-space()='Given name(s)']/../input")
    WebElement givenName;

    @FindBy(xpath = "//button[normalize-space()='Cancel']")
    WebElement cancelBtn;

    @FindBy(xpath = "//td[1]")
    WebElement searchResults;
    @FindBy(xpath = "//button[@type='button'][normalize-space()='Suspend device']")
    WebElement suspendBtn;
    @FindBy(xpath = "//span[normalize-space()='Email address']")
    WebElement emailaddress;

    @FindBy(xpath = "//span[@class='badge break-word badge-warning']")
    WebElement badgeVerifiedUnverified;
    SoftAssert softAssert;
    @FindBy(xpath = "//button[@data-role='admin-user-details-email-address-manage']")
    WebElement emailManageCTA;

    @FindBy(xpath = "//button[@data-role='admin-user-details-mobile-number-manage']")
    WebElement mobilenumManageCTA;


    public EmployeeApp_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        this.softAssert = new SoftAssert();

    }

    public void GetLabelText(String value) {
        var val = driver.findElement(By.xpath("//label[contains(text(),'" + value + "')]/../label"));
        try {
            Thread.sleep(5000);
            wait.until(ExpectedConditions.visibilityOf(lbl_username));
            Assert.assertTrue(val.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }

    }

    public void inputFieldsVisible(String value) {
        var locator = "//input[@id='bb_input_0']";
        if (Objects.equals(value, "Username or full name")) {
            locator = "//input[@id='bb_input_0']";
        } else if (Objects.equals(value, "Legal entity name")) {
            locator = "//input[@id='bb_input_1']";
        }
        var element = driver.findElement(By.xpath(locator));
        wait.until(ExpectedConditions.visibilityOf(element));
        Assert.assertTrue(element.isDisplayed());
    }

    public void totalNumOfUserisDisplayed() {
        wait.until(ExpectedConditions.visibilityOf(count_users));
        Assert.assertTrue(count_users.isDisplayed());
    }

    public void userTableisDisplayed() {
        wait.until(ExpectedConditions.visibilityOf(user_table));
        user_table.isDisplayed();
    }

    public void verifyUsersDisplayed(String value) throws Exception {
        var name = PropertiesOperations.getPropertyValueByKey(value);
        var val = driver.findElement(By.xpath("//tr[@tabindex='0']/td[contains(text(),'" + name + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        user_table.isDisplayed();
    }

    public void empAppEnterUser(String value) throws Exception {
//        System.out.println(value);
        wait.until(ExpectedConditions.visibilityOf(input_user));
        input_user.sendKeys(PropertiesOperations.getPropertyValueByKey(value));
    }

    public void clickFindUserbtn() throws Exception {

        wait.until(ExpectedConditions.visibilityOf(btn_finduser));
        btn_finduser.click();
    }

    public void clickUserToSelect(String value) throws Exception {
        var value1 = PropertiesOperations.getPropertyValueByKey(value);
        var val = driver.findElement(By.xpath("(//td[contains(text(),'" + value1 + "')])[1]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
        val.click();
    }

    public void errorMsg() throws Exception {

        wait.until(ExpectedConditions.visibilityOf(errorMsg));
        errorMsg.isDisplayed();
    }

    public void btnCTASelect() throws Exception {

        wait.until(ExpectedConditions.visibilityOf(ctaBtn));
        ctaBtn.isDisplayed();
    }

    public void actionsDDLSelect() throws Exception {

        wait.until(ExpectedConditions.visibilityOf(actionBtn));
        actionBtn.isDisplayed();
        actionBtn.click();
    }

    public void elementIsDisplayed(String value) throws Exception {
//        var val = driver.findElement(By.xpath("//*[normalize-space()='"+value+"']"));
        try {
            var val = driver.findElement(By.xpath("(//*[normalize-space()='" + value + "'])[last()]"));
            wait.until(ExpectedConditions.visibilityOf(val));
            Assert.assertTrue(val.isDisplayed());
        } catch (Exception Ex) {
            var val = driver.findElement(By.xpath("//*[normalize-space()='" + value + "']"));
            wait.until(ExpectedConditions.visibilityOf(val));
            Assert.assertTrue(val.isDisplayed());
        }
    }

    public void deviceDetailsDisplayed(String value) throws Exception {
        wait.until(ExpectedConditions.visibilityOf(deviceName));
        wait.until(ExpectedConditions.visibilityOf(deviceType));
        Assert.assertTrue(deviceName.isDisplayed());
        Assert.assertTrue(deviceType.isDisplayed());
    }

    public void elementIsNotDisplayed(String value) throws Exception {

        try {
            var val = driver.findElement(By.xpath("//*[normalize-space()='" + value + "']"));
            var bit = val.isDisplayed();
        } catch (NoSuchElementException ex) {
            System.out.println("Window got collapsed");

        }
    }

    public void dropDownOpIsDisplayed(String value1, String value2) throws Exception {
        var value = PropertiesOperations.getPropertyValueByKey(value2);
//        var val = driver.findElement(By.xpath("//button[@aria-label='" + value + "']/..//*[contains(text(),'" + value1 + "')]"));
        var val = driver.findElement(By.xpath("//div[@class='dropdown-menu show']//button[@role='menuitem'][normalize-space()='" + value1 + "']"));
        if(value1.equals("Restore device")) {
            val = driver.findElement(By.xpath("(//button[@aria-label='"+value+"'])[1]"));
        }else {
            val = driver.findElement(By.xpath("//div[@class='dropdown-menu show']//button[@role='menuitem'][normalize-space()='" + value1 + "']"));
        }Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOf(val));
//        Assert.assertTrue(val.isDisplayed());
    }
    public void dropDownOpIsClicked(String value1, String value2) throws Exception {
        var value = PropertiesOperations.getPropertyValueByKey(value2);
//        var val = driver.findElement(By.xpath("//button[@aria-label='" + value + "']/..//*[contains(text(),'" + value1 + "')]"));
        var val = driver.findElement(By.xpath("//div[@class='dropdown-menu show']//button[@role='menuitem'][normalize-space()='" + value1 + "']"));
        if(value1.equals("Restore device")) {
            val = driver.findElement(By.xpath("(//button[@aria-label='"+value+"'])[1]"));
        }else {
            val = driver.findElement(By.xpath("//div[@class='dropdown-menu show']//button[@role='menuitem'][normalize-space()='" + value1 + "']"));
        }Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
//        Assert.assertTrue(val.isDisplayed());
    }
    public void dropDownOpIsClicked1(String value1, String value2) throws Exception {

        var value = PropertiesOperations.getPropertyValueByKey(value2);
        var val = driver.findElement(By.xpath("(//button[@aria-label='" + value + "']/..//*[contains(text(),'" + value1 + "')])[last()]"));
        Thread.sleep(3000);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void dropDownOpIsClicked(String value) throws Exception {
        var val = driver.findElement(By.xpath("(//*[normalize-space()='" + value + "'])[last()]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void elementDisplayed(String value1) throws Exception {
        var value = PropertiesOperations.getPropertyValueByKey(value1);
        var val = driver.findElement(By.xpath("//div[normalize-space()='" + value + "']"));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void deviceNameIsDisplayed(String value1) throws Exception {
        var value = PropertiesOperations.getPropertyValueByKey(value1);
        var val = driver.findElement(By.xpath("(//span[@data-role='device-item-friendly-name'][normalize-space()='"+value+"'])[last()]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void deviceTypeIsDisplayed(String value_a, String value_b) throws Exception {
        var value1 = PropertiesOperations.getPropertyValueByKey(value_a);
        var value2 = PropertiesOperations.getPropertyValueByKey(value_b);
        var val = driver.findElement(By.xpath("(//span[@data-role='device-item-friendly-name'][normalize-space()='" + value1 + "']/../..//span)[last()]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void suspendedIsDisplayed(String value_a, String value2) throws Exception {
        try {
            var value1 = PropertiesOperations.getPropertyValueByKey(value_a);
            var val = driver.findElement(By.xpath("//span[@data-role='device-item-friendly-name'][normalize-space()='" + value1 + "']/../..//..//..//..//span[contains(text(),'" + value2 + "')]"));
            wait.until(ExpectedConditions.visibilityOf(val));
//        genericMethod.isElementPresent(val);
            this.softAssert.assertEquals(genericMethod.isElementPresent(val), true, "SUSPENDED not found ");
        } catch (Exception ex) {
            System.out.println("SUSPENDED not found ");
        }
    }

    public void elementisClicked(String value) throws Exception {

        var val = driver.findElement(By.xpath("//*[normalize-space()='" + value + "']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
        val.click();
    }

    public void threeDotsClicked() throws Exception {

        var val = driver.findElement(By.xpath("//button[@aria-label='Manage device Galaxy S22 Ultra']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOf(val));
        String text = val.getAttribute("aria-expanded");
        Assert.assertSame("false", text, "Dropdown is not expanded");
        Assert.assertTrue(val.isDisplayed());
        val.click();
        Thread.sleep(3000);
    }

    public void managebBtnIsClicked(String value) throws Exception {
        var value1 = PropertiesOperations.getPropertyValueByKey(value);
//        var val = driver.findElement(By.xpath("//button[@aria-label='" + value1 + "']"));
        var val = driver.findElement(By.xpath("(//button[@aria-label='"+value1+"'])[last()]"));
        if(value.equals("restore_menu_dropdown"))
        {
            val = driver.findElement(By.xpath("(//button[@aria-label='"+value1+"'])[1]"));
        }
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
        val.click();
    }

    public void managebBtnIsDisplayed(String value) throws Exception {
        var value1 = PropertiesOperations.getPropertyValueByKey(value);
        var val = driver.findElement(By.xpath("//button[@aria-label='" + value1 + "']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void clickManageBtn(String value) throws Exception {
        var value1 = driver.findElement(By.xpath("//button[@data-role='admin-user-details-" + value + "-manage']"));
        wait.until(ExpectedConditions.visibilityOf(value1));
        value1.isDisplayed();
        value1.click();
    }

    public void verifyInputField(String value) throws Exception {
        var value1 = driver.findElement(By.xpath("//label[normalize-space()='" + value + "']/../input"));
        wait.until(ExpectedConditions.visibilityOf(value1));
        value1.isDisplayed();
        value1.click();
    }

    public void verifyGivenName() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(givenName));
        givenName.isDisplayed();
    }

    public void verifyEditFullName() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(editFullName));
        editFullName.isDisplayed();
    }

    public void windowCollapsed() {
        if (genericMethod.isElementPresent(editFullName)) {
            Assert.assertTrue(editFullName.isDisplayed());
        }
    }

    public void notificationDisplayed() {
        if (genericMethod.isElementPresent(notification)) {
//            Assert.assertTrue(notification.isDisplayed());
            System.out.println("notificationDisplayed");
        }
    }

    public void notificationDisplayed1(String value) {
        var val = driver.findElement(By.xpath("//div[contains(text(),'" + value + "')]"));
        if (genericMethod.isElementPresent(val)) {
            Assert.assertTrue(val.isDisplayed());
        }
    }

    public void inputEditFullName(String value, String elementName) throws Exception {
        var value1 = PropertiesOperations.getPropertyValueByKey(value);
        WebElement value2;
        if (Objects.equals(elementName, "Mobile number")) {
            value2 = driver.findElement(By.xpath("//label[normalize-space()='" + elementName + "']/../div/input"));
        } else {
            value2 = driver.findElement(By.xpath("//label[normalize-space()='" + elementName + "']/../input"));
        }
        wait.until(ExpectedConditions.visibilityOf(value2));

        try {
            Thread.sleep(10000);
            value2.clear();
            value2.sendKeys(value1);

        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }
    }

    public void verifyFamilyName() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(familyName));
        familyName.isDisplayed();
    }

    public void saveBtn() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(saveBtn));
        saveBtn.isDisplayed();
        saveBtn.click();
    }

    public void cancelBtn(String value) throws Exception {
        var val = driver.findElement(By.xpath("//button[normalize-space()='" + value + "']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
        val.click();
        Thread.sleep(3000);
    }

    public void saveBtnIsDisplayed() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(saveBtn));
        saveBtn.isDisplayed();
    }

    public void cancelBtnIsDisplayed() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(cancelBtn));
        cancelBtn.isDisplayed();
    }

    public void btnIsDisplayed(String value) throws Exception {
        var val = driver.findElement(By.xpath("//button[normalize-space()='" + value + "']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void searchResult() throws Exception {
        wait.until(ExpectedConditions.visibilityOf(searchResults));
        Assert.assertTrue(searchResults.isDisplayed());
    }

    public void suspendBtn(String value) throws Exception {

        var val = driver.findElement(By.xpath("//button[@type='button'][normalize-space()='" + value + "']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
        Thread.sleep(3000);
    }

    public void specialBtn(String value) throws Exception {

        var val = driver.findElement(By.xpath("//button[@type='button'][normalize-space()='" + value + "']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        if(!value.equals("Suspend device"))
        {
            val.click();
        }

    }
//    public void clickCancelBtn() throws Exception {
//        wait.until(ExpectedConditions.visibilityOf(cancelBtn));
//        cancelBtn.isDisplayed();
//        cancelBtn.click();
//    }
}
