package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import junit.framework.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ProxyTransfer_Browser {


    WebDriver driver;
    WebDriverWait wait;

    public ProxyTransfer_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//*[@label='Transfer Method']//option[2]")
    WebElement NormalTransaction;

    @FindBy(xpath = "//*[@label='Bank']//option")
    List<WebElement> BankOptions;

    @FindBy(xpath = "//*[@label='Other Purpose']//input")
    WebElement OtherPurpose;

    @FindBy(xpath = "//*[@label='Other Purpose']//label")
    WebElement OtherPurposeLabel;

    @FindBy(xpath = "//*[@class='bb-label' and contains(text(),'Amount')]/..//input")
    WebElement AmountField;

    @FindBy(xpath = "//*[@label='Note (Optional)']//label/..//textarea")
    WebElement NoteFieldtextArea;


    public void verifyDefaultPhoneNumber(String expectedPhoneNumber) {
        String actualPhoneNumber = NormalTransaction.getAttribute("text");
        Assert.assertEquals(expectedPhoneNumber, actualPhoneNumber);
    }

    public void ClickTransferMethodDropdown(String value) {
        var val = driver.findElement(By.xpath("//*[@label='" + value + "']/..//select[@data-role='dropdown']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void verifyTransferMethodDropdownList(String value) {
        var actualValue = driver.findElement(By.xpath("//*[@label='Transfer Method']//*[@data-role='dropdown']//option[contains(text(),'" + value + "')]")).getText();
        Assert.assertEquals(value, actualValue);
    }

    public void verifyBankOptions() {
        for (WebElement webElement : BankOptions) {
            webElement.isDisplayed();
        }
    }

    public void SelectOptionFromDropdown(String value, String name) {
        var val = driver.findElement(By.xpath("//*[@data-role='label' and contains(text(),'" + name + "')]/..//option[@class='ng-star-inserted' and contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void verifyInputType(String Type) {
        String ActualInputType = OtherPurpose.getAttribute("type");
        Assert.assertEquals(Type, ActualInputType);
    }

    public void VerifyHelperText(String value, String placeholder) {
        //wait.until(ExpectedConditions.visibilityOf(OtherPurposeLabel));
        WebElement actualValue1 = driver.findElement(By.xpath("//*[@label='" + value + "']//label/..//input"));
        var actualValue = driver.findElement(By.xpath("//*[@label='" + value + "']//label")).getText();
        System.out.println(actualValue);
        Assert.assertEquals(value, actualValue);
        String actualplaceholder = actualValue1.getAttribute("placeholder");
        Assert.assertEquals(placeholder, actualplaceholder);
    }

    public void VerifyLength(String value, String length) {
        WebElement actualValue1 = driver.findElement(By.xpath("//*[@label='" + value + "']//label/..//input"));
        var actualValue = driver.findElement(By.xpath("//*[@label='" + value + "']//label")).getText();
        System.out.println(actualValue);
        Assert.assertEquals(value, actualValue);
        String actuallength = actualValue1.getAttribute("maxLength");
        Assert.assertEquals(length, actuallength);
    }

    public void VerifyAmountField(String value) {
        var val = driver.findElement(By.xpath("//label[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void VerifyAmountPlaceHolder(String value, String PlaceHolder) {
        wait.until(ExpectedConditions.visibilityOf(AmountField));
        var actualValue = driver.findElement(By.xpath("//*[@class='bb-label' and contains(text(),'" + value + "')]")).getText();
        System.out.println(actualValue);
        Assert.assertEquals(value, actualValue);
        String actualPlaceHolder = AmountField.getAttribute("placeholder");
        Assert.assertEquals(PlaceHolder, actualPlaceHolder);
    }

    public void VerifyNoteHelperText(String value, String placeholder) {
        var actualValue = driver.findElement(By.xpath("//*[@label='" + value + "']//label")).getText();
        System.out.println(actualValue);
        Assert.assertEquals(value, actualValue);
        String actualplaceholder = NoteFieldtextArea.getAttribute("placeholder");
        Assert.assertEquals(placeholder, actualplaceholder);
    }

    public void VerifyMaximumLength(String value, String MaximumLength) {
        var actualValue = driver.findElement(By.xpath("//*[@label='" + value + "']//label")).getText();
        System.out.println(actualValue);
        Assert.assertEquals(value, actualValue);
        String actualMaximumLength = NoteFieldtextArea.getAttribute("maxLength");
        Assert.assertEquals(MaximumLength, actualMaximumLength);
    }


}
