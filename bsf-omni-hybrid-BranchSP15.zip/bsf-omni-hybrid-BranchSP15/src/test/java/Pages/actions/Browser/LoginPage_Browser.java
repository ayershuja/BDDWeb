package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.PropertiesOperations;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.Dimension;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class LoginPage_Browser {


    WebDriver driver;
    WebDriverWait wait;

    @FindBy(xpath = "//*[@id='bb-username-then-password-input']")
    WebElement userName;


    @FindBy(xpath = "//input[@id='username']")
    WebElement username_emp;

    @FindBy(xpath = "//*[@id='bb-username-then-password-input']")
    WebElement username_retail;

    @FindBy(xpath = "//*[@id='bb-username-then-password-input']")
    WebElement NextButton;

    @FindBy(xpath = "//*[@name='password']")
    WebElement password;

    @FindBy(xpath = "//*[@id='bb-input-password']/label")
    WebElement PasswordText;

    @FindBy(xpath = "//*[@class='col-md-8']//h1")
    WebElement MyProductHeading;

    @FindBy(xpath = "//*[@id='kc-current-locale-link']")
    WebElement LanguageClick;

    @FindBy(xpath = "//*[@id='kc-current-locale-link']//span")
    WebElement LanguageName;

    @FindBy(xpath = "//*[@id='kc-page-title']")
    WebElement PageTitle;

    @FindBy(xpath = "//*[@id='bb-username-then-password-input-required']")
    WebElement UserNameMessage;

    @FindBy(xpath = "//*[@class='alert-description']")
    WebElement PasswordAlertMessage;

    @FindBy(xpath = "//*[@id='kc-form']//*[@class='bb-input-validation-message']")
    WebElement AttemptMessage;

    @FindBy(xpath = "//*[@id='bb-toggle-password-visibility-button']")
    WebElement PasswordVisiblityBtn;

    @FindBy(xpath = "//*[@id='bb-toggle-password-visibility-button']")
    WebElement ForgetLinkBtn;


    public LoginPage_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        driver.manage().window().setSize(new Dimension(1700, 800));
    }

    public void GetMessage(String name) throws Exception {
        String UserNameMess = UserNameMessage.getAttribute("outerText");
        Assert.assertEquals(name, UserNameMess);
//		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
    }


    public void openURL() throws Exception {
        driver.manage().window().maximize();
        Thread.sleep(5000);
        driver.get(PropertiesOperations.getPropertyValueByKey("url"));
    }

    public void openURL_UAT() throws Exception {
        driver.manage().window().maximize();
        Thread.sleep(5000);
        driver.get(PropertiesOperations.getPropertyValueByKey("url_uat"));
    }

    public void openURL1(String url) throws Exception {
        driver.manage().window().maximize();
        Thread.sleep(5000);
        driver.get(PropertiesOperations.getPropertyValueByKey(url));
    }

    public void enterUsername() throws Exception {

        //wait.until(ExpectedConditions.visibilityOf(userName));
        userName.sendKeys(PropertiesOperations.getPropertyValueByKey("username"));
    }

    public void enterUsername2() throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        userName.sendKeys(PropertiesOperations.getPropertyValueByKey("username2"));
    }

    public void enterPassword2() throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        userName.sendKeys(PropertiesOperations.getPropertyValueByKey("password2"));
    }

    public void enterUsername3() throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        userName.sendKeys(PropertiesOperations.getPropertyValueByKey("username3"));
    }

    public void enterUsername4() throws Exception {
        userName.sendKeys(PropertiesOperations.getPropertyValueByKey("username4"));
    }

    public void enterUsername5() throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        userName.sendKeys(PropertiesOperations.getPropertyValueByKey("username5"));
    }

    public void enterPassword5() throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        userName.sendKeys(PropertiesOperations.getPropertyValueByKey("password5"));
    }

    public void enterUsernameEmployeeApp(String username) throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        username_emp.sendKeys(PropertiesOperations.getPropertyValueByKey(username));
    }

    public void enterUsernameRetailApp(String username) throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        username_retail.sendKeys(PropertiesOperations.getPropertyValueByKey(username));
    }

    public void enterPasswordInTextBox(String username) throws Exception {
        //wait.until(ExpectedConditions.visibilityOf(userName));
        password.sendKeys(PropertiesOperations.getPropertyValueByKey(username));
    }

    public void enterPassword(String pasword) {
        password.sendKeys(pasword);
    }

    public void clickLogin(String value) {
        var val = driver.findElement(By.xpath("//input[@name='" + value + "']"));
        val.click();

    }

    public void ClickNextButton(String value) {
        var val = driver.findElement(By.xpath("//button[@id='kc-form-buttons' and contains(text(),'" + value + "')]"));
        val.click();
    }

    public void GetText(String value) {
        String passText = PasswordText.getAttribute("outerText");
        Assert.assertEquals(value, passText);
    }


    //	public void GetText(String value)
//	{
//		String passText = PasswordText.getAttribute("outerText");
//		Assert.assertEquals(value,passText);
////		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
//	}
    public void GetMyHeadingText(String value) {
        var val = driver.findElement(By.xpath("//*[@data-role='headings' and contains(text(),'" + value + "')]"));
        try {
            Thread.sleep(5000);
            wait.until(ExpectedConditions.visibilityOf(val));
            val.isDisplayed();
        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }

    }

    public void GetLabelText(String value) {
        var val = driver.findElement(By.xpath("//label[contains(text(),'" + value + "')]/../label"));
        try {
            Thread.sleep(5000);
            wait.until(ExpectedConditions.visibilityOf(val));
            val.isDisplayed();
        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }

    }

    public void GetLanguageClick() {
        LanguageClick.click();
    }

    public void ClickLanguage(String value) {
        var val = driver.findElement(By.xpath("//*[@id='kc-locale-dropdown-menu']//a[contains(text(),'" + value + "')]"));
        val.click();
    }

    public void GetLanguageNameTitle(String value, String Title) {
        String LangName = LanguageName.getAttribute("textContent");
        System.out.println("Language is" + LangName);
        String TitleName = PageTitle.getAttribute("outerText");
        System.out.println("Language is" + TitleName);
        Assert.assertEquals(value, LangName);
        Assert.assertEquals(Title, TitleName);
    }

    public void GetErrorMessageAttempt(String value, String Title) {
        String ErrMessage = PasswordAlertMessage.getAttribute("outerText");
        System.out.println("Language is" + ErrMessage);
        String AttemptAlert = AttemptMessage.getAttribute("outerText");
        System.out.println("Language is" + AttemptAlert);
        Assert.assertEquals(value, ErrMessage);
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Assert.assertEquals(Title, AttemptAlert);
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    public void GetPasswordVisbile() {
        PasswordVisiblityBtn.click();
    }

    public void SelectContext(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-select-context__container']//*[@data-role='service-agreement-item-name']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void GetForgetLink(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-stack']/.././/span[contains(text(),'"+value+"')]"));
        try {
            Assert.assertTrue(val.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }

    }

    public void GetForgetLinkClick() {
        var val = driver.findElement(By.xpath("//*[@class='bb-stack']/.././/span[contains(text(),'Forgot credentials?')]/../.."));
        try {
            val.click();
        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }

    }
}
