package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.PropertiesOperations;
import com.adobe.s3fs.com.amazonaws.services.dynamodbv2.xspec.B;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testcontainers.shaded.org.bouncycastle.asn1.x509.V2AttributeCertificateInfoGenerator;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class Statements_Browser {
    GenericMethod genericMethod = new GenericMethod();
    WebDriver driver;
    WebDriverWait wait;

    @FindBy(xpath = "//div[@class='ng-select-container ng-has-value'][contains(.,'Select AccountsSaving Account ; Account number: SA82 5500 0000 0K42 8140 0928; Balance:$4.51')]")
    WebElement DropDown;

    @FindBy(xpath = "//button[@data-role='collapsible-filter-btn'][contains(.,'Filter')]")
    WebElement FilterBtn;

    @FindBy(xpath = "//div[@class='bb-input-datepicker__wrapper'][contains(.,'Date range')]")
    WebElement DateRange;

    @FindBy(xpath = "//body/bb-app-root[1]/ng-component[1]/bb-retail-layout[1]/div[1]/div[2]/div[2]/div[1]/div[2]/bb-account-statement-retail-journey[1]/bb-account-statement-retail-view[1]/div[2]/div[1]/bb-account-statement-statements-container[1]/div[1]/bb-account-statement-filters-container[1]/bb-account-statement-base-filters[1]/form[1]/bb-collapsible-ui[1]/div[2]/div[1]/div[1]/bb-dropdown-multi-select-ui[1]")
    WebElement CategoryRange;

    @FindBy(xpath = "//button[contains(text(),'Close')]")
    WebElement CloseBtn;

    @FindBy(xpath = "//button[contains(text(),'Apply')]")
    WebElement ApplyBtn;

    @FindBy(xpath = "//button[contains(text(),'Clear all')]")
    WebElement ClearAllBtn;

    @FindBy(xpath = "//label[@role='option'][contains(.,'PDF_FULL')]")
    WebElement CategoryOption;

    @FindBy(xpath = "//body/bb-app-root[1]/ng-component[1]/bb-retail-layout[1]/div[1]/div[2]/div[2]/div[1]/div[2]/bb-account-statement-retail-journey[1]/bb-account-statement-retail-view[1]/div[2]/div[1]/bb-account-statement-statements-container[1]/div[1]/bb-account-statement-filters-container[1]/bb-account-statement-base-filters[1]/form[1]/bb-collapsible-ui[1]/div[2]/div[1]/div[1]/div[1]/div[1]/bb-input-datepicker-ui[1]/div[1]/div[1]/ngb-datepicker[1]/div[2]/div[1]/ngb-datepicker-month[1]/div[2]/div[7]/bb-input-datepicker-range-day-template-ui[1]/time[1]")
    WebElement DateOption;

    public void DropDown_Visibility() {
        wait.until(ExpectedConditions.visibilityOf(DropDown));
        Assert.assertTrue(DropDown.isDisplayed());
    }

    public void Click_OnDropDown() {
        wait.until(ExpectedConditions.visibilityOf(DropDown));
        Assert.assertTrue(DropDown.isDisplayed());
        DropDown.click();
    }

    public void Verify_Data(String Date, String Category) {
        var val = driver.findElement(By.xpath("(//td[@data-role='date-td'][contains(.,'" + Date + "')])/..//td[@data-role='category-td'][contains(.,'" + Category + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void Verify_PreviewIcon() {
        var val = driver.findElement(By.xpath("//tbody/tr[1]/td[4]/bb-account-statement-view-online[1]/div[1]/button[1]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void Verify_DownloadIcon() {
        var val = driver.findElement(By.xpath("//tbody/tr[1]/td[5]/bb-account-statement-downloads[1]/div[1]/button[1]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void Click_FilterBtn() {
        wait.until(ExpectedConditions.visibilityOf(FilterBtn));
        Assert.assertTrue(FilterBtn.isDisplayed());
        FilterBtn.click();
    }

    public void Verify_DateRange() {
        wait.until(ExpectedConditions.visibilityOf(DateRange));
        Assert.assertTrue(DateRange.isDisplayed());
    }

    public void Verify_CategoryRange() {
        wait.until(ExpectedConditions.visibilityOf(CategoryRange));
        Assert.assertTrue(CategoryRange.isDisplayed());
    }

    public void Verify_CloseBtn() {
        wait.until(ExpectedConditions.visibilityOf(CloseBtn));
        Assert.assertTrue(CloseBtn.isDisplayed());
    }

    public void Verify_ApplyBtn() {
        wait.until(ExpectedConditions.visibilityOf(ApplyBtn));
        Assert.assertTrue(ApplyBtn.isDisplayed());
    }

    public void Verify_ClearAllBtn() {
        wait.until(ExpectedConditions.visibilityOf(ClearAllBtn));
        Assert.assertTrue(ClearAllBtn.isDisplayed());
    }

    public void ClickOn_ApplytBtn() {
        wait.until(ExpectedConditions.visibilityOf(ApplyBtn));
        Assert.assertTrue(ApplyBtn.isDisplayed());
        ApplyBtn.click();
    }

    public void ClickOn_Category() {
        wait.until(ExpectedConditions.visibilityOf(CategoryRange));
        Assert.assertTrue(CategoryRange.isDisplayed());
        CategoryRange.click();
    }

    public void Select_Category() {
        wait.until(ExpectedConditions.visibilityOf(CategoryOption));
        Assert.assertTrue(CategoryOption.isDisplayed());
        CategoryOption.click();
    }

    public void Select_Date() {
        wait.until(ExpectedConditions.visibilityOf(DateOption));
        Assert.assertTrue(DateOption.isDisplayed());
        DateOption.click();
    }


}
