package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import com.adobe.s3fs.com.amazonaws.services.dynamodbv2.xspec.B;
import com.adobe.s3fs.com.amazonaws.services.dynamodbv2.xspec.S;
import io.cucumber.java.af.En;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;

import java.awt.*;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static Utils.PropertiesOperations.getPropertyValueByKey;

public class Domestic_Transfer {

    WebDriver driver;
    WebDriverWait wait;
    public Domestic_Transfer() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//*[@class='ng-untouched ng-pristine ng-invalid ng-star-inserted']//*[@class='bb-block bb-block--lg']")
    WebElement NormalTransaction;


    @FindBy(xpath = "//input[@name='integer'][contains(@id,'22')]")
    WebElement BillPayAmountInput;

    @FindBy(xpath = "//input[@id='bb_element_16']")
    WebElement EnterAmount;
    @FindBy(xpath = "//textarea[@id='bb_input_3']")
    WebElement EnterNote;

    @FindBy(xpath = "//*[@label='Purpose']//*[@data-role='dropdown']")
    WebElement DropDownPurpose;

    @FindBy(xpath = "//*[@placeholder='Please enter a purpose' and @data-role='input']")
    WebElement OtherPurposeFieldTextBox;


    public void ClickTransferTo() {
        wait.until(ExpectedConditions.visibilityOf(NormalTransaction));
        NormalTransaction.isDisplayed();
    }

    public void OtherPurposeField(String value) {
        wait.until(ExpectedConditions.visibilityOf(OtherPurposeFieldTextBox));
        OtherPurposeFieldTextBox.isDisplayed();
        OtherPurposeFieldTextBox.isDisplayed();
    }
    public void ClicksOtherPurposeField() {
        wait.until(ExpectedConditions.visibilityOf(OtherPurposeFieldTextBox));
        OtherPurposeFieldTextBox.isDisplayed();
        OtherPurposeFieldTextBox.click();
    }

    public void GetAccountAlias(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-dropdown-panel-items scroll-host']//*[contains(text(),'" + value + "')]/../../..//div[@data-role='card-title']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void GetAvailableBalanceLabel(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-dropdown-panel-items scroll-host']//*[contains(text(),'" + value + "')]/../../..//div[@data-role='card-sub-title']//span"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void GetSymbolDisplayed(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-dropdown-panel-items scroll-host']//*[contains(text(),'" + value + "')]/../../../../../..//span[@class='symbol']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        var textval = val.getAttribute("outerText");
        textval.contentEquals("€");
    }

    public void GetAmount(String value, String amount) {
        var val = driver.findElement(By.xpath("//*[@class='ng-dropdown-panel-items scroll-host']//*[contains(text(),'" + value + "')]/../../../../../..//span[@class='symbol']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        String[] textval = val.getAttribute("textContent").split("0");
        textval[0].contentEquals(amount);
    }

    public void GetBeneficiaryName(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-dropdown-panel-items scroll-host']//*[contains(text(),'" + value + "')]/../../..//span[@data-role='list-name']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void DropdownPurpose(String value) {
        wait.until(ExpectedConditions.visibilityOf(DropDownPurpose));
        Select dropdown = new Select(DropDownPurpose);
        dropdown.selectByVisibleText(value);
    }


    public void BeneficiaryAccountNumber(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-dropdown-panel-items scroll-host']//*[contains(text(),'" + value + "')]/../..//span[@data-role='list-account-number']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void UserInputsAmount(String value) {
        wait.until(ExpectedConditions.visibilityOf(BillPayAmountInput));
        BillPayAmountInput.sendKeys(value);
    }

    public void UserClicksAmountField() {
        wait.until(ExpectedConditions.visibilityOf(BillPayAmountInput));
        BillPayAmountInput.isDisplayed();
        BillPayAmountInput.click();
    }

    public void UserSelectsAccount(String value) throws Exception {
        var value1 = getPropertyValueByKey("transfers",value);
        WebElement val;

        System.out.println("**************************");
        System.out.println("**************************");
        System.out.println("**************************");
        System.out.println("value: " +value);
        System.out.println("value1: " +value1);
        System.out.println("**************************");
        System.out.println("**************************");
        System.out.println("**************************");

        if(value.equals("acc_amount_zero"))
        {
            val = driver.findElement(By.xpath("//div[@class='bb-product-selector__dropdown-menu-panel dropdown-menu show']//div[@class='bb-ellipsis bb-ellipsis--single-line'][normalize-space()='"+value1+"']"));
        }else
        {
            val = driver.findElement(By.xpath("//div[@class='bb-product-selector__dropdown-menu-panel dropdown-menu show']//div[@class='bb-ellipsis bb-ellipsis--single-line'][normalize-space()='"+value1+"']"));
        }
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
        try{
            val.click();
        }catch (Exception e) {
            System.out.println(e);
            Thread.sleep(3000);
        }
    }
    public void UserSelectsToAccount(String value) throws Exception {
//        wait.until(ExpectedConditions.visibilityOf(FirstAccount));
        var value1 = getPropertyValueByKey("transfers",value);
        var val = driver.findElement(By.xpath("(//*[@data-role='bb-amount-value']//span[contains(text(),'" + value1 + "')])[3]"));
//        Thread.sleep(3000);
//        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
        val.click();
    }

    public void USerEnterAmount(String value) {
        wait.until(ExpectedConditions.visibilityOf(EnterAmount));
//        EnterAmount.isDisplayed();
        EnterAmount.sendKeys(value);
    }
    public void USerVerifyAmount(String value) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", EnterAmount);
        wait.until(ExpectedConditions.visibilityOf(EnterAmount));
        Assert.assertEquals(value,EnterAmount.getText());
    }
    public void UserWritesNote (String value) {
        wait.until(ExpectedConditions.visibilityOf(EnterNote));
        EnterNote.isDisplayed();
        EnterNote.sendKeys(value);
    }
    public void UserIsOnScreen(String value) {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }
    public void UserIsNotOnScreen(String value) {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertFalse(val.isDisplayed());
    }
    public void UserClicksOnBtn(String value) {
        try {
            var val = driver.findElement(By.xpath("//*[normalize-space()='" + value + "']"));
            wait.until(ExpectedConditions.visibilityOf(val));
            val.click();
        }catch (Exception Ex){
            var val = driver.findElement(By.xpath("//button[@class='bb-button-bar__button btn-secondary btn btn-md'][normalize-space()='" + value + "']"));
            wait.until(ExpectedConditions.visibilityOf(val));
            val.click();
        }
    }
    public void USerSeeCurrencyUnit(String value) {
//        wait.until(ExpectedConditions.visibilityOf(FirstAccount));
        var val = driver.findElement(By.xpath("//input[@id='bb_element_13']")).getText();
        System.out.println("xpath value: "+val);

        Select drpCountry = new Select(driver.findElement(By.xpath("//input[@id='bb_element_12']")));
        var options_dd = drpCountry.getOptions();
        System.out.println(options_dd);
//        drpCountry.selectByVisibleText(value);
//        Select drpCountry = new Select(driver.findElement(By.name("country")));
//        Assert.assertEquals(value, val);
    }

    public void ErrorDisplayed(String value) {
//        wait.until(ExpectedConditions.visibilityOf(FirstAccount));
        var val = driver.findElement(By.xpath("//span[@data-role='required-error' and contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void ElementGetsClicked(String value) throws Exception {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
        Thread.sleep(3000);
    }

    public void BeneficiaryBankName(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-dropdown-panel-items scroll-host']//*[contains(text(),'" + value + "')]/../..//span[@data-role='list-bank-name']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }


}
