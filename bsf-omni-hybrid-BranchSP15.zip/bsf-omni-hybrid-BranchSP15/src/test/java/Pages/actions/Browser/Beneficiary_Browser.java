package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.*;
import Utils.PropertiesOperations;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.w3c.dom.Element;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.*;

public class Beneficiary_Browser {

    WebDriver driver;
    WebDriverWait wait;

    GenericMethod generics;
    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button'][1]//span[@data-role='list-name']")
    WebElement BeneficiaryName;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button'][1]//span[@data-role='list-account-number']")
    WebElement AccountNumber;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button'][1]//span[@data-role='list-bank-name']")
    WebElement BankName;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button']//span[@class='badge badge-secondary' and contains(text(),'Inactive')]")
    List<WebElement> InactiveStatus;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button']//*[@data-role='list-account-number']")
    List<WebElement> LocalBankInactiveStatus;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button'][1]")
    WebElement FirstBeneficiary;

    @FindBy(xpath = "//*[@data-role='create-new-beneficiary-label']//h3")
    WebElement FullNameAsHeading;

    @FindBy(xpath = "//*[@class='col col-lg-6 beneficiary-details-container']//*[@heading='Beneficiary type']/../div")
    WebElement BeneficiaryType;

    @FindBy(xpath = "//*[@class='col col-lg-6 beneficiary-details-container']//*[@heading='Full name']/../div")
    WebElement BeneficiaryFullName;

    @FindBy(xpath = "//*[@class='col col-lg-6 beneficiary-details-container']//*[@heading='Account number or IBAN']/../div")
    WebElement BeneficiaryAccountNumber;

    @FindBy(xpath = "//*[@class='col col-lg-6 beneficiary-details-container']//*[@heading='Bank']/../div")
    WebElement BeneficiaryBank;

    @FindBy(xpath = "//*[@data-role='delete-button']")
    WebElement DeleteIcon;

    @FindBy(xpath = "//*[@data-role='confirm-delete-button']/..")
    WebElement DeleteBtn;

    @FindBy(xpath = "//*[@class='col col-lg-6 beneficiary-details-container']//*[@data-role='activate-beneficiary-button']")
    WebElement ActivateBeneficiaryBtn;

    @FindBy(xpath = "//span[@class='bb-switch__element bb-switch__element--checked']")
    WebElement SwiftToggleBtn;
    @FindBy(xpath = "//p[@class='bb-empty-state__message ng-star-inserted']")
    WebElement NotificationDetails;
    @FindBy(xpath = "(//*[contains(text(),'Manage Notifications')])[last()]")
    WebElement ElementIsDisplayed;

    @FindBy(xpath = "(//*[contains(text(),'Notification details')])[last()]")
    WebElement Noti_Details_Header;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button']//span[@data-role='list-account-number' and contains(text(),'N0047500161')]")
    List<WebElement> DeleteAccount;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button']//span[@data-role='list-account-number' and contains(text(),'N0012422148')]")
    List<WebElement> DeleteAccountBSF;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button']//span[@data-role='list-account-number' and contains(text(),'SA4720000002352623169940')]")
    List<WebElement> DeleteLocalAccount;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@role='button']//span[@data-role='list-account-number' and contains(text(),'K0816602250')]")
    List<WebElement> DeleteBSFAccount;

    @FindBy(xpath = "//*[@data-role='new-beneficiary-button']")
    WebElement AddNewBeneficiaries;

    @FindBy(xpath = "//*[@data-role='dropdown']")
    WebElement BeneficiaryTypeDropdown;

    @FindBy(xpath = "/html/body/bb-app-root/ng-component/bb-retail-layout/div/div[2]/div[2]/div/div[2]/bb-beneficiary-manager-journey/bb-beneficiary-list-container/div/div[3]/div[2]/bb-beneficiary-manager-form-view/bb-beneficiary-form-container/bb-beneficiary-form/form/div[1]/div[1]/bb-switch-ui/div/span/span")
    WebElement BeneficiaryToggleBtn;

    @FindBy(xpath = "//*[@data-role='new-beneficiary-iban']/input")
    WebElement InputBeneficiaryAccountNumber;

    @FindBy(xpath = "//input[@id='bb-create-accountNumber-name']")
    WebElement BeneficiaryFullname;

    @FindBy(xpath = "//*[@class='col col-lg-6 beneficiary-details-container']")
    WebElement BeneficiaryForm;

    @FindBy(xpath = "//*[@data-role='new-accountNumber-name']/input")
    WebElement InputFullName;

    @FindBy(xpath = "//*[@class='ng-star-inserted']//label[contains(text(),'Banque Saudi Fransi')]/..//input")
    WebElement ToggleBtnOff;

    @FindBy(xpath = "//*[@data-role='beneficiary-manager-list-item']")
    List<WebElement> ActiveStatus;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@data-role='beneficiary-manager-list-item'][1]//*[@role='img']")
    WebElement BeneficiaryIcon;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@data-role='beneficiary-manager-list-item'][1]//*[@data-role='list-name']")
    WebElement BeneficiaryfullName;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@data-role='beneficiary-manager-list-item'][1]//*[@data-role='list-account-number']")
    WebElement BeneficiaryaccountNumber;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@data-role='beneficiary-manager-list-item'][1]//*[@data-role='list-bank-name']")
    WebElement BeneficiarybankName;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@data-role='beneficiary-manager-list-item'][1]//*[@class='badge badge-secondary']")
    WebElement BeneficiaryinactiveIcon;

    @FindBy(xpath = "//*[@data-role='dropdown']")
    WebElement SelectBank;

    @FindBy(xpath = "//label[contains(text(),'Country of residency')]/..//*[@data-role='search-input']")
    WebElement SearchBarElement;

    @FindBy(xpath = "//label[contains(text(),'Country of the bank')]/..//*[@data-role='search-input']")
    WebElement SearchBarElementForBank;
    @FindBy(xpath = "//*[@role='option']//div//span")
    List<WebElement> countries_names;

    @FindBy(xpath = "//*[@role='option']//div//*[contains(@class, 'flag-icon')]")
    List<WebElement> countries_flags;

    @FindAll(@FindBy(xpath = "//*[@role='listbox']//div[@role='option']"))
    List<WebElement> ContriesListElement;

    @FindBy(xpath = "//*[@data-role='beneficiary-manager-search']//input")
    WebElement SearchBSFElement;

    @FindBy(xpath = "//*[@data-role='existing-beneficiary']//li[@data-role='beneficiary-manager-list-item']")
    WebElement SearchBSFElementResult;
    public Beneficiary_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        generics = new GenericMethod();
        // driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void VerifyBeneficiaryName() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryName));
        BeneficiaryName.isDisplayed();
    }

    public void VerifyAccountNumber() {

        wait.until(ExpectedConditions.visibilityOf(AccountNumber));
        AccountNumber.isDisplayed();
    }

    public void VerifyBankName() {

        wait.until(ExpectedConditions.visibilityOf(BankName));
        BankName.isDisplayed();
    }

    public void VerifyInactiveStatus() {

        for (WebElement webElement : InactiveStatus) {
            webElement.isDisplayed();
        }
    }

    public void ClickFirstBeneficiary() {
        wait.until(ExpectedConditions.visibilityOf(FirstBeneficiary));
        FirstBeneficiary.click();
    }

    public void GetFullNameAsHeading() {

        wait.until(ExpectedConditions.visibilityOf(FullNameAsHeading));
        FullNameAsHeading.isDisplayed();
    }

    public void GetBeneficiaryType() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryType));
        BeneficiaryType.isDisplayed();
    }

    public void GetBeneficiaryFullName() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryFullName));
        BeneficiaryFullName.isDisplayed();
    }

    public void GetBBeneficiaryAccountNumber() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryAccountNumber));
        BeneficiaryAccountNumber.isDisplayed();
    }

    public void GetBeneficiaryBank() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryBank));
        BeneficiaryBank.isDisplayed();
    }

    public void GetBeneficiaryDeleteIcon() {

        wait.until(ExpectedConditions.visibilityOf(DeleteIcon));
        DeleteIcon.isDisplayed();
    }

    public void ClickInactiveStatus() {

        for (WebElement webElement : InactiveStatus) {
            webElement.click();
            break;
        }

    }

    public void ClickLocalInactiveStatus() {

        for (WebElement webElement : InactiveStatus) {
            if (LocalBankInactiveStatus.contains("BSF")) {
                webElement.click();
                break;
            }
        }

    }

    public void ClickActivateBeneficiaryBtn() {

        wait.until(ExpectedConditions.visibilityOf(ActivateBeneficiaryBtn));
        ActivateBeneficiaryBtn.isDisplayed();

    }

    public void DeleteAccountNumber() {

        if (DeleteAccount.size() > 0) {
            for (WebElement webElement : DeleteAccount) {
                webElement.click();
                break;
            }
            DeleteIcon.click();
            DeleteBtn.click();
        } else {
            AddNewBeneficiaries.isEnabled();
        }
    }

    public void DeleteAccountNumberBSF() {

        if (DeleteAccountBSF.size() > 0) {
            for (WebElement webElement : DeleteAccountBSF) {
                wait.until(ExpectedConditions.visibilityOf(webElement));
                webElement.click();
                break;
            }
            DeleteIcon.click();
            DeleteBtn.click();
        } else {
            AddNewBeneficiaries.isEnabled();
        }
    }

    public void DeleteLocalAccountNumber() {
        if (DeleteLocalAccount.size() > 0) {
            for (WebElement webElement : DeleteLocalAccount) {
                webElement.click();
                break;
            }
            DeleteIcon.click();
            DeleteBtn.click();
        } else {
            AddNewBeneficiaries.isEnabled();
        }
    }

    public void DeleteBSFAccountNumber() {
        if (DeleteBSFAccount.size() > 0) {
            for (WebElement webElement : DeleteBSFAccount) {
                webElement.click();
                break;
            }
            DeleteIcon.click();
            DeleteBtn.click();
        } else {
            AddNewBeneficiaries.isEnabled();
        }
    }

    public void ClickAddNewBeneficiary() {

        wait.until(ExpectedConditions.visibilityOf(AddNewBeneficiaries));
        AddNewBeneficiaries.isEnabled();
        AddNewBeneficiaries.click();
    }

    public void SelectNewBeneficiaryType(String value) {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryTypeDropdown));
        Select drpBeneficiary = new Select(BeneficiaryTypeDropdown);
        drpBeneficiary.selectByVisibleText(value);

    }

    public void ToggleBtnOff() {
        wait.until(ExpectedConditions.visibilityOf(SwiftToggleBtn));
        SwiftToggleBtn.click();
    }

    public void ElementIsDisplayed(String value) {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void ElementIsDisplay() {
//        var val = driver.findElement(By.xpath(""));
        wait.until(ExpectedConditions.visibilityOf(ElementIsDisplayed));
        Assert.assertTrue(ElementIsDisplayed.isDisplayed());
    }

    public void NotificationDetailsHeader() {
        wait.until(ExpectedConditions.visibilityOf(Noti_Details_Header));
        Assert.assertTrue(Noti_Details_Header.isDisplayed());
    }

    public void ElementDetailIsDisplayed(String value) {
        wait.until(ExpectedConditions.visibilityOf(NotificationDetails));
        Assert.assertTrue(NotificationDetails.isDisplayed());
    }

    public void SelectFromDropDown(String value) {
        wait.until(ExpectedConditions.visibilityOf(SelectBank));
        Select dropdown = new Select(SelectBank);
        dropdown.selectByVisibleText(value);
    }

    public void SearchElement(String value) {
        wait.until(ExpectedConditions.visibilityOf(SearchBarElement));
        SearchBarElement.sendKeys(value);
    }

    public void SearchElementForBank(String value) {
        wait.until(ExpectedConditions.visibilityOf(SearchBarElementForBank));
        SearchBarElementForBank.sendKeys(value);
    }

    public void ContriesList() {
        if (!ContriesListElement.isEmpty()) {
            System.out.println("Verification of dropdown displays content");
            Assert.assertFalse(ContriesListElement.isEmpty());
        } else {
            System.out.println("Verification of dropdown gets closed");
            Assert.assertTrue(ContriesListElement.isEmpty());
        }
    }

    public void ElementIsClicked(String value) throws Exception {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
        Thread.sleep(3000);
        generics.scrollToTop(driver);
    }

    public void ScrollToTop() throws Exception {
        generics.scrollToTop(driver);
        Thread.sleep(3000);
    }

    public void ComboBoxIsClicked(String value) {
        try {
            WebElement val;
            if (value.equals("Country of residency")) {
                val = driver.findElement(By.xpath("//ng-select[@aria-label='" + value + "']"));
            } else {
                val = driver.findElement(By.xpath("//ng-select[@aria-label='" + value + "']"));
            }
            wait.until(ExpectedConditions.visibilityOf(val));
            val.click();

        } catch (Exception ex) {
            System.out.println(ex);
        }

    }

    public void ErrorMessageDisplayed(String value) {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }
    public void UserShouldBeAbleToReview (String value) {
        var val = driver.findElement(By.xpath("//*[normalize-space()='"+value+"']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void ElementSelected(String value) {

        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();

    }

    public void ElementVerify() {

        var countries_count = countries_names.size();
        var countries_flag_count = countries_flags.size();
        if (countries_count > 0) {
            for (int i = 0; i < countries_names.size(); i++) {
                wait.until(ExpectedConditions.visibilityOf(countries_names.get(i)));
            }
            Assert.assertEquals(countries_count, countries_flag_count);
        } else {
            System.out.println("Countries and there Flags are not getting displayed ");
            Assert.fail();
        }
    }

    public void TextBoxIsDisplayed(String value) {

        var val = driver.findElement(By.xpath("//*[@placeholder='" + value + "']/input"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());

    }

    public void InputValue(String value1, String value2) throws Exception {
        try {
            WebElement val;
            if (value1.equals("Enter swift code") || value1.equals("Enter ABA") || value1.equals("Enter IFSC") || value1.equals("Enter sort code") || value1.equals("Enter BSB") || value1.equals("Enter transit number")) {
                val = driver.findElement(By.xpath("//*[@placeholder='" + value1 + "']"));
            } else {
                val = driver.findElement(By.xpath("//*[@placeholder='" + value1 + "']/input"));
            }
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);
            wait.until(ExpectedConditions.visibilityOf(val));
            if (value2.equals("Null")) {
                String s = Keys.chord(Keys.CONTROL, "a");
                val.sendKeys(s);
                // sending DELETE key
                val.sendKeys(Keys.DELETE);
                Thread.sleep(3000);
            } else {
                val.sendKeys(PropertiesOperations.getPropertyValueByKey("internationalBeneficiaryAccount",value2));
                Thread.sleep(3000);
                System.out.println(value2);
            }
        } catch (Exception e) {
            throw new Exception("Error" + e);
        }

    }

    public void BeneficiaryToggleBtnOn() throws InterruptedException {

        JavascriptExecutor executor = (JavascriptExecutor) driver;
        executor.executeScript("window.scrollBy(0,-250)");
        Thread.sleep(5000);
        executor.executeScript("arguments[0].click();", BeneficiaryToggleBtn);

    }

    public void InputBeneficiaryAccount(String value) {

        wait.until(ExpectedConditions.visibilityOf(InputBeneficiaryAccountNumber));

        try {
            Thread.sleep(10000);
            InputBeneficiaryAccountNumber.sendKeys(value);

        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }
    }

    public void BeneficiaryDetailBtn(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-button-bar bb-button-bar--spacing-sm']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isEnabled();
        val.click();
    }

    public void BeneficiaryFieldDisabled(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-untouched ng-pristine ng-star-inserted']//*[contains(text(),'" + value + "')]/..//input"));
        wait.until(ExpectedConditions.visibilityOf(val));
        assertFalse(val.isEnabled());

//        boolean disable = val.isEnabled();
//        System.out.println(disable);
//        if (!disable) {
//            val.click();
//        }
    }

    public void BeneficiaryPopupHeaderText(String value) throws InterruptedException {
        Thread.sleep(3000);
        var val = driver.findElement(By.xpath("//*[@class='modal-header']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isEnabled();
        val.click();
    }

    public void BeneficiaryPopupHeaderBtn(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-button-bar' or @class='modal-footer']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isEnabled();
        val.click();
    }

    public void DefinedBeneficiary(String value) throws InterruptedException {
        Thread.sleep(5000);
        var val = driver.findElement(By.xpath("//*[@data-role='existing-beneficiary']//span[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void GetBeneficiaryDetailName(String value) {
        var val = driver.findElement(By.xpath("//*[@class='col col-lg-6 beneficiary-details-container']//*[@heading='" + value + "']/../div"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void CheckBtn() {

        boolean btn = AddNewBeneficiaries.isEnabled();
        if (!btn) {
            System.out.println("Button is not visible");
        }

    }

    public void GetFieldBeneficiaries(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-star-inserted']//label[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void InputInvalidBeneficiaryAccount() {

        wait.until(ExpectedConditions.visibilityOf(InputBeneficiaryAccountNumber));
        Assert.assertFalse(InputBeneficiaryAccountNumber.getAttribute("value").contains("[a-zA-Z0-9]+") && InputBeneficiaryAccountNumber.getAttribute("value").contains("[0-9]+"));
    }

    public void GetAlphanumericValue(String value) {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryFullname));
        BeneficiaryFullname.sendKeys(value);
    }

    public void GetAlertMessage(String name, String value) {
        var val = driver.findElement(By.xpath("//*[@role='alert']//span[contains(text(),'" + value + "')]"));
        var FieldName = driver.findElement(By.xpath("//*[@class='row']//label[contains(text(),'" + name + "')]"));
        wait.until(ExpectedConditions.visibilityOf(FieldName));
        wait.until(ExpectedConditions.visibilityOf(val));
        FieldName.isDisplayed();
        val.isDisplayed();
        String message = val.getText();
        System.out.println(message);
        Assert.assertEquals(message, value);
    }

    public void GetBeneficiaryForm() {
        wait.until(ExpectedConditions.visibilityOf(BeneficiaryForm));
        boolean Form = BeneficiaryForm.isDisplayed();
        assertTrue(Form);
    }

    public void InputBFullName(String value) {

        wait.until(ExpectedConditions.visibilityOf(InputFullName));

        try {
            Thread.sleep(10000);
            InputFullName.sendKeys(value);

        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }
    }

    public void GetAddBeneficiaryFieldName(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-star-inserted']//label[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void ToggleButtonDefault() {
        String amount = ToggleBtnOff.getAttribute("ariaChecked");

        if (amount.contains("false")) {
            assertEquals(amount, "false");
        } else {
            assertEquals(amount, "true");
        }
    }

    public void ClickActiveStatus() {

        WebElement element = driver.findElement(By.xpath("//*[@class='bb-block row']"));

        for (int i = 0; i < ActiveStatus.size(); i++) {
            if (element.getAttribute("textContent").contains("active")) {
                System.out.println(element.getSize());
                element.click();
                break;
            }
            break;

        }
    }

    public void DisplayBeniIcon() {

        //wait.until(ExpectedConditions.visibilityOf(BeneficiaryIcon));
        BeneficiaryIcon.isDisplayed();
    }

    public void DisplayBeniFullName() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryfullName));
        BeneficiaryfullName.isDisplayed();
    }

    public void DisplayBeneficiaryaccountNumber() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryaccountNumber));
        BeneficiaryaccountNumber.isDisplayed();
    }

    public void DisplayBeneficiarybankName() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiarybankName));
        BeneficiarybankName.isDisplayed();
    }

    public void DisplayBeneficiaryinactiveIcon() {

        wait.until(ExpectedConditions.visibilityOf(BeneficiaryinactiveIcon));
        BeneficiaryinactiveIcon.isDisplayed();
    }

    public void GetBeniType(String value) {
        var val = driver.findElement(By.xpath("//*[@class='col col-lg-6 beneficiary-details-container']//*[@heading='Beneficiary type']//..//div[contains(text(),'" + value + "')]")).getText();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        assertEquals(val, value);
    }

    public void GetBeniDetail(String value) {
        var val = driver.findElement(By.xpath("//*[@class='col col-lg-6 beneficiary-details-container']//*[@heading='" + value + "']")).getText();
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        assertEquals(val, value);
    }

    public void SearchElementBSF(String value) {
        try{
            Assert.assertTrue(SearchBSFElement.isEnabled());
            SearchBSFElement.sendKeys(value);
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void SearchElementBSFView(String value) {

        var val = driver.findElement(By.xpath("//*[@data-role='existing-beneficiary']//li[@data-role='beneficiary-manager-list-item']//span[contains(text(),'"+value+"')]"));

        try{
            Assert.assertTrue(SearchBSFElementResult.isDisplayed());
            Assert.assertTrue(val.isDisplayed());
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

}