package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import Utils.GenericMethod;
import Utils.PropertiesOperations;
import com.adobe.s3fs.com.amazonaws.services.dynamodbv2.xspec.B;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testcontainers.shaded.org.bouncycastle.asn1.x509.V2AttributeCertificateInfoGenerator;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class Notifications_Browser {
    GenericMethod genericMethod = new GenericMethod();
    WebDriver driver;
    WebDriverWait wait;
    @FindBy(xpath = "//em[@class='bb-icon bb-icon-notifications bb-icon--lg bb-icon--secondary']")
    WebElement BellIcon;

    @FindBy(xpath = "//body/bb-app-root[1]/ng-component[1]/bb-retail-layout[1]/div[1]/div[2]/div[2]/div[1]/div[2]/bb-product-notifications-settings[1]/bb-actions-product-notifications-settings-container[1]/bb-actions-product-settings-page[1]/div[1]/bb-actions-account-balance-recipe-form[1]/form[1]/bb-collapsible-ui[1]/div[1]/div[1]/bb-switch-with-loading[1]/bb-switch-ui[1]/div[1]/span[1]")
    WebElement ToggleBtn;

    @FindBy(xpath = "//body/bb-app-root[1]/ng-component[1]/bb-retail-layout[1]/div[1]/div[2]/div[2]/div[1]/div[2]/bb-product-notifications-settings[1]/bb-actions-product-notifications-settings-container[1]/bb-actions-product-settings-page[1]/div[2]/bb-actions-transactions-recipe-form[1]/form[1]/bb-collapsible-ui[1]/div[1]/div[1]/bb-switch-with-loading[1]/bb-switch-ui[1]/div[1]/span[1]")
    WebElement CreditToggleBtn;

    @FindBy(xpath = "//header/button[1]/bb-icon-ui[1]/em[1]")
    WebElement SettingsIcon;
    @FindBy(xpath = "//span[@class='bb-heading-3' and contains(text(),'Notifications')]")
    WebElement NotificationsHeading;
    @FindBy(xpath = "//em[@class='bb-icon bb-icon-notifications-off bb-icon--xxl']")
    WebElement NoNotificationsImg;

    @FindBy(xpath = "//h1[contains(text(),'Manage Notifications')]")
    WebElement ElementIsDisplayed;

    @FindBy(xpath = "//em[contains(@class,'bb-icon bb-icon-edit bb-icon--md')]")
    WebElement EditIcon;

    @FindBy(xpath = "//button[contains(@color,'success')]")
    WebElement AcceptBtn;

    @FindBy(xpath = "//input[contains(@class,'form-control ng-pristine ng-valid ng-touched')]")
    WebElement InputField;

    public Notifications_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

    }

    public void BellIconIsClicked() {
        wait.until(ExpectedConditions.visibilityOf(BellIcon));
        Assert.assertTrue(BellIcon.isDisplayed());
        BellIcon.click();
    }

    public void ClickToggleBtn() {

            wait.until(ExpectedConditions.visibilityOf(ToggleBtn));
            Assert.assertTrue(ToggleBtn.isDisplayed());
            ToggleBtn.click();
    }

    public void click_Credit_toggle_btn() {

        wait.until(ExpectedConditions.visibilityOf(CreditToggleBtn));
        Assert.assertTrue(CreditToggleBtn.isDisplayed());
        CreditToggleBtn.click();
    }

    public void NotificationsHeadingIsDisplayed() {
        wait.until(ExpectedConditions.visibilityOf(NotificationsHeading));
        Assert.assertTrue(NotificationsHeading.isDisplayed());
    }

    public void NoNotificationsImageIsDisplayed() {
        wait.until(ExpectedConditions.visibilityOf(NoNotificationsImg));
        Assert.assertTrue(NoNotificationsImg.isDisplayed());
    }

    public void SettingsIconIsClicked() {

        wait.until(ExpectedConditions.visibilityOf(SettingsIcon));
        Assert.assertTrue(SettingsIcon.isDisplayed());
        SettingsIcon.click();
    }

    public void ElementIsDisplayedAcross(String value, String value1) {

        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]//ancestor::div[@class='bb-account-info']//*[contains(text(),'" + value1 + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());

    }

    public void AccountBalanceIsDisplayedAcross(String value, String value1) {

        var val = driver.findElement(By.xpath("(//*[contains(text(),'" + value + "')]//ancestor::div//*[contains(text(),'" + value1 + "')])[last()]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());

    }

    public void ElementIsDisplay() {
//        var val = driver.findElement(By.xpath(""));
        wait.until(ExpectedConditions.visibilityOf(ElementIsDisplayed));
        Assert.assertTrue(ElementIsDisplayed.isDisplayed());
    }

    public void CurrentAccountsDisp() {
        var val = driver.findElement(By.xpath("//body/bb-app-root[1]/ng-component[1]/bb-retail-layout[1]/div[1]/div[2]/div[2]/div[1]/div[2]/bb-actions-retail-notification-preferences[1]/div[1]/bb-product-summary-list-widget[1]/bb-product-kind-collapsible-ui[1]/div[1]/div[1]/div[1]/bb-product-kind-name[1]/bb-ellipsis-ui[1]/div[1]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void SavingsAccountsDisp() {
        var val = driver.findElement(By.xpath("//body/bb-app-root[1]/ng-component[1]/bb-retail-layout[1]/div[1]/div[2]/div[2]/div[1]/div[2]/bb-actions-retail-notification-preferences[1]/div[1]/bb-product-summary-list-widget[1]/bb-product-kind-collapsible-ui[2]/div[1]/div[1]/div[1]/bb-product-kind-name[1]/bb-ellipsis-ui[1]/div[1]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void Edit_Btn_Click() {
        wait.until(ExpectedConditions.visibilityOf(EditIcon));
        Assert.assertTrue(EditIcon.isDisplayed());
        EditIcon.click();
    }

    public void ClearInputField() {
        var InputLabel = driver.findElement(By.xpath("//input[contains(@class,'form-control ng-pristine ng-valid ng-touched')]"));
//        wait.until(ExpectedConditions.visibilityOf(InputLabel));
//        try {
            InputLabel.clear();
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
    }

    public void ClickAcceptBtn() {
        wait.until(ExpectedConditions.visibilityOf(AcceptBtn));
        AcceptBtn.click();
    }

    public void enterAmount(String amount) {
        Assert.assertTrue(InputField.isEnabled());
        InputField.sendKeys(amount);
    }

    public void LowerThan_Symbol_And_Amount(String symbol, String amount) {

        var val = driver.findElement(By.xpath("//span[contains(@class,'symbol')][contains(text(),'" + symbol + "')]/..//span[contains(@class,'integer')][contains(text(),'" + amount + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());

    }

    public void LowerThanFieldIsDisplayed() {
        var val = driver.findElement(By.xpath("//input[contains(@class,'form-control ng-pristine ng-valid ng-touched')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

}
