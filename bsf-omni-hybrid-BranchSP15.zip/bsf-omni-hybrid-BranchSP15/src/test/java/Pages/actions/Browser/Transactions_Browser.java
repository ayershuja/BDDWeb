package Pages.actions.Browser;

import DriverManager.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Transactions_Browser {

    WebDriver driver;

    WebDriverWait wait;

    public Transactions_Browser() {
        this.driver = (WebDriver) Driver.driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//span[contains(text(),'Transactions')]")
    WebElement TransactionPage;

    //*[@data-role='search-input']

    @FindBy(xpath = "//*[@data-role='search-input']")
    WebElement EnterTransactions;

    @FindBy(xpath = "//*[@data-role='bb-clear-button']")
    WebElement CancelTransactionSearch;

    @FindBy(xpath = "//*[@data-role='filter']")
    WebElement TransactionFilter;

    @FindBy(xpath = "//*[@class='bb-transactions-list-filter ng-star-inserted']")
    WebElement TransactionFilterOptions;

    @FindBy(xpath = "//*[@class='bb-input-datepicker__wrapper']//*[contains(text(),'Start date')]")
    WebElement TransactionFilterOptionsStartDate;

    @FindBy(xpath = "//*[@class='bb-input-datepicker__wrapper']//*[contains(text(),'End date')]")
    WebElement TransactionFilterOptionsEndDate;

    @FindBy(xpath = "//*[@class='bb-input-datepicker__calendar-opener-button btn-link btn btn-md']")
    List<WebElement> CalandarOptions;

    @FindBy(xpath = "//*[@data-role='credit-debit-indicator-label']//*[contains(text(),'Credit or debit')]")
    WebElement CreditDebitOptions;


    public void getClickAccounts(String value) {
        var Account = driver.findElement(By.xpath("//*[@data-role='savingsAccounts']//*[@class='contextual-alternates-off ng-star-inserted' and contains(text(),'"+value+"')]"));
        Account.click();
    }

    public void GetTransactionPage()
    {
        Assert.assertTrue(TransactionPage.isDisplayed());
    }

    public void GetTransactionSearch(String value) {

        wait.until(ExpectedConditions.visibilityOf(EnterTransactions));
        Assert.assertTrue(EnterTransactions.isDisplayed());
        EnterTransactions.sendKeys(value);
        EnterTransactions.sendKeys(Keys.RETURN);
    }

    public void GetTransactionMessage(String message) {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + message + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void GetTransactionCancelBtn()
    {
        Assert.assertTrue(CancelTransactionSearch.isDisplayed());
        CancelTransactionSearch.click();
    }

    public void GetTransactionFilterClick()
    {
        Assert.assertTrue(TransactionFilter.isDisplayed());
        TransactionFilter.click();
    }

    public void GetTransactionFilterOptions()
    {
        Assert.assertTrue(TransactionFilterOptions.isDisplayed());
    }

    public void GetTransactionFilterStartDate(String value)
    {
        Assert.assertTrue(TransactionFilterOptionsStartDate.isDisplayed());
        WebElement val = driver.findElement(By.xpath("//*[@class='bb-input-datepicker__wrapper']//*[contains(text(),'Start date')]/..//input"));
        String passText = val.getAttribute("placeholder");
        Assert.assertEquals(value, passText);
    }

    public void GetTransactionFilterENDDate(String value)
    {
        Assert.assertTrue(TransactionFilterOptionsEndDate.isDisplayed());
        WebElement val = driver.findElement(By.xpath("//*[@class='bb-input-datepicker__wrapper']//*[contains(text(),'End date')]/..//input"));
        String passText = val.getAttribute("placeholder");
        Assert.assertEquals(value, passText);
    }

    public void FilterCalandarOptions() {

        for (WebElement webElement : CalandarOptions) {
            Assert.assertTrue(webElement.isDisplayed());
            webElement.click();
        }
    }

    public void GetTransactionCreditDebitField(String value)
    {
        WebElement val = driver.findElement(By.xpath("//*[contains(text(),'"+value+"')]//following-sibling::select"));
        Assert.assertTrue(val.isDisplayed());
    }

    public void GetTransactionMinMaxField(String value, String placeholder)
    {

        WebElement val = driver.findElement(By.xpath("//*[contains(text(),'"+value+"')]/../following-sibling::*//input"));
        Assert.assertTrue(val.isDisplayed());
        String passText = val.getAttribute("placeholder");
        Assert.assertEquals(placeholder, passText);
    }

    public void GetTransactionButton(String value)
    {
        WebElement val = driver.findElement(By.xpath("//*[@class='bb-button-bar bb-button-bar--reverse']//*[contains(text(),'"+value+"')]"));
        Assert.assertTrue(val.isDisplayed());
    }
}
