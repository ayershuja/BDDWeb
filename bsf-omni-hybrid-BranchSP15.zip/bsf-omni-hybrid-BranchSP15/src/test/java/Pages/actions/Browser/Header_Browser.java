package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class Header_Browser {

    WebDriver driver;
    WebDriverWait wait;

    public Header_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    public void SelectHeaderMenu(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-layout__horizontal-nav no-print']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void VerifyTestCase(String value) {
        System.out.println("TestCase No:" + value + "is Completed");
    }

    public void SelectFromMenu(String value) {
        var val = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }
}
