package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import com.adobe.s3fs.com.amazonaws.services.dynamodbv2.xspec.B;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.List;


public class Message_Browser {


    WebDriver driver;
    WebDriverWait wait;

    public Message_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//*[@name='ellipsis-h']")
    WebElement FurtherMenu;
    @FindBy(xpath = "//button[@aria-label='Toggle read status']")
    WebElement ToggleReadStatus;
    @FindBy(xpath = "//*[@class='bb-messages-conversations-list-item table-active bb-text-semi-bold ng-star-inserted']")
    WebElement VerifyBoldUnreadMsg;

    @FindBy(xpath = "//*[@class='table table-hover']//*[@data-role='conversation'][1]//td[@data-role='checkbox-cell']")
    WebElement FirstCoversationOutboxCheckbox;
    @FindBy(xpath = "(//*[@class='bb-input-checkbox__content'])[3]")
    WebElement SelectCheckBoxConversation;

    @FindBy(xpath = "//*[@id='bb_input_1']")
    WebElement MessageSubjectText;

    @FindBy(xpath = "//*[@data-placeholder='Write some text' or @data-placeholder='Write your message']")
    WebElement MessageText;


    @FindBy(xpath = "//*[@class='bb-empty-state']//*[@data-role='empty-state-message']")
    WebElement ConversationMessage;

    @FindBy(xpath = "//*[@class='bb-button-bar']//button[@data-role='refresh']")
    WebElement RefreshBtn;

    @FindBy(xpath = "//div[@class='bb-stack w-auto bb-stack__item--push-right']//button[@aria-label='Refresh']")
    WebElement RefreshBtnDrafts;

    @FindBy(xpath = "//*[@data-role='conversations-list-table']")
    WebElement Messages;

    @FindBy(xpath = "//tr[@data-role='conversation']")
    WebElement AllMessages;

    @FindBy(xpath = "//*[@aria-label='Select all conversations']//*[@data-role='checkbox-input']")
    WebElement SelectAll;

    @FindBy(xpath = "//*[@class='bb-stack']//*[@data-role='Delete']")
    WebElement DeleteMessages;
    @FindBy(xpath = "//span[@class='text-large bb-text-semi-bold ng-star-inserted']")
    WebElement DeleteConversationPopup;

    @FindBy(xpath = "//span[@id='messages-list-table-delete-conversation-modal-subtitle']")
    WebElement AreYouSurePopup;


    @FindBy(xpath = "//*[@data-role='dropdown']")
//    @FindBy(xpath = "//*[@class='table table-hover']//*[@data-role='conversation'][1]//td[@data-role=\"checkbox-cell\"]")
    WebElement TopicDropdown;

    @FindBy(xpath = "//*[@data-role='char-counter']/span")
    WebElement CharCount;

    @FindBy(xpath = "//tbody[@ngmodelgroup='ids']/tr[1]//span[@class='break-word ng-star-inserted']")
    WebElement SubjectText;

    @FindBy(xpath = "//*[@class='table table-hover']//*[@data-role='conversation'][1]//span[@bbtooltip='Dropdown menu']")
    WebElement CTAButton;


    @FindBy(xpath = "//*[@class='table table-hover']//*[@data-role='conversation'][1]//span[@bbtooltip='Dropdown menu']//a[@data-role='mark-as-read-unread']")
    WebElement ReadUnRead;

    @FindBy(xpath = "//*[@class='table table-hover']//*[@data-role='conversation']//*[@name='error']")
    List<WebElement> ImportantMessage;

    @FindBy(xpath = "//*[@class='bb-messages-conversations-list__container card card-lg']")
    WebElement OutboxDisplay;

    @FindBy(xpath = "(//*[@class='ng-untouched ng-pristine ng-valid']//*[@data-role='conversation'])[1]")
    WebElement ClickMessage;

    @FindBy(xpath = "//*[@class='card card-lg']")
    WebElement MessagePanel;

    @FindBy(xpath = "//*[@data-role='reply-btn']")
    WebElement ReplyButton;

    @FindBy(xpath = "(//*[@class='ng-untouched ng-pristine ng-valid']//*[@data-role='conversation'])[1]//input[@data-role='checkbox-input']")
    WebElement SelectInboxMessage;

    @FindBy(xpath = "//button[@data-role='Delete']")
    WebElement DeleteButton;


    public void SelectCheckBox() {
        try {
            wait.until(ExpectedConditions.visibilityOf(SelectInboxMessage));
            SelectInboxMessage.click();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void DeleteButtn() {
        try {
//            DeleteButton.click();
            Assert.assertTrue(DeleteButton.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void DeleteButtnOut() {
        try {
            DeleteButton.click();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }



    public void ClickOnThreeDots() {
        wait.until(ExpectedConditions.visibilityOf(FurtherMenu));
        FurtherMenu.isDisplayed();
        FurtherMenu.click();
    }

    public void FirstCoversationOutboxCheckboxClick(String value) {
        WebElement val = driver.findElement(By.xpath("(//*[@class='table table-hover']//*[@data-role='conversation'][1]//td[@data-role='checkbox-cell']//*[@aria-label='Checkbox to select conversation'])[1]"));
//        @FindBy(xpath = "//*[@class='table table-hover']//*[@data-role='conversation'][1]//td[@data-role='checkbox-cell']")
//        WebElement FirstConversation;
        try {
            Thread.sleep(30000);
            wait.until(ExpectedConditions.visibilityOf(val));
            val.click();
        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }


//        wait.until(ExpectedConditions.visibilityOf(FirstCoversationOutboxCheckbox));
//        FirstCoversationOutboxCheckbox.isDisplayed();
//        FirstCoversationOutboxCheckbox.click();
    }

    public void ReadUnreadToggleButton() {
        wait.until(ExpectedConditions.visibilityOf(ToggleReadStatus));
        ToggleReadStatus.isDisplayed();
    }

    public void ReadUnreadToggleButtonClicked() {
        wait.until(ExpectedConditions.visibilityOf(ToggleReadStatus));
        ToggleReadStatus.isDisplayed();
        ToggleReadStatus.click();
    }

    public void VerifyMessageGetsUnreadStatus() {
        wait.until(ExpectedConditions.visibilityOf(VerifyBoldUnreadMsg));
        VerifyBoldUnreadMsg.isDisplayed();
    }

    public void SelectConversation() {
        wait.until(ExpectedConditions.visibilityOf(SelectCheckBoxConversation));
        SelectCheckBoxConversation.isDisplayed();
        SelectCheckBoxConversation.click();
    }

    public void ClickOnMoreScreen(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-layout__horizontal-nav-submenu dropdown-menu show']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void SeeDropDownOptions(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-layout__horizontal-nav-submenu dropdown-menu show']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void ClickBtn(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-star-inserted']//*[contains(text(),'" + value + "')]|//*[@class='ng-star-inserted']//button[contains(text(),'"+value+"')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void ClickBtnDelete() {
        var val = driver.findElement(By.xpath("//*[@class='ng-star-inserted']//button[contains(text(),'Delete')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void SeeBtn(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-star-inserted']//*[contains(text(),'" + value + "')]|//*[@class='ng-star-inserted']//*[@data-role='form']//*[contains(text(),'" + value + "')]|//*[@class='ng-star-inserted']//button[contains(text(),'"+value+"')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void ClickFooterBtn(String value) {
        var val = driver.findElement(By.xpath("//*[@class='ng-star-inserted']//*[@data-role='form']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void ClickConfirmationBtn(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-button-bar__button btn-danger btn btn-md ng-star-inserted']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
    }

    public void PopupScreenName(String value) {
        var val = driver.findElement(By.xpath("//*[@class='modal-content-container']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }

    public void EnterMessageSubject(String Subject) {
        wait.until(ExpectedConditions.visibilityOf(MessageSubjectText));
        MessageSubjectText.click();
        MessageSubjectText.sendKeys(Subject);
    }

    public void EnterMessage(String Message) {
        wait.until(ExpectedConditions.visibilityOf(MessageText));
        MessageText.click();
        MessageText.sendKeys(Message);
    }

    public void EnterTextMessage(String Message) {
//        wait.until(ExpectedConditions.visibilityOf(MessageText));
        WebElement val = driver.findElement(By.xpath("//*[@data-placeholder='Write some text']"));
        val.click();
        val.sendKeys(Message);
    }

    public void DiscardBtn(String value) {
        try {
            var val = driver.findElement(By.xpath("//*[@class='modal-footer']//*[contains(text(),'"+value+"')]/.."));
            Thread.sleep(6000);
            Assert.assertTrue(val.isDisplayed());
            val.click();
        } catch (Exception e) {
            var val = driver.findElement(By.xpath("//*[@class='modal-footer']//*[contains(text(),'"+value+"')]/.."));
            val.click();
        }
    }

    public void VerifyHeaderBtn(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-heading-widget']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isEnabled();
        val.isDisplayed();
    }

    public void VerifyTabs(String value, String name, String label) {
        var val = driver.findElement(By.xpath("//*[@class='bb-tab-container']//*[contains(text(),'" + value + "') or contains(text(),'" + name + "') or contains(text(),'" + label + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isEnabled();
        val.isDisplayed();
    }

    public void ClickTab(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-tab-container']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isEnabled();
        val.click();
    }

    public void SeeTab(String value) {
        var val = driver.findElement(By.xpath("//*[@class='bb-tab-container']//*[contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }

    public void MessageVerbiage(String verbiage) {
        String val = driver.findElement(By.xpath("//*[@class='bb-empty-state']//*[contains(text(),'" + verbiage + "')]")).getText();
        Assert.assertEquals(val, verbiage);
    }

    public void GetTransactionMessage(String message) {
        wait.until(ExpectedConditions.visibilityOf(ConversationMessage));
        String passText = ConversationMessage.getAttribute("innerText");
        Assert.assertEquals(message, passText);
    }

    public void ClickRefreshBtn() {
        //wait.until(ExpectedConditions.visibilityOf(RefreshBtn));
        RefreshBtn.click();
    }

    public void ClickRefreshBtnOnDrafts() {
        wait.until(ExpectedConditions.visibilityOf(RefreshBtnDrafts));
        RefreshBtnDrafts.click();
    }

    public void ViewMessages() {
        wait.until(ExpectedConditions.visibilityOf(Messages));
        Messages.isDisplayed();
    }

    public void ViewMoreMessages() {
        wait.until(ExpectedConditions.visibilityOf(AllMessages));
        List<WebElement> val = driver.findElements(By.xpath("//tr[@data-role='conversation']"));
        long a = val.stream().count();
        System.out.println(a);
        Assert.assertTrue(a >= 10);
//        AllMessages;
    }


    public void SelectAllMessages() {
        WebElement val = driver.findElement(By.xpath("//*[@data-role='conversations-list-table']//input[@aria-label='Select all conversations']"));
//
        try {

            wait.until(ExpectedConditions.visibilityOf(val));
            val.click();
        } catch (Exception e) {
            throw new RuntimeException("Error" + e);
        }

    }

    public void DeleteMessages() {
        wait.until(ExpectedConditions.visibilityOf(DeleteMessages));
        DeleteMessages.isEnabled();
        DeleteMessages.click();
    }

    public void DetailsOffPopup() {
        WebElement val = driver.findElement(By.xpath("//span[@class='text-large bb-text-semi-bold ng-star-inserted']"));
        String text = val.getText();
        WebElement val1 = driver.findElement(By.xpath("//span[@id='messages-list-table-delete-conversation-modal-subtitle']"));
        String text1 = val1.getText();
        System.out.println(text);
        System.out.println(text1);
//        wait.until(ExpectedConditions.visibilityOf(DeleteMessages));
//        DeleteMessages.isEnabled();
//        DeleteMessages.click();
    }

    public void SeeBtnPopUp(String value) {
        WebElement val = driver.findElement(By.xpath("//button[normalize-space()='" + value + "']"));
        val.isDisplayed();
    }

    public void clickBtnPopUp(String value) {
        WebElement val = driver.findElement(By.xpath("//button[normalize-space()='" + value + "']"));
        val.isDisplayed();
        val.click();
    }

    public void SeeWarningPopUp(String value) {
        WebElement val = driver.findElement(By.xpath("//button[normalize-space()='" + value + "']"));
        Assert.assertTrue(val.isDisplayed());
    }

    public void GetValueFromDropdown(String value) {

        wait.until(ExpectedConditions.visibilityOf(TopicDropdown));
        Select dropdown = new Select(TopicDropdown);
        dropdown.selectByVisibleText(value);
    }

    public void GetAttachment() throws AWTException {

        Robot rb = new Robot();

        // copying File path to Clipboard
        StringSelection str = new StringSelection(System.getProperty("user.dir") + "/src/test/resources/data/FileUpload/Attachment.png");
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);

        // press Contol+V for pasting
        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_V);

        // release Contol+V for pasting
        rb.keyRelease(KeyEvent.VK_CONTROL);
        rb.keyRelease(KeyEvent.VK_V);

        // for pressing and releasing Enter
        rb.keyPress(KeyEvent.VK_ENTER);
        rb.keyRelease(KeyEvent.VK_ENTER);
    }

    public void GetCharacterLength(String value) {
        wait.until(ExpectedConditions.visibilityOf(CharCount));
        String[] passText = CharCount.getAttribute("textContent").split("0 / ");
        System.out.println(passText[1]);
        Assert.assertEquals(passText[1], value);
    }

    public void GetOutboxSubject(String value) {
        wait.until(ExpectedConditions.visibilityOf(SubjectText));
        String passText = SubjectText.getAttribute("innerText");
        Assert.assertEquals(passText, value);
    }

    public void SelectConversation(String value) {
        WebElement SelectConversation = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]//ancestor::tr//label[@for='bb_input_8']//input[@aria-checked='false']"));
        wait.until(ExpectedConditions.visibilityOf(SelectConversation));
        SelectConversation.click();
    }

    public void ClickCTA() {
        wait.until(ExpectedConditions.visibilityOf(CTAButton));
        CTAButton.click();
    }

    public void SeeCTA() {
        wait.until(ExpectedConditions.visibilityOf(CTAButton));
        Assert.assertTrue(CTAButton.isDisplayed());
    }

    public void GetUnreadRead(String value) {

        String passText = ReadUnRead.getText();
        System.out.println(passText);

        if (passText.contains("Mark as unread")) {
            ReadUnRead.isDisplayed();
            // Assert.assertEquals(passText,value);
            ReadUnRead.click();
        } else if (passText.contains("Mark as read")) {

            ReadUnRead.isDisplayed();
            // Assert.assertEquals(passText,value);
            ReadUnRead.click();
        }
    }


    public void GetImportantSign() {

        for (WebElement webElement : ImportantMessage) {
            wait.until(ExpectedConditions.visibilityOf(webElement));
            webElement.isDisplayed();
        }
    }

    public void GetOutBoxDisplay() {
        try {
           Assert.assertTrue(OutboxDisplay.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void ClickFirstMessage(int value) {

        WebElement val = driver.findElement(By.xpath("(//*[@class='ng-untouched ng-pristine ng-valid']//*[@data-role='conversation'])["+value+"]"));
        try {
            val.click();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void ClickFirstMessageinboxPanel() {
        try {
            Assert.assertTrue(MessagePanel.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void ReplyButtonClick() {
        try {
            ReplyButton.click();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void SendButtonSend(String value) {
        try {

            var val = driver.findElement(By.xpath("//*[@class='bb-button-bar bb-button-bar--reverse']//*[contains(text(),'"+value+"')]/.."));
            val.click();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }



}






