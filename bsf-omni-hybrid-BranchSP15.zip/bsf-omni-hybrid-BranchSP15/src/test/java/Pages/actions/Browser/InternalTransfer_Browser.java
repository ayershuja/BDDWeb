package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.testng.AssertJUnit.assertEquals;

public class InternalTransfer_Browser {

    WebDriver driver;
    WebDriverWait wait;

    public InternalTransfer_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    //    @FindBy(xpath = "//*[@class='ng-untouched ng-pristine ng-invalid ng-star-inserted']/div[1]//span[@class='ng-arrow-wrapper']")
    @FindBy(xpath = "//div[@class='ng-select-container'][contains(.,'Select Account')]")
    WebElement TransferFrom;
    @FindBy(xpath = "//input[@id='bb_element_12' and @data-role='currency-input-currency-readonly']")
    WebElement CurrencyUnitFixed;

    @FindBy(xpath = "//span[@class='integer']")
    WebElement AmountReview;

    @FindBy(xpath = "(//*[@class='bb-account-info__product-number-content'])[1]")
    WebElement FirstAccount;
    //    @FindBy(xpath = "//*[@class='ng-untouched ng-pristine ng-invalid ng-star-inserted']/div[2]//span[@class='ng-arrow-wrapper']")

    //button[@aria-describedby='account-selector-creditorAccount-error-message']
    @FindBy(xpath = "//div[@class='ng-select-container'][contains(.,'Select beneficiary')]")
    WebElement TransferTo;

    @FindBy(xpath = "//span[@class='bb-text-support bb-product-selector__placeholder']")
    WebElement FromToEmptyFields;
    @FindBy(xpath = "//*[contains(text(),'Sight Deposit')]//ancestor::*[@class='bb-dropdown-multi-select--disabled']")
    WebElement DropDownElementDisabled;

    @FindBy(xpath = "//body/bb-app-root[1]/ng-component[1]/bb-retail-layout[1]/div[1]/div[2]/div[2]/div[1]/div[2]/bb-initiate-payment-journey-wrapper[1]/bb-initiate-payment-journey[1]/bb-create-payment-form[1]/bb-payord-form[1]/form[1]/bb-payord-group[1]/bb-payord-internal-account-selector[1]/div[1]/section[1]/label[1]/bb-product-selector-ui[1]/div[1]/div[1]/div[1]")
    WebElement TransferDropdown;

    public void SelectHeaderMenu() {
        System.out.println("issue");
    }

    public void ClickTransferFrom() {
        wait.until(ExpectedConditions.visibilityOf(TransferFrom));
        TransferFrom.click();
    }

    public void VerifyFieldsGetsClear() {
        Domestic_Transfer domestic_transfer=new Domestic_Transfer();
        String text = domestic_transfer.EnterAmount.getText();
        Assert.assertTrue( text.contains(""));
        String text1 = domestic_transfer.EnterNote.getText();
        Assert.assertTrue( text.contains(""));
    }
    public void VerifyDetailsFromAccount (String value) {
        var val = driver.findElement(By.xpath("//*[@data-role='"+value+"']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.isDisplayed();
    }
    public void VerifyDetailsAmount(String value) {
//        var val = driver.findElement(By.xpath("//*[@data-role='"+value+"']"));
        wait.until(ExpectedConditions.visibilityOf(AmountReview));
        AmountReview.isDisplayed();
    }
    public void VerifyDetailsDate() {
//        var val = driver.findElement(By.xpath("//*[@data-role='"+value+"']"));
        wait.until(ExpectedConditions.visibilityOf(AmountReview));
        AmountReview.isDisplayed();
    }
    public void CurrencyUnitGetsFixed() {
        wait.until(ExpectedConditions.visibilityOf(CurrencyUnitFixed));
        CurrencyUnitFixed.isDisplayed();
    }

    public void CurrencyUnitDropDown(String value1, String value2) {
        Select drpCurrencyUnit = new Select(driver.findElement(By.xpath("//select[@id='bb_element_19']")));
        var options_dd = drpCurrencyUnit.getOptions();
        System.out.println(options_dd);

    }

    public void ClickTransferTo() {
        wait.until(ExpectedConditions.visibilityOf(TransferTo));
        TransferTo.click();
    }
    public void FromAndTOFieldsCLear() {
        wait.until(ExpectedConditions.visibilityOf(FromToEmptyFields));
        FromToEmptyFields.isDisplayed();
    }

    public void VerifyDDElementDisabled() {
        wait.until(ExpectedConditions.visibilityOf(DropDownElementDisabled));
        Assert.assertTrue(DropDownElementDisabled.isDisplayed());
    }

    public void VerifySuccessMsg(String value)
    {
        var val = driver.findElement(By.xpath("//*[normalize-space()='" + value + "']"));
        wait.until(ExpectedConditions.visibilityOf(val));
        Assert.assertTrue(val.isDisplayed());
    }
    public WebElement ClickOnFromTransferAccount(String value) {
        wait.until(ExpectedConditions.visibilityOf(TransferDropdown));
        var val = driver.findElement(By.xpath("//*[@class='bb-ellipsis bb-ellipsis--single-line'][contains(text(),'" + value + "')]"));
        wait.until(ExpectedConditions.visibilityOf(val));
        val.click();
        return val;
    }


    public void Verifyselection(String value) {

        String actualValue = ClickOnFromTransferAccount(value).getText();

//        assertEquals(expectedValue, actualValue);
    }


}
