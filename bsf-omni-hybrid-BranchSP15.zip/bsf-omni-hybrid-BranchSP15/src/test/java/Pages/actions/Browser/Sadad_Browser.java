package Pages.actions.Browser;

import DriverManager.Driver;
import StepDefinitions.RunnerInfo;
import junit.framework.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Sadad_Browser {


    WebDriver driver;
    WebDriverWait wait;

    private WebElement button;
    private boolean isDisabled;

    public Sadad_Browser() {
        this.driver = (WebDriver) Driver.driver.get(RunnerInfo.getDeviceType());
        wait = new WebDriverWait(driver, Duration.ofSeconds(30), Duration.ofSeconds(60));
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//*[@class='dropdown']//*[@role='menu']")
    WebElement AddNewDropdownView;

    @FindBy(xpath = "//*[@data-role='search-input']")
    WebElement SearchField;

    @FindBy(xpath = "//*[@formcontrolname='billerName']")
    WebElement SelectBiller;

    @FindBy(xpath = "//*[@container='ng-select']//*[@data-role='dropdown-menu-toggle-button']")
    WebElement FilterOption;

    @FindBy(xpath = "//*[@container='ng-select']//*[@data-role='dropdown-menu-toggle-button']")
    WebElement InputType;

    @FindBy(xpath = "//*[@class='ng-untouched ng-pristine ng-invalid']//*[@formcontrolname='billerName']")
    WebElement SelectBillerDropdown;

    @FindBy(xpath = "//*[@class='ng-untouched ng-pristine ng-invalid']//*[@formcontrolname='billerName']//input[@data-role='search-input']")
    WebElement SelectBillerValue;

    @FindBy(xpath = "//*[@formcontrolname='billerName']//div[@role='option'][1]")
    WebElement SelectBillerValueDropdown;

    @FindBy(xpath = "//*[@class='main bb-border-bottom ng-star-inserted'][last()]//button[@data-role='dropdown-menu-toggle-button']")
    WebElement ClickLastBill;

    @FindBy(xpath = "//*[@class='d-flex justify-content-between bb-block--md bb-stack bb-stack--wrap product-item-content pt-5']//button[contains(text(),'Continue')]")
    WebElement Continue_Button;

    @FindBy(xpath = "//*[@class='pb-3 rtl-search ng-star-inserted']//input[@data-role='search-input']")
    WebElement SearchTextBox;

    @FindBy(xpath = "//span[@data-role='inline-edit-text']")
    List<WebElement> BillName;

    @FindBy(xpath = "//*[@class='badge badge-success ng-star-inserted']")
    List<WebElement> BillStatus;

    @FindBy(xpath = "//span[@data-role='inline-edit-text']")
    List<WebElement> BillNumber;

    @FindBy(xpath = "//*[@class='main bb-border-bottom ng-star-inserted']//div[2]")
    List<WebElement> ExpiryDate;

    @FindBy(xpath = "//*[@class='main bb-border-bottom ng-star-inserted']//div[3]")
    List<WebElement> BillAmount;

    @FindBy(xpath = "//*[@class='main bb-border-bottom ng-star-inserted']//button[@class='btn btn-primary btn-md' and contains(text(),'Detail')]")
    List<WebElement> DetailCTA;

    @FindBy(xpath = "//*[@data-role='search-input']")
    WebElement EnterTransactions;
    public void verifyAddNewDropdownList(String value) {
        var actualValue = driver.findElement(By.xpath("//*[@data-role='dropdown-menu']//*[contains(text(),'" + value + "')]")).getText();
        Assert.assertEquals(value, actualValue);
    }

    public void GetAddNewDropdownView() {
        try {
            Assert.assertTrue(AddNewDropdownView.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void ClickSearchField(String value) {
        SearchField.click();
        wait.until(ExpectedConditions.visibilityOf(EnterTransactions));
        org.testng.Assert.assertTrue(EnterTransactions.isDisplayed());
        EnterTransactions.sendKeys(value);
        EnterTransactions.sendKeys(Keys.RETURN);

    }

    public void GetDropdownValueSelect(String value) {
        var btn = driver.findElement(By.xpath("//*[@class='dropdown']//*[contains(text(),'" + value + "')]"));
        btn.click();
    }

    public void GetValueWithField(String value) {
        var btn = driver.findElement(By.xpath("//*[@class='bb-block bb-block--lg']//*[contains(text(),'" + value + "')]/..//*[@class='ng-select-container']"));
        try {
            btn.isDisplayed();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void SelectBillerField() {
        try {
            SelectBiller.click();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public void GetValueWithField() {
        try {
            FilterOption.isDisplayed();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void GetBtnDisable() {
        try {
            button = driver.findElement(By.name("Continue"));
            isDisabled = button.getAttribute("disabled") != null;
            assert isDisabled : "Button is not disabled";
        } catch (NoSuchElementException e) {
            System.out.println("Button is disabled");
        }
    }

    public void GetViewInputOfLabel(String value) {
        var InputLabel = driver.findElement(By.xpath("//*[@class='bb-block bb-block--lg ng-star-inserted']//label[contains(text(),'" + value + "')]/..//input"));
        try {
            Assert.assertTrue(InputLabel.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void VerifyInputType(String value, String type) {
        WebElement ActualValue = driver.findElement(By.xpath("//*[@class='bb-block bb-block--lg ng-star-inserted']//label[contains(text(),'" + value + "')]/..//input"));
        try {
            Assert.assertTrue(ActualValue.isDisplayed());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        String actualType = ActualValue.getAttribute("type");
        Assert.assertEquals(type, actualType);

    }

    public void VerifyHelperText(String value, String placeholder, String length) {
//wait.until(ExpectedConditions.visibilityOf(OtherPurposeLabel));
        var InputValue = driver.findElement(By.xpath("//*[contains(text(),'Account Number')]")).getText();
        WebElement actualValue1 = driver.findElement(By.xpath("//*[contains(text(),'" + value + "')]/..//input"));
        var actualValue = actualValue1.getText();
        System.out.println(actualValue);
        Assert.assertEquals(value, InputValue);
        String actualplaceholder = actualValue1.getAttribute("placeholder");
        Assert.assertEquals(placeholder, actualplaceholder);
        String actuallength = actualValue1.getAttribute("size");
        Assert.assertEquals(length, actuallength);
    }

    public void InputText(String value, String field) {
        var InputLabel = driver.findElement(By.xpath("//*[contains(text(),'" + field + "')]/..//input"));
        try {
            Assert.assertTrue(InputLabel.isDisplayed());
            InputLabel.sendKeys(value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void ClearField(String field) {
        var InputLabel = driver.findElement(By.xpath("//*[contains(text(),'" + field + "')]/..//input"));
        try {
            InputLabel.clear();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void SelectBiller()
    {
        try{
            SelectBillerDropdown.click();
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void SelectBillerValue(String value)
    {
        try{
            SelectBillerValue.sendKeys(value);
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void SelectBillerValueDropdown()
    {
        try{
            wait.until(ExpectedConditions.visibilityOf(SelectBillerValueDropdown));
            SelectBillerValueDropdown.click();
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetContinueBtn()
    {
        try{
            Assert.assertTrue(Continue_Button.isDisplayed());
            wait.until(ExpectedConditions.visibilityOf(Continue_Button));
            Continue_Button.click();
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetLastBill()
    {
        try{
            Assert.assertTrue(ClickLastBill.isDisplayed());
            ClickLastBill.click();
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void DeleteBill(String value) {
        var values = driver.findElement(By.xpath("//*[@class='dropdown-menu ng-star-inserted show']//a[contains(text(),'"+value+"')]"));

        try{
            Assert.assertTrue(values.isDisplayed());
            values.click();
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetRemoveBillPopup(String value) {
        var values = driver.findElement(By.xpath("//*[@class='modal-content-container']//h1[contains(text(),'"+value+"')]"));

        try{
            Assert.assertTrue(values.isDisplayed());
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetRemoveBillPopupDesc(String value) {
        var values = driver.findElement(By.xpath("//*[@class='modal-content-container']//div[contains(text(),'"+value+"')]"));

        try{
            Assert.assertTrue(values.isDisplayed());
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetRemoveBillBtn(String value) {
        var values = driver.findElement(By.xpath("//*[@class='modal-content-container']//h1[contains(text(),'Remove Bill')]/..//button[contains(text(),'"+value+"')]"));

        try{
            Assert.assertTrue(values.isDisplayed());
            values.click();
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetHeadervalue(String value) {
        var values = driver.findElement(By.xpath("//*[@class='bb-layout__main-content-area']//h1[contains(text(),'"+value+"')]"));

        try{
            Assert.assertTrue(values.isDisplayed());

        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetCTABtn(String CTA1, String CTA2) {
        var values = driver.findElement(By.xpath("//*[@class='checkbox-main label-layout pb-5']//*[contains(text(),'"+CTA1+"') or contains(text(),'"+CTA2+"')]"));

        try{
            Assert.assertTrue(values.isDisplayed());

        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void GetSearchTextBox() {

        try{
            Assert.assertTrue(SearchTextBox.isDisplayed());

        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void VerifyBillName() {

        try{
        for (WebElement webElement : BillName) {
            webElement.isDisplayed();
            }
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void VerifyBillNumber() {

        try{
            for (WebElement webElement : BillNumber) {
                webElement.isDisplayed();
            }
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void VerifyBillStatus() {

        try{
            for (WebElement webElement : BillStatus) {
                webElement.isDisplayed();
            }
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void VerifyExpiryDate() {

        try{
            for (WebElement webElement : ExpiryDate) {
                webElement.isDisplayed();
            }
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void VerifyBillAmount() {

        try{
            for (WebElement webElement : BillAmount) {
                webElement.isDisplayed();
            }
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void VerifyDetailCTA() {

        try{
            for (WebElement webElement : DetailCTA) {
                webElement.isDisplayed();
            }
        }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    public void NavigateBack() {

        try{
            driver.navigate().back();
            }
        catch (Exception e){
            throw new RuntimeException(e);
        }
    }


}