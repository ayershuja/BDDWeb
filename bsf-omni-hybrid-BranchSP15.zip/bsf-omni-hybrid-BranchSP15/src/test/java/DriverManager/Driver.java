package DriverManager;


import StepDefinitions.RunnerInfo;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import io.appium.java_client.service.local.flags.GeneralServerFlag;
import io.appium.java_client.windows.WindowsDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.testng.Reporter;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

public class Driver {
    public Driver() { // private constructor

    }

     private final String userName = "teamit_eh8STI";
     private final String accessKey = "UxZABzizx1iwPbzH1qnM";
     public static Map<String, Object> driver = new HashMap<>();
     public String status = "android";
     public static Map<String,List<AppiumDriverLocalService>> appiumDriverLocalServices = new HashMap<>();

    public  void setStatus(String newStatus) {
        status = newStatus;
    }


    public  String getStatus() {
        return status;
    }
    public  void setUp(String environment) {

        try {
            setStatus(environment);
            switch (environment.toLowerCase()) {
                case "android" -> openAndroidDriver();
                case "ios" -> openIOSDriver();
                case "windows" -> openWindowsDriver();
                case "browser" -> openNativeBrowser();
                case "browserstack-android" -> openBrowserStackDriver("Android");
                case "browserstack-ios" -> openBrowserStackDriver("iOS");
                default -> {
                    driver = null;
                    System.out.println("No driver found in switch method from json file");
                }
            }
        } catch (Exception e) {
            System.out.println("Source: " + e.getCause());
            System.out.println("Message: " + e.getMessage());
            System.out.println("Stack Trace: " + Arrays.toString(e.getStackTrace()));
        }
    }

    private  void openBrowserStackDriver(String type) throws MalformedURLException {

        String env = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("deviceName");

        System.out.println("Starting BrowserStack Driver");
        System.out.println("Mobile Type: " + type);
        String url = "https://" + userName + ":" + accessKey + "@hub-cloud.browserstack.com/wd/hub";
        System.out.println("URL: " + url);
        if (type.equalsIgnoreCase("android")) {
            DesiredCapabilities capabilities = readCapabilities("./src/test/resources/data/"+env+".properties");
            driver.put(status,new AndroidDriver(new URL("https://" + userName + ":" + accessKey + "@hub-cloud.browserstack.com/wd/hub"), capabilities));
        } else if (type.equalsIgnoreCase("ios")) {
            DesiredCapabilities capabilities = readCapabilities("./src/test/resources/data/"+env+".properties");
//            capabilities.setCapability("browserstack.uploadMedia", new String[]{"media://d3b25ffc7e7e16122a19743ddfc60cf4433cccc1"});
            driver.put(status, new IOSDriver(new URL("https://" + userName + ":" + accessKey + "@hub-cloud.browserstack.com/wd/hub"), capabilities));
        } else throw new RuntimeException("BrowserStack Type:" + type + " is wrong");
        System.out.println("BrowserStack Driver: " + driver);
    }

    private  void openAndroidDriver() throws MalformedURLException {
        System.out.println("Starting Android Appium Service");
//        URL url = new URL("http://0.0.0.0:4723/wd/hub");
        AppiumDriverLocalService setAppiumDriverLocalService = startAppium();
        DesiredCapabilities capabilities = readCapabilities("./src/test/resources/data/samsungS22Ultra.properties");
        capabilities.setCapability("enableMultiWindows", true);
        capabilities.setCapability("autoGrantPermissions", true);
        capabilities.setCapability("noReset", "false");
  //      capabilities.setCapability("isHeadless", true);
        try {
            driver.put(status, new AndroidDriver(setAppiumDriverLocalService.getUrl(), capabilities));

        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Appium Started");
        System.out.println("Android Driver: " + driver);
    }

    private  void openIOSDriver() {
        System.out.println("Starting IOS Appium Service");
        AppiumDriverLocalService iosAppiumDriverLocalService = startAppium();
        DesiredCapabilities capabilities = readCapabilities("./src/test/resources/data/iPoneProMax.properties");
        capabilities.setCapability("autoDismissAlerts","true");
        driver.put(status, new IOSDriver(iosAppiumDriverLocalService.getUrl(), capabilities));
        System.out.println("Appium Started");
        System.out.println("IOS Driver: " + driver);
    }

    private  void openWindowsDriver() {
        System.out.println("Starting Windows Appium Service");
        AppiumDriverLocalService windowsAppiumDriverLocalService = startAppium();
        DesiredCapabilities capabilities = readCapabilities("./src/test/resources/data/windows.properties");
        driver.put(status,new WindowsDriver(windowsAppiumDriverLocalService.getUrl(), capabilities));
        System.out.println("Appium Started");
        System.out.println("Windows Driver: " + driver);
    }

    private  void openNativeBrowser() {
        System.out.println("Starting Browser Driver Service");
        String browserName = getBrowserName();
        switch (browserName.toLowerCase()) {
            case "chrome" -> setupChromeBrowser();
            case "firefox" -> setupFirefoxBrowser();
            case "edge" -> setupEdgeBrowser();
            case "safari" -> setupSafariBrowser();
        }
        System.out.println("Initiated Browser Driver: " + driver);
    }

    private  void setupChromeBrowser() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions option = new ChromeOptions();
        option.addArguments("--remote-allow-origins=*");
        option.setCapability(ChromeOptions.CAPABILITY, option);
        driver.put(status,new ChromeDriver(option));

    }

    private  void setupFirefoxBrowser() {
        WebDriverManager.firefoxdriver().setup();
        driver.put(status,new FirefoxDriver());
    }

    private  void setupSafariBrowser() {
        WebDriverManager.safaridriver().setup();
        driver.put(status, new SafariDriver());
    }

    private  void setupEdgeBrowser() {
        WebDriverManager.edgedriver().setup();
        driver.put(status,new EdgeDriver());
    }

    private  AppiumDriverLocalService startAppium() {
        System.out.println("Setting Appium");
//        AppiumServiceBuilder appiumServiceBuilder = new AppiumServiceBuilder();
//        appiumServiceBuilder.usingAnyFreePort()
//                .withIPAddress("127.0.0.1")
//                .withArgument(GeneralServerFlag.SESSION_OVERRIDE)
//                .withLogFile(new File(System.getProperty("user.dir") + "/target/resources/appium_server_logs" + Thread.currentThread().getId()));
//        AppiumDriverLocalService appiumDriverLocalService = AppiumDriverLocalService.buildService(appiumServiceBuilder);
//        appiumDriverLocalService.start();
        AppiumServiceBuilder builder = new AppiumServiceBuilder();
//        builder = new AppiumServiceBuilder();
//        builder.withIPAddress("127.0.0.1");
//        builder.usingPort(4723);
//        builder.withArgument(GeneralServerFlag.SESSION_OVERRIDE);
//        builder.withArgument(GeneralServerFlag.LOG_LEVEL,"error");
//
//        //Start the server with the builder
//        AppiumDriverLocalService appiumDriverLocalService = AppiumDriverLocalService.buildService(builder);
//        appiumDriverLocalService.start();
        AppiumDriverLocalService appiumDriverLocalService = builder.usingAnyFreePort().withArgument(GeneralServerFlag.BASEPATH, "/wd/hub/").withArgument(GeneralServerFlag.SESSION_OVERRIDE).withArgument(GeneralServerFlag.SESSION_OVERRIDE)
                .withArgument(GeneralServerFlag.LOG_LEVEL, "error")
                .withArgument(GeneralServerFlag.RELAXED_SECURITY).build();
        System.out.println("Service URL: " + appiumDriverLocalService.getUrl());
        if (!appiumDriverLocalService.isRunning()) {
            System.out.println("Appium Service Not Running");
            appiumDriverLocalService.start();
            appiumDriverLocalService.clearOutPutStreams();
            System.out.println("Appium Service Started");
        }
        System.out.println("Appium Service: " + appiumDriverLocalService);
        System.out.println(RunnerInfo.getDeviceType());
        System.out.println(List.of(appiumDriverLocalService));
        appiumDriverLocalServices.put(RunnerInfo.getDeviceType(), List.of(appiumDriverLocalService));
        return appiumDriverLocalService;
    }

    private  DesiredCapabilities readCapabilities(String path) {
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream(path));
            DesiredCapabilities capabilities = new DesiredCapabilities();
            Enumeration<?> e = prop.propertyNames();

            while (e.hasMoreElements()) {
                String key = (String) e.nextElement();
                capabilities.setCapability(key, prop.getProperty(key));
            }
            return capabilities;

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private  String getBrowserName() {
        Properties prop = new Properties();
        try {
            prop.load(new FileInputStream("./src/test/resources/data/browserConfig.properties"));
            return prop.getProperty("browser");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void stopAppium() {
        String name = RunnerInfo.getDeviceType();
        if(appiumDriverLocalServices.get(name) != null) {
            for (AppiumDriverLocalService appiumDriver : appiumDriverLocalServices.get(name)) {
                appiumDriver.stop();
            }
        }
    }

    public  void stopBrowserDriver() {
        var browserName = getBrowserName();
        switch (browserName.toLowerCase()) {
            case "chrome" -> {
                var chromeDriver = (ChromeDriver) driver.get("browser");
                chromeDriver.quit();
            }
            case "firefox" -> {
                var foreFoxDriver = (FirefoxDriver) driver.get("browser");
                foreFoxDriver.quit();
        }
            case "edge" -> {
                var edgeDriver = (EdgeDriver) driver.get("browser");
                edgeDriver.quit();
            }
        }
    }
}

